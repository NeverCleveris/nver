<?php
ob_start();
require_once "../classes/My_Class.php";
require_once TPL."head.php";

if (!isset($_COOKIE['secretkey']) or $_COOKIE['secretkey'] != $secretkey) {
           header("Location: index.php"); 
exit;
}

$My_Class->title("Настройки BITCOIN");
	
if(isset($_GET['history']) ) {
	

	
$set_bot = DB::$the->query("SELECT * FROM `sel_set_bot` ");
$set_bot = $set_bot->fetch(PDO::FETCH_ASSOC);
	echo' <div class="panel-heading"><center><h3 class="m-t-0 header-title">История с номера: <i>'.$set_bot['numberbtc'].'</i></h3></center></div>';
	 
	
	echo'<div class="form-group col-sm-10">История пополнений  <table style="font-size: 14px;" class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>                                 
                                        <th>address BTC</th>
                                       <th>Пользователь</th>
										 <th>Сумма в BTC</th>
										 <th>Сумма в RUB</th>
										 <th>Сумма в Тенге</th>
										 <th>Время</th>	 
                                         <th>Cтатус оплаты</th>	
                                    </tr>
                                </thead>

                                            <tbody>';
$query = DB::$the->query("SELECT * FROM `payments`  ");
     while($row = $query->fetch()) {
     	$user = DB::$the->query("SELECT * FROM `sel_users` WHERE `chat` = {$row['invoice_id']} ");
$user = $user->fetch(PDO::FETCH_ASSOC);
           echo '    <tr>
                                                    <td>'.$row['id'].'</td>
													<td>'.$row['input_address'].'</td>
                                                    <td>'.$user['username'].'</td>
                                                    <td>'.$row['value'].' BTC</td>
													<td>'.$row['valuerub'].' RUB</td>
													<td>'.$row['valuekzt'].' KZT</td>
                                                    <td>'.$eng->showtime($row['date_create'],1).'</td>
                                                    <td><font color="green">'.$row['status'].'</font></td>

                                               </tr>
												';

	   }
  
        echo '
                                </tbody>
                            </table>
							  </div>
                        
                 
           

';

		


}else{
	
	
	
$row = DB::$the->query("SELECT * FROM `sel_set_bot` ");
$set = $row->fetch(PDO::FETCH_ASSOC);


if(isset($_GET['ok']) and isset($_POST['submit'])) {

if($_POST['numberbtc'] != "" and $_POST['passwordbtc'] != "") {

$numberbtc=$_POST['numberbtc'];
$passwordbtc=$_POST['passwordbtc'];
$btc=$_POST['btc'];



DB::$the->prepare("UPDATE sel_set_bot SET numberbtc=? ")->execute(array("$numberbtc")); 
DB::$the->prepare("UPDATE sel_set_bot SET passwordbtc=? ")->execute(array("$passwordbtc")); 
DB::$the->prepare("UPDATE sel_set_bot SET btc=? ")->execute(array("$btc"));

header("Location: ?");
}
else
{
?>
<div class="alert alert-danger"> Первый номер и пароль обязательный к заполнению!</div>
<?
}
}

?>
<script type="text/javascript">  
 $(function() { 
    $(".btn").click(function(){
        $(this).button('loading').delay(3000).queue(function() {
            $(this).button('reset');
            $(this).dequeue();
        });        
    });
});  
</script>

<div class="col-lg-8">
<center><h3>Настройки Оплаты BITCOIN</h3>



</div>


<form method="POST" action="?ok"><div class="form-group col-sm-8">


<div class="alert alert-info">
              <button type="button" class="close" data-dismiss="alert">x</button><br>
              <strong>Внимание!</strong> Чтобы Включить Прием BITCOIN в Боте!!! <font color="green">Заполните 1. Название Платежной системы:</font>
</div>
<div class="panel panel-default">
  <div class="panel-heading"><input type="radio" name="active" value="<?=$res['id']?>" <? if($act['active'] == '1') echo 'checked'; ?>><?=$res['id']?> 
  <? if($res['active'] == "1") echo '<font color="green">ПРИНИМАЕТ ОПЛАТУ</font>'; ?></div>
  <div class="panel-body">		
<div class="input-group input-group-lg">	
	<span class="input-group-addon">1. Название Платежной системы:</span>
    <input type="text" class="form-control" name="btc" value="<?=$set['btc'];?>">
    </div><br />
<div class="input-group input-group-lg">	
	<span class="input-group-addon">2. Номер Кошелька BTC</span>
    <input type="text" class="form-control" name="numberbtc" value="<?=$set['numberbtc'];?>">
     </div><br />	
<div class="input-group input-group-lg">	
	<span class="input-group-addon">3. Пароль Номер Кошелька BTC  </span>
    <input type="password" class="form-control" name="passwordbtc" value="<?=$set['passwordbtc'];?>">
    </div><br />
<div class="input-group input-group-lg">
<ul>
</div>

<a type="submit" href="?history" data-loading-text="Загружаем" class="form-control btn btn-min btn-warning waves-effect waves-light">история </a>

	
</div></div>		

<button type="submit" name="submit" data-loading-text="Сохраняю" class="btn btn-danger btn-lg btn-block">Сохранить</button></form>
</div>
<?
}
$My_Class->foot();
?>