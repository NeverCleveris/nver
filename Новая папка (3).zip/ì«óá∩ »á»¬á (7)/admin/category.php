<?php
ob_start();


require_once "../classes/My_Class.php";
require_once TPL."head.php";


if (!isset($_COOKIE['secretkey']) or $_COOKIE['secretkey'] != $secretkey) {
header("Location: index.php");		
exit;
}

$My_Class->title("Категории");

if(isset($_GET['category'])){
$header = DB::$the->query("SELECT id FROM `sel_category` WHERE `id` = '".intval($_GET['category'])."' ");
$header = $header->fetchAll();
if(count($header) == 0){
header("Location: index.php");		
exit;
}}	

?>
<script type="text/javascript">  
 $(function() { 
    $(".btn").click(function(){
        $(this).button('loading').delay(3000).queue(function() {
            $(this).button('reset');
            $(this).dequeue();
        });        
    });
});  
</script>
<?

if(isset($_GET['cmd'])){$cmd = htmlspecialchars($_GET['cmd']);}else{$cmd = '0';}
if(isset($_GET['category'])){$category = abs(intval($_GET['category']));}else{$category = '0';}

switch ($cmd){
case 'create':
?>
<ol class="breadcrumb">
  <li><a href="index.php">Админ-панель</a></li>
  <li><a href="category.php">Категории</a></li>
  <li class="active">Создание категории</li>
</ol>
<?
if(isset($_POST['create'])) {

if($_POST['cat'] != "") {
$cat=$_POST['cat'];

$cat_m = DB::$the->query("SELECT mesto FROM `sel_category` order by `mesto` DESC limit 1 ");
$cat_m = $cat_m->fetch(PDO::FETCH_ASSOC);
$new_mesto = $cat_m['mesto']+1;

$params = array( 'name' => ''.$cat.'', 'time' => ''.time().'', 'mesto' => $new_mesto);  
 
$q= DB::$the->prepare("INSERT INTO `sel_category` (name, time, mesto) VALUES (:name, :time, :mesto)");  
$q->execute($params);

header("Location: category.php");
}
else
{
echo '<div class="alert alert-danger">Пустое название</div>';
}
}

echo '<form action="category.php?cmd=create" method="POST">
<div class="form-group col-sm-8">
<div class="input-group input-group-lg">
    <span class="input-group-addon"><span class="glyphicon glyphicon-pencil"></span> </span>
<input type="text" placeholder="Название категории" class="form-control" name="cat" value="">
</div>
<br />
<button type="submit" name="create" class="btn btn-danger btn-lg btn-block" data-loading-text="Создаю">Создать</button>
</div></form>';

break;
 	
case 'edit':	
?>
<ol class="breadcrumb">
  <li><a href="index.php">Админ-панель</a></li>
  <li><a href="category.php">Категории</a></li>
  <li class="active">Редактирование категории</li>
</ol>
<?

$row = DB::$the->query("SELECT * FROM `sel_category` WHERE `id` = {$category} ");
$cat = $row->fetch(PDO::FETCH_ASSOC);

// Редактирование категории
if(isset($_POST['edit'])) {

if($_POST['name'] != "") {
$name=$_POST['name'];
$mesto=intval($_POST['mesto']);
$img=$_POST['img'];
DB::$the->prepare("UPDATE sel_category SET img=? WHERE id=? ")->execute(array("$img", $category)); 
DB::$the->prepare("UPDATE sel_category SET name=? WHERE id=? ")->execute(array("$name", $category)); 
DB::$the->prepare("UPDATE sel_category SET mesto=? WHERE id=? ")->execute(array("$mesto", $category)); 

header("Location: category.php");
}
else
{
echo '<div class="alert alert-danger">Пустое название</div>';
}
}


echo '<form action="?cmd=edit&category='.$category.'" method="POST">
<div class="form-group col-sm-8">
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-pencil"></span> </span>
<input type="text" placeholder="'.$cat['name'].'" class="form-control" name="name" value="'.$cat['name'].'">
</div><br />
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-flag"></span> </span>
<input type="text" placeholder="'.$cat['mesto'].'" class="form-control" name="mesto" value="'.$cat['mesto'].'">
</div><br />
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-camera"></span> </span>
<input type="text" placeholder="'.$cat['img'].'" class="form-control" name="img" value="'.$cat['img'].'">
</div><br />
<button type="submit" name="edit" class="btn btn-danger btn-lg btn-block" data-loading-text="Изменяю">Изменить</button>
</div></form>';

	
break;

case 'delete':	
$row = DB::$the->query("SELECT * FROM `sel_category` WHERE `id` = '".$category."'");
$cat = $row->fetch(PDO::FETCH_ASSOC);
?>
<ol class="breadcrumb">
  <li><a href="index.php">Админ-панель</a></li>
  <li><a href="category.php">Категории</a></li>
  <li class="active">Удаление категории: <b><?=$cat['name'];?></b></li>
</ol>
<div class="alert alert-danger">Будут удалены все подкатегории данной категории и ключи из всех подкатегорий данной категории!</div>

<div class="btn-group">
  <button type="button" class="btn btn-danger dropdown-toggle" data-loading-text="Думаем" data-toggle="dropdown">Вы уверены? <span class="caret"></span></button>
  <ul class="dropdown-menu" role="menu">
    <li><a href="?cmd=delete&category=<?=$category;?>&ok">Да, удалить</a></li>
    <li class="divider"></li>
    <li><a href="category.php">Нет, отменить</a></li>
  </ul>
</div><br /><br />

<?

if(isset($_GET['ok'])) {
DB::$the->query("DELETE FROM `sel_category` WHERE `id` = '".$category."' ");
DB::$the->query("DELETE FROM `sel_subcategory` WHERE `id_cat` = '".$category."' ");
DB::$the->query("DELETE FROM `sel_keys` WHERE `id_cat` = '".$category."' ");

header("Location: category.php");
}

break;

case 'remove_sale':	

?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>  <li><a href="category.php">Категории</a></li>
  <li class="active">Удаление всех проданных ключей</b></li>
</ol>
<div class="alert alert-danger">Будут удалены все проданные ключи из всех категорий!</div>

<div class="btn-group">
  <button type="button" class="btn btn-danger dropdown-toggle" data-loading-text="Думаем" data-toggle="dropdown">Вы уверены? <span class="caret"></span></button>
  <ul class="dropdown-menu" role="menu">
    <li><a href="?cmd=remove_sale&ok">Да, удалить все проданные ключи</a></li>
    <li class="divider"></li>
    <li><a href="category.php">Нет, отменить</a></li>
  </ul>
</div><br /><br />

<?

if(isset($_GET['ok'])) {
DB::$the->query("DELETE FROM `sel_keys` WHERE `sale` = '1' ");

header("Location: category.php");
}

break;
	
default:

?>
	
<div class="alert alert-warning">
              <button type="button" class="close" data-dismiss="alert">x</button><br>
              <strong><font color="red">Внимание!</strong> <b>НАЗВАНИЯ РАЙОНОВ, ФАСОВОК, ТОВАРА В ГОРОДЕ, НЕ ДОЛЖНЫ СОВПАДАТЬ С НАЗВАНИЯМИ КАТЕГОРИЙ В ОСТАЛЬНЫХ ГОРОДАХ.</b></font>
</div>
	


<div class="row">
                    <div class="col-sm-12">
                        <div class="button-list pull-right">
						    <a  class="btn btn-info waves-effect waves-light" href="subcategory.php?cmd=createcats"><i class="glyphicon glyphicon-plus-sign m-r-5"></i> <span>Добавить фасовку</span></a>
                            <a  class="btn btn-info waves-effect waves-light" href="?cmd=create"><i class="fa fa-plus m-r-5"></i> <span>Добавить город</span></a>
							<a  class="btn btn-danger waves-effect waves-light" href="?cmd=remove_sale"><i class="glyphicon glyphicon-trash m-r-5"></i><span>Удалить все проданые адреса</span></a>

                        </div>

                        <h4 class="page-title">Управление городами</h4>
                      
                    </div>
                </div><br />
				<div class="row">
				<div class="col-lg-7">
<?



$total = DB::$the->query("SELECT * FROM `sel_category` ");
$total = $total->fetchAll();
$max = 15;
$pages = $My_Class->k_page(count($total),$max);
$page = $My_Class->page($pages);
$start=($max*$page)-$max;

if(count($total) == 0){
echo '<div class="alert alert-danger">Нет категорий!</div>';
}	

$query = DB::$the->query("SELECT * FROM `sel_category` order by `mesto` LIMIT $start, $max");
while($cat = $query->fetch()) {

$total = DB::$the->query("SELECT id_cat FROM `sel_subcategory` WHERE `id_cat` = '".$cat['id']."' ");
$total = $total->fetchAll();

$sel_keys = DB::$the->query("SELECT * FROM `sel_keys` WHERE `sale` = '1' and  id_cat = '".$cat['id']."'");
$sel_keys = $sel_keys->fetch(PDO::FETCH_ASSOC);

$oborot_gorod = DB::$the->query("SELECT SUM(`amount`) as `sum` FROM `sel_subcat` WHERE `id` = '{$sel_keys['id_cats']}'");
$oborot_gorod = $oborot_gorod->fetch(PDO::FETCH_ASSOC);

$sum = $oborot_gorod['sum'];

echo '<div class="card-box m-b-8">
                            <div class="table-box ">
                            <br/>
                                <div class="table-detail">
                                    <font color="green">#'.$cat['id'].' </font>
                                </div>

                                <div class="table-detail">
                                    <div class="member-info">
                                        <h4 class="m-t-0"><b><a href="../admin/subcategory.php?category='.$cat['id'].'">'.$cat['name'].'</a></b></h4>
                                        <p class="text-dark m-b-5"><b>Районы: </b><i class="glyphicon glyphicon-tags"></i>';
										$querys = DB::$the->query("SELECT * FROM `sel_cat` where `cat` = '{$cat['id']}'");
                                          while($subcats = $querys->fetch()) {
	                                           echo ' <span class="text-muted">'.$subcats['name'].'</span>, ';
                                          }
										echo'
<div class="table-detail lable-detail">
                                    <span class="label label-info">Товаров: '.count($total).'</span>
                                </div>


                                    </div>
                                </div>

                                

                                

                                <div class="table-detail table-actions-bar">
								    <a href="../admin/subcategory.php?cmd=createsubcats&category='.$cat['id'].'" class="table-action-btn"><i class="glyphicon glyphicon-plus-sign"></i></a>
                                    <a href="?cmd=edit&category='.$cat['id'].'" class="table-action-btn"><i class="md md-edit"></i></a>
                                    <a href="?cmd=delete&category='.$cat['id'].'&hash='.md5($cat['time']).'" class="table-action-btn"><i class="md md-close"></i></a>
                                </div>
                            </div>
                        </div>';
}

if ($pages>1) $My_Class->str('?',$pages,$page); 

?></div>  <!-- Todos app -->
                   <div class="col-lg-5">
                       <div class="card-box">
                            <h4 class="m-t-0 m-b-20 header-title"><b>Список фасовок</b></h4>
<div class="nicescroll mx-box" tabindex="5000" style="overflow: hidden; outline: none;">
                                <ul class="list-unstyled transaction-list m-r-5">
							                         
                               
                               <?php
							  
								
                               $query = DB::$the->query("SELECT * FROM `sel_subcat` order by `id`");
                               while($tr_cats = $query->fetch()) {
				                $tr_cat = DB::$the->query("SELECT * FROM `sel_subcategory` WHERE `id` = '".$tr_cats['id_subcat']."' ");
                                $tr_cat = $tr_cat->fetch(PDO::FETCH_ASSOC);

echo'<li><span class="tran-text text-success">#'.$tr_cats['id'].'</span>
<span class="tran-text">'.$tr_cats['name'].'</span>
<span class="text-muted">'.$tr_cat['name'].'</span>
<span class="pull-right text-muted">
<a href="../admin/subcategory.php?cmd=editcats&id='.$tr_cats['id'].'"> <span class="badge pull-right"><span class="glyphicon glyphicon-pencil"></span> </a>
                                        <a href="../admin/subcategory.php?cmd=deletcats&id='.$tr_cats['id'].'"> <span class="badge pull-right"><span class="glyphicon glyphicon-remove"></span> </a>
										</span>
                                        <span class="clearfix"></span>
                                    </li>';
							   }
                               ?>
							    </ul>
                            </div>
                        </div>

                      </div>
</div>
<div class="row">
                    
							   </tbody>
									   </table>
                        </div>

                      </div>
					  
                    
							   </tbody>
									   </table>
                        </div>

                      </div>
                </div>
<?
}

$My_Class->foot();
?>