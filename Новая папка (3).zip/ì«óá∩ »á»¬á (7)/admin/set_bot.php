<?php
ob_start();

require_once "../classes/My_Class.php";
require_once TPL."head.php";


if (!isset($_COOKIE['secretkey']) or $_COOKIE['secretkey'] != $secretkey) {
header("Location: index.php");		
exit;
}

if (!isset($_COOKIE['secretkey']) or $_COOKIE['secretkey'] != $secretkey) {
header("Location: index.php"); exit;
}

$My_Class->title("Настройки бота");
	
$row = DB::$the->query("SELECT * FROM `sel_set_bot` ");
$set = $row->fetch(PDO::FETCH_ASSOC);


$msg = '';
	if(!file_exists('install.lock')) {
         $msg = '<div class="alert alert-success "><b>Поздравляем!<br/>Telegram Bot был успешно установлен. Осталось совсем чуть-чуть укажите ниже токен BOT. <a href="https://t.me/BotFather">Где взять токен?</a></div>';
      
   }
	
	
if(isset($_GET['ok']) and isset($_POST['submit'])) {

if($_POST['token'] != ""  and $_POST['on_off'] != "") {
$token=$_POST['token'];

if(!file_exists('install.lock')) {
   $create_file = fopen("install.lock","w+");
	    echo $create_file;
		$beget_login =  conf::$api['login'];
		$beget_password = conf::$api['password'];
		$ip = conf::$api['ip'];
		$url = conf::$main['url'];
		$idshop = conf::$main['idshop'];
        $cro = urlencode("wget -O /dev/null https://{$url}/{$idshop}/cron.php");
        $cros = urlencode("wget -O /dev/null https://{$url}/{$idshop}/cron2.php");
		$crosi = urlencode("wget -O /dev/null https://{$url}/{$idshop}/cron3.php");
     //$add_cron = file_get_contents("https://api.beget.com/api/cron/add?login=$beget_login&passwd=$beget_password&input_format=json&output_format=json&input_data=%7B%22minutes%22%3A%22*%22%2C%22hours%22%3A%22*%22%2C%22days%22%3A%22*%22%2C%22months%22%3A%22*%22%2C%22weekdays%22%3A%22*%22%2C%22command%22%3A%22wget%20-O%20%5C%2Fdev%5C%2Fnull%20https%3A%5C%2F%5C%2F%20$url/$idshop/cron.php%22%7D"); // Получаем запрос от пользователя 
     $add_cron = file_get_contents("http://{$ip}/ispmgr?authinfo={$beget_login}:{$beget_password}&active=on&clicked_button=ok&command={$cro}&description={$idshop}&func=scheduler.edit&hideout=off&input_dmonth=*&input_dweek=*&input_hour=*&input_min=*&input_month=*&mailto=&month=month1&month_day=1&progressid=false&run_every=every_day&schedule_type=type_expert&sfrom=ajax&sok=ok&time_hour=0&time_min=0&wday0=off&wday1=off&wday2=off&wday3=off&wday4=off&wday5=off&wday6=on"); // Получаем запрос от пользователя
    $add_crons = file_get_contents("http://{$ip}/ispmgr?authinfo={$beget_login}:{$beget_password}&active=on&clicked_button=ok&command={$cros}&description={$idshop}&func=scheduler.edit&hideout=off&input_dmonth=*&input_dweek=*&input_hour=*&input_min=*/5&input_month=*&mailto=&month=month1&month_day=1&progressid=false&run_every=every_day&schedule_type=type_expert&sfrom=ajax&sok=ok&time_hour=0&time_min=0&wday0=off&wday1=off&wday2=off&wday3=off&wday4=off&wday5=off&wday6=on"); // Получаем запрос от пользователя
	$add_cronsi = file_get_contents("http://{$ip}/ispmgr?authinfo={$beget_login}:{$beget_password}&active=on&clicked_button=ok&command={$crosi}&description={$idshop}&func=scheduler.edit&hideout=off&input_dmonth=*&input_dweek=*&input_hour=*&input_min=*/5&input_month=*&mailto=&month=month1&month_day=1&progressid=false&run_every=every_day&schedule_type=type_expert&sfrom=ajax&sok=ok&time_hour=0&time_min=0&wday0=off&wday1=off&wday2=off&wday3=off&wday4=off&wday5=off&wday6=on"); // Получаем запрос от пользователя
if(strstr($add_cron, "basic")){
header("Location: ?"); exit;
}
	   sleep(3);
	}	 
	
	if($token != $set['token']){
		$url = conf::$main['url'];
		$idshop = conf::$main['idshop'];
		$idshop = conf::$main['idshop'];
	   $add_bot = file_get_contents("https://api.telegram.org/bot$token/setwebhook?url=https://$url/$idshop/bot.php"); // Получаем запрос от пользователя  
       echo $add_bot;
	}
$hello=$_POST['hello'];
$msg_help=$_POST['msg_help'];
$proxy=$_POST['proxy'];
$proxy_login=$_POST['proxy_login'];
$proxy_pass=$_POST['proxy_pass'];
$url=$_POST['url'];
$on_off=$_POST['on_off'];
$nomer1=$_POST['nomer1'];
$chatid=$_POST['chatid'];
$footer=$_POST['footer'];
$footerr=$_POST['footerr'];
$foto=$_POST['foto'];
$fotoqiwi=$_POST['fotoqiwi'];
$fotobtc=$_POST['fotobtc'];
$city1=$_POST['city1'];
$city2=$_POST['city2'];
$city3=$_POST['city3'];
$city4=$_POST['city4'];
$city5=$_POST['city5'];
$pole1=$_POST['pole1'];
$pole2=$_POST['pole2'];
$pole3=$_POST['pole3'];
$doppole1=$_POST['doppole1'];
$doppole2=$_POST['doppole2'];
$doppole3=$_POST['doppole3'];
$meny1=$_POST['meny1'];
$meny2=$_POST['meny2'];
$meny3=$_POST['meny3'];
$mendoppole1=$_POST['mendoppole1'];
$mendoppole2=$_POST['mendoppole2'];
$mendoppole3=$_POST['mendoppole3'];
$numberbtc=$_POST['numberbtc'];
$passwordbtc=$_POST['passwordbtc'];
$btc=$_POST['btc'];
$nikbota=$_POST['nikbota'];
$verification=$_POST['verification'];
$block=$_POST['block'];
$time_block=$_POST['time_block'];
$count_block=$_POST['count_block'];
$ban_block_time=$_POST['ban_block_time'];




DB::$the->prepare("UPDATE sel_set_bot SET token=? ")->execute(array("$token")); 
DB::$the->prepare("UPDATE sel_set_bot SET nikbota=? ")->execute(array("$nikbota")); 
DB::$the->prepare("UPDATE sel_set_bot SET hello=? ")->execute(array("$hello")); 
DB::$the->prepare("UPDATE sel_set_bot SET msg_help=? ")->execute(array("$msg_help")); 
DB::$the->prepare("UPDATE sel_set_bot SET proxy=? ")->execute(array("$proxy")); 
DB::$the->prepare("UPDATE sel_set_bot SET proxy_login=? ")->execute(array("$proxy_login")); 
DB::$the->prepare("UPDATE sel_set_bot SET proxy_pass=? ")->execute(array("$proxy_pass")); 
DB::$the->prepare("UPDATE sel_set_bot SET url=? ")->execute(array("$url")); 
DB::$the->prepare("UPDATE sel_set_bot SET nomer1=? ")->execute(array("$nomer1")); 
DB::$the->prepare("UPDATE sel_set_bot SET chatid=? ")->execute(array("$chatid")); 
DB::$the->prepare("UPDATE sel_set_bot SET on_off=? ")->execute(array("$on_off")); 
DB::$the->prepare("UPDATE sel_set_bot SET footer=? ")->execute(array("$footer")); 
DB::$the->prepare("UPDATE sel_set_bot SET footerr=? ")->execute(array("$footerr"));
DB::$the->prepare("UPDATE sel_set_bot SET foto=? ")->execute(array("$foto")); 
DB::$the->prepare("UPDATE sel_set_bot SET fotoqiwi=? ")->execute(array("$fotoqiwi")); 
DB::$the->prepare("UPDATE sel_set_bot SET fotobtc=? ")->execute(array("$fotobtc")); 
DB::$the->prepare("UPDATE sel_set_bot SET city1=? ")->execute(array("$city1")); 
DB::$the->prepare("UPDATE sel_set_bot SET city2=? ")->execute(array("$city2"));
DB::$the->prepare("UPDATE sel_set_bot SET city3=? ")->execute(array("$city3"));
DB::$the->prepare("UPDATE sel_set_bot SET city4=? ")->execute(array("$city4"));
DB::$the->prepare("UPDATE sel_set_bot SET city5=? ")->execute(array("$city5"));
DB::$the->prepare("UPDATE sel_set_bot SET pole1=? ")->execute(array("$pole1"));
DB::$the->prepare("UPDATE sel_set_bot SET pole2=? ")->execute(array("$pole2"));
DB::$the->prepare("UPDATE sel_set_bot SET pole3=? ")->execute(array("$pole3"));
DB::$the->prepare("UPDATE sel_set_bot SET doppole1=? ")->execute(array("$doppole1"));
DB::$the->prepare("UPDATE sel_set_bot SET doppole2=? ")->execute(array("$doppole2"));
DB::$the->prepare("UPDATE sel_set_bot SET doppole3=? ")->execute(array("$doppole3"));
DB::$the->prepare("UPDATE sel_set_bot SET meny1=? ")->execute(array("$meny1"));
DB::$the->prepare("UPDATE sel_set_bot SET meny2=? ")->execute(array("$meny2"));
DB::$the->prepare("UPDATE sel_set_bot SET meny3=? ")->execute(array("$meny3"));
DB::$the->prepare("UPDATE sel_set_bot SET mendoppole1=? ")->execute(array("$mendoppole1"));
DB::$the->prepare("UPDATE sel_set_bot SET mendoppole2=? ")->execute(array("$mendoppole2"));
DB::$the->prepare("UPDATE sel_set_bot SET mendoppole3=? ")->execute(array("$mendoppole3"));
DB::$the->prepare("UPDATE sel_set_bot SET numberbtc=? ")->execute(array("$numberbtc")); 
DB::$the->prepare("UPDATE sel_set_qiwi SET passwordbtc=? ")->execute(array("$passwordbtc")); 
DB::$the->prepare("UPDATE sel_set_bot SET btc=? ")->execute(array("$btc"));
DB::$the->prepare("UPDATE sel_set_bot SET verification=? ")->execute(array("$verification")); 
DB::$the->prepare("UPDATE sel_set_bot SET time_block=? ")->execute(array("$time_block"));  
DB::$the->prepare("UPDATE sel_set_bot SET count_block=? ")->execute(array("$count_block"));  
DB::$the->prepare("UPDATE sel_set_bot SET ban_block_time=? ")->execute(array("$ban_block_time"));  
DB::$the->prepare("UPDATE sel_set_bot SET block=? ")->execute(array("$block")); 


header("Location: ?");
}
else
{
$msg = 'Не все поля запонены!';
}
}

?>
<script type="text/javascript">  
 $(function() { 
    $(".btn").click(function(){
        $(this).button('loading').delay(3000).queue(function() {
            $(this).button('reset');
            $(this).dequeue();
        });        
    });
});  
</script>


 <h4 class="page-title">Настройки бота</h4>
<?php echo $msg; ?>
                      
               <br />
				
<form method="POST" action="?ok">
<div class="col-sm-12">
<div class="card-box">
<div class="input-group input-group-lg">
    <span class="input-group-addon"><font size="3">TOKEN</font></span>
    <input type="text" class="form-control" name="token" value="<?=$set['token'];?>">
	</div><br />
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Бот</font></span>
    <input type="text" class="form-control" name="nikbota" value="<?=$set['nikbota'];?>">
    </div><br />		
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Лого</font></span>
    <input type="text" class="form-control" name="foto" value="<?=$set['foto'];?>">
    </div><br />		
<div class="input-group">	
	<span class="input-group-addon"><font size="3">Приветствие</font></span>
<textarea class="form-control" name="hello" rows="3"><?=$set['hello'];?></textarea>	
    </div><br />
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Антифлуд</font></span>
    <input type="text" class="form-control" name="verification" value="<?=$set['verification'];?>">
 <span class="input-group-addon"><font size="3">	сек.</font></span>
    </div><br />
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Резерв оплаты</font></span>
    <input type="text" class="form-control" name="block" value="<?=$set['block'];?>">
 <span class="input-group-addon"><font size="3">мин.</font></span>
    </div><br />	
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Резерв товара</font></span>
    <input type="text" class="form-control" name="time_block" value="<?=$set['time_block'];?>">
 <span class="input-group-addon"><font size="3">мин.</font></span>
    </div><br />		
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3"><font size="3">Резерва бана</font></font></span>
    <input type="text" class="form-control" name="count_block" value="<?=$set['count_block'];?>">
 <span class="input-group-addon"><font size="3">мин.</font></span>
    </div><br />
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3"><font size="3">Блок. отмены заказа</font> </font></span>
    <input type="text" class="form-control" name="ban_block_time" value="<?=$set['ban_block_time'];?>">
 <span class="input-group-addon"><font size="3">мин. </font></span>
    </div><br />		
<div class="input-group">	
	<span class="input-group-addon"><font size="3">Помошь</font></span>
<textarea class="form-control" name="msg_help" rows="3"><?=$set['msg_help'];?></textarea>	
    </div><br />	
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Фото Qiwi</font></span>
    <input type="text" class="form-control" name="fotoqiwi" value="<?=$set['fotoqiwi'];?>">
    </div><br />
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Фото Bitcoin</font></span>
    <input type="text" class="form-control" name="fotobtc" value="<?=$set['fotobtc'];?>">
    </div><br />	
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Адрес сайта (с https://)</font></span>
    <input type="text" class="form-control" name="url" value="<?=$set['url'];?>">
    </div><br />	
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Поле №1</font></span>
    <input type="text" class="form-control" name="pole1" value="<?=$set['pole1'];?>">
    </div><br />		
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Поле №2</font></span>
    <input type="text" class="form-control" name="pole2" value="<?=$set['pole2'];?>">
    </div><br />			
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Поле №3</font></span>
    <input type="text" class="form-control" name="pole3" value="<?=$set['pole3'];?>">
    </div><br />				
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Доп.Поле №1</font></span>
    <input type="text" class="form-control" name="doppole1" value="<?=$set['doppole1'];?>">
    </div><br />				
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Доп.Поле №2</font></span>
    <input type="text" class="form-control" name="doppole2" value="<?=$set['doppole2'];?>">
    </div><br />		
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Доп.Поле №3</font></span>
    <input type="text" class="form-control" name="doppole3" value="<?=$set['doppole3'];?>">
    </div><br />		
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Меню №1</font></span>
    <input type="text" class="form-control" name="meny1" value="<?=$set['meny1'];?>">
    </div><br />		
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Меню №2</font></span>
    <input type="text" class="form-control" name="meny2" value="<?=$set['meny2'];?>">
    </div><br />	
<div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Меню №3</font></span>
    <input type="text" class="form-control" name="meny3" value="<?=$set['meny3'];?>">
    </div><br />	
<div class="input-group">	
	<span class="input-group-addon"><font size="3">Текст Поле №1</font></span>
    <textarea class="form-control" name="city3" rows="3"><?=$set['city3'];?></textarea>
    </div><br />		
<div class="input-group">	
	<span class="input-group-addon"><font size="3">Текст Поле №2</font></span>
    <textarea class="form-control" name="city4" rows="3"><?=$set['city4'];?></textarea>
    </div><br />		
<div class="input-group">	
	<span class="input-group-addon"><font size="3">Текст Поле №3</font></span>
    <textarea class="form-control" name="city5" rows="3"><?=$set['city5'];?></textarea>
    </div><br />				
<div class="input-group">	
	<span class="input-group-addon"><font size="3">Текст Доп.Поле №1</font></span>
<textarea class="form-control" name="mendoppole1" rows="3"><?=$set['mendoppole1'];?></textarea>	
    </div><br />		
<div class="input-group">	
	<span class="input-group-addon"><font size="3">Текст Доп.Поле №2</font></span>
<textarea class="form-control" name="mendoppole2" rows="3"><?=$set['mendoppole2'];?></textarea>	
    </div><br />
<div class="input-group">	
	<span class="input-group-addon"><font size="3">Текст Доп.Поле №3</font></span>
<textarea class="form-control" name="mendoppole3" rows="3"><?=$set['mendoppole3'];?></textarea>	
    </div><br />	
<div class="input-group">	
	<span class="input-group-addon"><font size="3">Текст Меню №1</font></span>
<textarea class="form-control" name="footerr" rows="3"><?=$set['footerr'];?></textarea>	
    </div><br />	
<div class="input-group">	
	<span class="input-group-addon"><font size="3">Текст Меню №2</font></span>
<textarea class="form-control" name="footer" rows="3"><?=$set['footer'];?></textarea>	
    </div><br />
<div class="input-group">	
	<span class="input-group-addon"><font size="3">Текст Меню №3</font></span>
    <textarea class="form-control" name="city1" rows="3"><?=$set['city1'];?></textarea>
   </div><br />
  <hr>  
 <div class="input-group input-group-lg">	
	<span class="input-group-addon"><font size="3">Состояние бота вкл(on) выкл(off)</font></span>
    <input type="text" class="form-control" name="on_off" value="<?=$set['on_off'];?>">
    </div><br />   
<hr>
<button type="submit" name="submit" data-loading-text="Сохраняю" class="btn btn-danger btn-lg btn-block">Сохранить</button></form>
</div>
</div>

<?

$My_Class->foot();
?>