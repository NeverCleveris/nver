<?php
ob_start();

require_once "../classes/My_Class.php";
require_once TPL."head.php";


if (!isset($_COOKIE['secretkey']) or $_COOKIE['secretkey'] != $secretkey) {
header("Location: index.php"); exit;
}

$row = DB::$the->query("SELECT * FROM `sel_category` WHERE `id` = '".intval($_GET['category'])."'");
$cat = $row->fetch(PDO::FETCH_ASSOC);

$My_Class->title("Категория: ".$cat['name']);

if(isset($_GET['category'])){
$header = DB::$the->query("SELECT id FROM `sel_category` WHERE `id` = '".intval($_GET['category'])."' ");
$header = $header->fetchAll();
if(count($header) == 0){
header("Location: index.php"); exit;
}}	

if(isset($_GET['subcategory'])){
$header = DB::$the->query("SELECT id FROM `sel_subcategory` WHERE `id` = '".intval($_GET['subcategory'])."' ");
$header = $header->fetchAll();
if(count($header) == 0){
header("Location: index.php"); exit;
}}	
?>
<script type="text/javascript">  
 $(function() { 
    $(".btn").click(function(){
        $(this).button('loading').delay(3000).queue(function() {
            $(this).button('reset');
            $(this).dequeue();
        });        
    });
});  
</script>
<?

if(isset($_GET['cmd'])){$cmd = htmlspecialchars($_GET['cmd']);}else{$cmd = '0';}

if(isset($_GET['category'])){$category = abs(intval($_GET['category']));}else{$category = '0';}
if(isset($_GET['subcategory'])){$subcategory = abs(intval($_GET['subcategory']));}else{$subcategory = '0';}

switch ($cmd){
	case 'catsall':
?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>   <li class="active">Управление фасовками</li>
</ol>
<div class="list-group">
<a class="list-group-item" href="../admin/subcategory.php?cmd=createcats">
<span class="glyphicon glyphicon-plus-sign"></span>Создать Фасовку
</a>
</div>
<?


$total = DB::$the->query("SELECT * FROM `sel_subcat`");
$total = $total->fetchAll();
$max = 5;
$pages = $My_Class->k_page(count($total),$max);
$page = $My_Class->page($pages);
$start=($max*$page)-$max;

if(count($total) == 0){
echo '<div class="alert alert-danger">В данной категории нет разделов!</div>';
}	

echo '<div class="list-group">';
$query = DB::$the->query("SELECT * FROM `sel_subcat` order by `id` LIMIT $start, $max");
while($subcats = $query->fetch()) {
	
$cat = DB::$the->query("SELECT * FROM `sel_subcategory` WHERE `id` = '{$subcats['id_subcat']}'");
$cat = $cat->fetch(PDO::FETCH_ASSOC);


	
echo '<span class="list-group-item"><font color="green"># '.$subcats['id'].'</font>
<a href="subcategory.php?category='.$cat['id'].'&subcategory='.$subcats['id_subcat'].'"><b>'.$subcats['name'].' [Товар: '.$cat['name'].', Цена: '.$subcats['amount'].' RUB]</b></a>';
echo '<a href="?cmd=editcats&id='.$subcats['id'].'"> <span class="badge pull-right"><span class="glyphicon glyphicon-pencil"></span> </a>';
echo '<a href="?cmd=deletcats&id='.$subcats['id'].'"> <span class="badge pull-right"><span class="glyphicon glyphicon-remove"></span> </a>';
echo '</span>';
}
echo '</div>';

if ($pages>1) $My_Class->str('?cmd=catsall&',$pages,$page); 
	
break;
	
	
case 'editcats':

$id = $_GET['id'];

$cats = DB::$the->query("SELECT * FROM `sel_subcat` WHERE `id` = '{$id}'");
$cats = $cats->fetch(PDO::FETCH_ASSOC);

if(isset($_POST['edit'])) {

if($_POST['name'] != "") {
$name=$_POST['name'];
$img=$_POST['img'];
$amount=$_POST['amount'];


DB::$the->prepare("UPDATE sel_subcat SET img=? WHERE id=? ")->execute(array($img, $id));
DB::$the->prepare("UPDATE sel_subcat SET name=? WHERE id=? ")->execute(array($name, $id)); 
DB::$the->prepare("UPDATE sel_subcat SET id_subcat=? WHERE id=? ")->execute(array($_POST['id_subcat'], $id)); 
DB::$the->prepare("UPDATE sel_subcat SET amount=? WHERE id=? ")->execute(array($amount, $id)); 


header("Location: ?cmd=catsall");
}
else
{
echo '<div class="alert alert-danger">Не заполнены все поля!</div>';
}
}

?>

<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>   <li><a href="?cmd=catsall">Управление Фасовками</a></li>
  <li class="active">Редактирование фасовки: <?=$cats['name'];?></li>
</ol>

<form action="?cmd=editcats&id=<?=$id?>" method="POST">
<div class="form-group col-sm-8">
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-pencil"></span> </span>
<input type="text" placeholder="<?=$cats['name']?>" class="form-control" name="name" value="<?=$cats['name']?>">
</div><br />
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-usd"></span> </span>
<input type="text" placeholder="<?=$cats['amount']?>" class="form-control" name="amount" value="<?=$cats['amount']?>">
</div><br />
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-camera"></span> </span>
<input type="text" placeholder="<?=$cats['img']?>" class="form-control" name="img" value="<?=$cats['img']?>">
</div><br />
Выберите Товар:<br />
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-pencil"></span> </span>
<select style="color: black;" class="form-control"  name="id_subcat" value="<?=$cats['id_subcat']?>">
<?
$query = DB::$the->query("SELECT * FROM `sel_subcategory` order by `id` ");
     while($cats = $query->fetch()) {
	  echo "<option value='{$cats['id']}'>{$cats['name']}</option>";
	   
 }

?>
</select></div><br />




<button type="submit" name="edit" class="btn btn-danger btn-lg btn-block" data-loading-text="Изменяю">Изменить</button>
</div></form>
<?
break;	
	case 'createcats':

?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>    <li><a href="?cmd=catsall">Управление фасовками</a></li>
   <li class="active">Создание Фасовки</li>
</ol>
<?


if(isset($_POST['create'])) {
	
	
if($_POST['name'] != "" and $_POST['amount'] != "") {
$name=$_POST['name'];

$params = array('name' => $name, 'id_subcat' => $_POST['id_subcat'], 'amount' => $_POST['amount']);  
 
$q= DB::$the->prepare("INSERT INTO `sel_subcat` (name, id_subcat, amount) VALUES (:name, :id_subcat, :amount)");  
$q->execute($params);


header("Location: ?cmd=catsall");
}
else
{
echo '<div class="alert alert-danger">Не заполнены все поля!</div>';
}
}


?>
<form action="?cmd=createcats&create" method="POST">
<div class="form-group col-sm-8">
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-pencil"></span> </span>
<input type="text" placeholder="Наименование фасовки" class="form-control" name="name">
</div><br />
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-usd"></span> </span>
<input type="text" placeholder="Цена за вес RUB" class="form-control" name="amount">
</div><br />
Выберите Товар:<br />
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-pencil"></span> </span>
<select style="color: black;" class="form-control"  name="id_subcat">








<?
$query = DB::$the->query("SELECT * FROM `sel_subcategory` order by `id` ");
     while($cats = $query->fetch()) {
	  echo "<option value='{$cats['id']}'>{$cats['name']}</option>";
	   
 }

?>


</select></div><br />








<button type="submit" name="create" class="btn btn-danger btn-lg btn-block" data-loading-text="Создаю">Создать</button></form>





</div></form>








<?

break;

case 'deletcats':	
$row = DB::$the->query("SELECT name FROM `sel_subcat` WHERE `id` = '{$_GET['id']}'");
$subcat = $row->fetch(PDO::FETCH_ASSOC);
?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>  <li class="active">Удаление фасовки: <b><?=$subcat['name'];?></b></li>
</ol>
<div class="alert alert-danger">Будут удалены все адреса из данного раздела!</div>

<div class="btn-group">
  <button type="button" class="btn btn-danger dropdown-toggle" data-loading-text="Думаем" data-toggle="dropdown">Вы уверены? <span class="caret"></span></button>
  <ul class="dropdown-menu" role="menu">
    <li><a href="?cmd=deletcats&id=<?=$_GET['id'];?>&ok">Да, удалить</a></li>
    <li class="divider"></li>
    <li><a href="?cmd=catsall">Нет, отменить</a></li>
  </ul>
</div><br /><br />
<?


if(isset($_GET['ok'])) {
DB::$the->query("DELETE FROM `sel_subcat` WHERE `id` = {$_GET['id']} ");
DB::$the->query("DELETE FROM `sel_keys` WHERE `id_cats` = {$_GET['id']} ");

header("Location: ?cmd=catsall");
}

break;
	
	/*  */
case 'subcatsall':
?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>   <li class="active">Все районы</li>
</ol>
<div class="list-group">
<a class="list-group-item" href="../admin/category.php">
<span class="glyphicon glyphicon-plus-sign"></span>Создать Район
</a>
</div>
<?


$total = DB::$the->query("SELECT * FROM `sel_cat`");
$total = $total->fetchAll();
$max = 5;
$pages = $My_Class->k_page(count($total),$max);
$page = $My_Class->page($pages);
$start=($max*$page)-$max;

if(count($total) == 0){
echo '<div class="alert alert-danger">В данной категории нет разделов!</div>';
}	

echo '<div class="list-group">';
$query = DB::$the->query("SELECT * FROM `sel_cat` order by `id` LIMIT $start, $max");
while($subcats = $query->fetch()) {
	
$cat = DB::$the->query("SELECT * FROM `sel_category` WHERE `id` = '{$subcats['cat']}'");
$cat = $cat->fetch(PDO::FETCH_ASSOC);


	
echo '<span class="list-group-item"><font color="green"># '.$subcats['id'].'</font>
<a href="?cmd=subcatsall&category='.$category.'"><b>'.$subcats['name'].' [ '.$cat['name'].' ]</b></a>';
echo '<a href="?cmd=editsubcats&id='.$subcats['id'].'"> <span class="badge pull-right"><span class="glyphicon glyphicon-pencil"></span> </a>';
echo '<a href="?cmd=deletsubcats&id='.$subcats['id'].'"> <span class="badge pull-right"><span class="glyphicon glyphicon-remove"></span> </a>';
echo '</span>';
}
echo '</div>';

if ($pages>1) $My_Class->str('?cmd=subcatsall&',$pages,$page); 
	
break;
	
case 'createsubcats':

?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>  <li><a href="subcategory.php?category=<?=$category;?>"><?=$cat['name'];?></a</li>
    <li><a href="?cmd=subcatsall&category=<?=$category;?>">Все районы</a></li>
   <li class="active">Создание района</li>
</ol>
<?


if(isset($_POST['create'])) {

if($_POST['name'] != "" ){
$name = $_POST['name'];


$subcats = DB::$the->query("SELECT * FROM `sel_cat` WHERE `cat` = '{$category}' order by `id` DESC limit 1 ");
$subcats = $subcats->fetch(PDO::FETCH_ASSOC);

$params = array('name' => $name, 'cat' => $category, 'time' => time());  
 
$q= DB::$the->prepare("INSERT INTO `sel_cat` (name, cat, time) VALUES (:name, :cat, :time)");  
$q->execute($params);

header("Location: ?category={$category}");
}
else
{
echo '<div class="alert alert-danger">Не заполнены все поля!</div>';
}
}


?>
<form action="?cmd=createsubcats&category=<?=$category?>" method="POST">
<div class="form-group col-sm-8">
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-pencil"></span> </span>
<input type="text" placeholder="Название района" class="form-control" name="name">
</div><br />
<button type="submit" name="create" class="btn btn-danger btn-lg btn-block" data-loading-text="Создаю">Создать</button></form>
</div>
<?

break;
case 'editsubcats':
?>

<?
	
$id = $_GET['id'];

$cats = DB::$the->query("SELECT * FROM `sel_cat` WHERE `id` = '{$id}'");
$cats = $cats->fetch(PDO::FETCH_ASSOC);

if(isset($_POST['edit'])) {

if($_POST['name'] != "") {
$name=$_POST['name'];
$img=$_POST['img'];

DB::$the->prepare("UPDATE sel_cat SET img=? WHERE id=? ")->execute(array($img, $id)); 
DB::$the->prepare("UPDATE sel_cat SET name=? WHERE id=? ")->execute(array($name, $id)); 
DB::$the->prepare("UPDATE sel_cat SET cat=? WHERE id=? ")->execute(array($_POST['cat'], $id)); 

header("Location: ?cmd=subcatsall");
}
else
{
echo '<div class="alert alert-danger">Не заполнены все поля!</div>';
}
}

?>

<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>   <li><a href="?cmd=subcatsall">Управление районами</a></li>
  <li class="active">Редактирование района: <?=$cats['name'];?></li>
</ol>

<form action="?cmd=editsubcats&id=<?=$id?>" method="POST">
<div class="form-group col-sm-8">
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-pencil"></span> </span>
<input type="text" placeholder="<?=$cats['name']?>" class="form-control" name="name" value="<?=$cats['name']?>">
</div><br />
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-camera"></span> </span>
<input type="text" placeholder="<?=$cats['img']?>" class="form-control" name="img" value="<?=$cats['img']?>">
</div><br />
Выберите город:<br />
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-pencil"></span> </span>
<select style="color: black;" class="form-control"  name="cat" value="<?=$cats['cat']?>">
<?
$query = DB::$the->query("SELECT * FROM `sel_category` order by `id` ");
     while($cats = $query->fetch()) {
	  echo "<option value='{$cats['id']}'>{$cats['name']}</option>";
	   
 }

?>
</select></div><br />
<button type="submit" name="edit" class="btn btn-danger btn-lg btn-block" data-loading-text="Изменяю">Изменить</button>
</div></form>
<?
break;


case 'deletsubcats':	
$row = DB::$the->query("SELECT name FROM `sel_cat` WHERE `id` = '{$_GET['id']}'");
$subcat = $row->fetch(PDO::FETCH_ASSOC);
?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>  <li class="active">Удаление Района: <b><?=$subcat['name'];?></b></li>
</ol>
<div class="alert alert-danger">Будут удалены все адреса из данного раздела!</div>

<div class="btn-group">
  <button type="button" class="btn btn-danger dropdown-toggle" data-loading-text="Думаем" data-toggle="dropdown">Вы уверены? <span class="caret"></span></button>
  <ul class="dropdown-menu" role="menu">
    <li><a href="?cmd=deletsubcats&id=<?=$_GET['id'];?>&ok">Да, удалить</a></li>
    <li class="divider"></li>
    <li><a href="?category=<?=$category;?>">Нет, отменить</a></li>
  </ul>
</div><br /><br />
<?


if(isset($_GET['ok'])) {
DB::$the->query("DELETE FROM `sel_cat` WHERE `id` = {$_GET['id']} ");
DB::$the->query("DELETE FROM `sel_keys` WHERE `id_subcats` = {$_GET['id']} ");

header("Location: ?cmd=subcatsall");
}

break;

break;
 	case 'create':

?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>  <li><a href="subcategory.php?category=<?=$category;?>"><?=$cat['name'];?></a></li>
   <li><a href="?cmd=subcatsall&category=<?=$category;?>">Управление районами</a></li>
  <li class="active">Создание раздела</li>
</ol>
<?

if(isset($_POST['create'])) {

if($_POST['subcat'] != "" and $_POST['amount'] != "") {
$subcat=$_POST['subcat'];
$amount=$_POST['amount'];

$cat_m = DB::$the->query("SELECT mesto FROM `sel_subcategory` WHERE `id_cat` = {$category} order by `mesto` DESC limit 1 ");
$cat_m = $cat_m->fetch(PDO::FETCH_ASSOC);
$mesto = $cat_m['mesto']+1;

$params = array('name' => $subcat, 'amount' => $amount, 'id_cat' => $category, 'time' => time(), 'mesto' => $mesto);  
 
$q= DB::$the->prepare("INSERT INTO `sel_subcategory` (name, amount, id_cat, time, mesto) VALUES (:name,:amount, :id_cat, :time, :mesto)");  
$q->execute($params);

header("Location: ?category=$category");
}
else
{
echo '<div class="alert alert-danger">Не заполнены все поля!</div>';
}
}

?>
<form action="?cmd=create&category=<?=$category?>" method="POST">
<div class="form-group col-sm-8">
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-pencil"></span> </span>
<input type="text" placeholder="Название раздела" class="form-control" name="subcat">
</div><br />
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-usd"></span> </span>
<input type="text" placeholder="Цена ключей" class="form-control" name="amount">
</div><br />
<button type="submit" name="create" class="btn btn-danger btn-lg btn-block" data-loading-text="Создаю">Создать</button></form>
</div>
<?

break;
 	
case 'edit':
?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>  <li><a href="subcategory.php?category=<?=$category;?>"><?=$cat['name'];?></a></li>
  <li class="active">Редактирование раздела</li>
</ol>
<?	
$row = DB::$the->query("SELECT * FROM `sel_subcategory` WHERE `id` = {$subcategory} and `id_cat` = {$category}");
$subcat = $row->fetch(PDO::FETCH_ASSOC);

// Редактирование раздел
if(isset($_POST['edit'])) {

if($_POST['name'] != "" and $_POST['amount'] != "") {
$name=$_POST['name'];
$amount=$_POST['amount'];
$mesto=intval($_POST['mesto']);
$img=$_POST['img'];

DB::$the->prepare("UPDATE sel_subcategory SET img=? WHERE id=? ")->execute(array("$img", $subcategory)); 
DB::$the->prepare("UPDATE sel_subcategory SET name=? WHERE id=? ")->execute(array("$name", $subcategory)); 
DB::$the->prepare("UPDATE sel_subcategory SET amount=? WHERE id=? ")->execute(array("$amount", $subcategory)); 
DB::$the->prepare("UPDATE sel_subcategory SET mesto=? WHERE id=? ")->execute(array("$mesto", $subcategory)); 



header("Location: ?category=$category");
}
else
{
echo '<div class="alert alert-danger">Не заполнены все поля!</div>';
}
}


?>
<form action="?cmd=edit&category=<?=$category?>&subcategory=<?=$subcategory?>" method="POST" enctype="multipart/form-data">
<div class="form-group col-sm-8">
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-pencil"></span> </span>
<input type="text" placeholder="<?=$subcat['name']?>" class="form-control" name="name" value="<?=$subcat['name']?>">
</div><br />
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-usd"></span> </span>
<input type="text" placeholder="<?=$subcat['amount']?>" class="form-control" name="amount" value="<?=$subcat['amount']?>">
</div><br />
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-flag"></span> </span>
<input type="text" placeholder="<?=$subcat['mesto']?>" class="form-control" name="mesto" value="<?=$subcat['mesto']?>">
</div><br />
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-camera"></span> </span>
<input type="text" placeholder="<?=$cats['img']?>" class="form-control" name="img" value="<?=$subcat['img']?>">
</div><br />

<button type="submit" name="edit" class="btn btn-danger btn-lg btn-block" data-loading-text="Изменяю">Изменить</button>
</div></form>
<?

	
break;

case 'delete':	
$row = DB::$the->query("SELECT name FROM `sel_subcategory` WHERE `id` = {$subcategory} and `id_cat` = {$category}");
$subcat = $row->fetch(PDO::FETCH_ASSOC);
?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>  <li><a href="subcategory.php?category=<?=$category;?>"><?=$cat['name'];?></a></li>
  <li class="active">Удаление раздела: <b><?=$subcat['name'];?></b></li>
</ol>
<div class="alert alert-danger">Будут удалены все ключи из данного раздела!</div>

<div class="btn-group">
  <button type="button" class="btn btn-danger dropdown-toggle" data-loading-text="Думаем" data-toggle="dropdown">Вы уверены? <span class="caret"></span></button>
  <ul class="dropdown-menu" role="menu">
    <li><a href="?cmd=delete&category=<?=$category;?>&subcategory=<?=$subcategory;?>&ok">Да, удалить</a></li>
    <li class="divider"></li>
    <li><a href="?category=<?=$category;?>">Нет, отменить</a></li>
  </ul>
</div><br /><br />
<?


if(isset($_GET['ok'])) {
DB::$the->query("DELETE FROM `sel_subcategory` WHERE `id` = {$subcategory} ");
DB::$the->query("DELETE FROM `sel_keys` WHERE `id_subcat` = {$subcategory} ");

header("Location: ?category=$category");
}

break;
	
default:

?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>  <li><a href="category.php">Категории</a></li>
  <li class="active"><?=$cat['name'];?></li>
</ol>

<div class="list-group">
<a class="list-group-item" href="?cmd=create&category=<?=$category;?>">
<span class="glyphicon glyphicon-plus-sign"></span> Создать раздел
</a>
</div>
<div class="list-group">
<a class="list-group-item" href="?cmd=createsubcats&category=<?=$category;?>">
<span class="glyphicon glyphicon-plus-sign"></span>Создать Район
</a>
</div>
<?


$total = DB::$the->query("SELECT * FROM `sel_subcategory` where `id_cat` = {$category} ");
$total = $total->fetchAll();
$max = 5;
$pages = $My_Class->k_page(count($total),$max);
$page = $My_Class->page($pages);
$start=($max*$page)-$max;

if(count($total) == 0){
echo '<div class="alert alert-danger">В данной категории нет разделов!</div>';
}	

echo '<div class="list-group">';
$query = DB::$the->query("SELECT * FROM `sel_subcategory` where `id_cat` = {$category} order by `mesto` LIMIT $start, $max");
while($cat = $query->fetch()) {
$total = DB::$the->query("SELECT id_subcat FROM `sel_keys` WHERE `id_subcat` = {$cat[id]} ");
$total = $total->fetchAll();
	
echo '<span class="list-group-item"><font color="green">['.$cat['mesto'].'] </font>
<a href="key.php?category='.$category.'&subcategory='.$cat['id'].'"><b>'.$cat['name'].'</b></a> ('.count($total).')';
echo '<a href="?cmd=edit&category='.$category.'&subcategory='.$cat['id'].'"> <span class="badge pull-right"><span class="glyphicon glyphicon-pencil"></span> </a>';
echo '<a href="?cmd=delete&category='.$category.'&subcategory='.$cat['id'].'"> <span class="badge pull-right"><span class="glyphicon glyphicon-remove"></span> </a>';
echo '</span>';
}
echo '</div>';

if ($pages>1) $My_Class->str('?category='.$category.'&',$pages,$page); 

}

$My_Class->foot();
?>