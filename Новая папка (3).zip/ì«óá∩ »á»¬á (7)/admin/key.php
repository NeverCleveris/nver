<?php
ob_start();

require_once "../classes/My_Class.php";
require_once TPL."head.php";


if (!isset($_COOKIE['secretkey']) or $_COOKIE['secretkey'] != $secretkey) {
header("Location: index.php");		
exit;
}

$row = DB::$the->query("SELECT * FROM `sel_category` WHERE `id` = '".intval($_GET['category'])."'");
$cat = $row->fetch(PDO::FETCH_ASSOC);

$row = DB::$the->query("SELECT * FROM `sel_subcategory` WHERE `id` = '".intval($_GET['subcategory'])."'");
$subcat = $row->fetch(PDO::FETCH_ASSOC);

$My_Class->title("Подкатегория: ".$subcat['name']);


if(isset($_GET['category'])){
$header = DB::$the->query("SELECT id FROM `sel_category` WHERE `id` = '".intval($_GET['category'])."' ");
$header = $header->fetchAll();
if(count($header) == 0){
header("Location: index.php"); exit;
}}	

if(isset($_GET['subcategory'])){
$header = DB::$the->query("SELECT id FROM `sel_subcategory` WHERE `id` = '".intval($_GET['subcategory'])."' ");
$header = $header->fetchAll();
if(count($header) == 0){
header("Location: index.php"); exit;
}}	
?>

<?

if(isset($_GET['cmd'])){$cmd = htmlspecialchars($_GET['cmd']);}else{$cmd = '0';}

if(isset($_GET['category'])){$category = abs(intval($_GET['category']));}else{$category = '0';}
if(isset($_GET['subcategory'])){$subcategory = abs(intval($_GET['subcategory']));}else{$subcategory = '0';}
if(isset($_GET['key'])){$key = abs(intval($_GET['key']));}else{$key = '0';}

switch ($cmd){

case 'create':

?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>  <li><a href="subcategory.php?category=<?=$category;?>"><?=$cat['name'];?></a></li>
  <li><a href="key.php?category=<?=$category;?>&subcategory=<?=$subcategory;?>"><?=$subcat['name'];?></a></li>
  <li class="active">Добавление Адресов</li>
</ol>
<?

if(isset($_POST['create_all'])) {
  if ($_POST['key'] != "") {
    $code = $_POST['key'];
	$arrAD = ['key' => 'code'];
	$arrAD[]='key';
	foreach(explode("\n",$code)as$key){
		$key = htmlspecialchars($key);
		$key = trim($key);
		if(($key = htmlspecialchars(trim( $key)))!= ''){
			$str_search = array("#\[img\](.*?\.(?:jpg|jpeg|gif|png|bmp))\[\/img\]#is",);
			$str_replace = array("".SITEDIR."/style/images/keys/\\1",);
			$key = preg_replace($str_search, $str_replace, $key);
			$params = array('code' => $key, 'id_cat' => $category, 'id_cats' => $_POST['subcats'], 'id_subcats' => $_POST['cats'], 'id_subcat' => $subcategory, 'time' => time(), 'sale' => 0);
			$q = DB::$the->prepare("INSERT INTO `sel_keys` (code, id_cat, id_cats, id_subcats, id_subcat, time, sale) VALUES (:code, :id_cat, :id_cats, :id_subcats, :id_subcat, :time, :sale)");
			$q->execute($params);}
			$ph = DB::$the->query("SELECT id FROM `sel_keys` order by `id` DESC "); $ph = $ph->fetch(PDO::FETCH_ASSOC);}
             header("Location: ?category=$category&subcategory=$subcategory");
  }
}



echo '
<script type="text/javascript">
	$(function(){
		var btnUpload=$(\'#upload\');
		var status=$(\'#status\');
		new AjaxUpload(btnUpload, {
			action: \'../admin/ajax.php?mod=uploadsimg\',
			name: \'uploadfile\',
			onSubmit: function(file, ext){
				 if (! (ext && /^(bmp|jpg|png|jpeg|gif)$/.test(ext))){  
                    // extension is not allowed 
					status.text(\'Поддерживаемые форматы bmp, jpg, jpeg, png, gif\');
					return false;
				}
				status.text(\'Загрузка...\');
			},
			onComplete: function(file, response){
				//On completion clear the status
				status.text(\'\');
				//Add uploaded file to list
				if(response==="success"){
					$(\'<li></li>\').appendTo(\'#files\').html(\'<img src="../style/images/keys/\'+file+\'" alt=""><br>\'+file).addClass(\'success\');
				} else{
					$(\'<li></li>\').appendTo(\'#files\').text(\'Файл не загружен!\' + file).addClass(\'error\');
				}
			}
		});
		
	});
</script>
<section class="widget">
<div class="alert alert-info">
              <button type="button" class="close" data-dismiss="alert">x</button><br>
              <strong>Внимание!</strong> Каждый адрес вводите с новой строки, Что бы добавить фотографию ниже загрузите и в нужном месте укажите<br/><b> [img]название нужной фотографи[/img]</b>
</div>
			
<form action="?cmd=create&category='.$category.'&subcategory='.$subcategory.'" method="POST" enctype="multipart/form-data">

<div class="form-group ">
  <label for="all_address">Массовое добавление</label>
<div class="input-group">
<div class="form-group">
  <textarea  name="key" class="form-control"  cols="160" rows="5" placeholder="Каждый адрес с новой строки" required="required"></textarea>
</div>
</div><br/>

<div  style="margin: 0;margin-bottom: 10px;">

Выберите район:<select class="form-control"  name="cats">';
$query = DB::$the->query("SELECT * FROM `sel_cat` WHERE `cat` = '{$category}' order by `id` ");
     while($cats = $query->fetch()) {
	  echo '<option value="'.$cats["id"].'">'.$cats["name"].'</option>';
	   
 }
echo'</select></div>

<div  style="margin: 0;margin-bottom: 10px;">
Выберите Фасовку:<select class="form-control" name="subcats">';
$query = DB::$the->query("SELECT * FROM `sel_subcat` WHERE `id_subcat` = '{$subcategory}' order by `id` ");
     while($cat = $query->fetch()) {
	  echo '<option value="'.$cat['id'].'">'.$cat['name'].'</option>';
	   
 }
echo'</select></div><br /><div id="upload"><span>Выбрать файл<span></div><span id="status"></span>
	<div  style="margin: 0;margin-bottom: 10px;">	
<ul id="files"></ul>
</div><br /> <button type="submit" name="create_all" class="btn btn-default btn-lg btn-block" data-loading-text="Добавляю">Добавить</button></form></div></section></div></div>';


break;
 
case 'edit':
?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>  <li><a href="subcategory.php?category=<?=$category;?>"><?=$cat['name'];?></a></li>
  <li><a href="key.php?category=<?=$category;?>&subcategory=<?=$subcategory;?>"><?=$subcat['name'];?></a></li>
  <li class="active">Редактирование Адреса</li>
</ol>
<?	
$key_edit = DB::$the->query("SELECT code FROM `sel_keys` WHERE `id` = {$key} and `id_subcat` = {$subcategory}");
$key_edit = $key_edit->fetch(PDO::FETCH_ASSOC);

if(isset($_POST['edit'])) {

if($_POST['key'] != "") {
$code=$_POST['key'];

DB::$the->prepare("UPDATE sel_keys SET code=? WHERE id=? ")->execute(array("$code", $key)); 

header("Location: ?category=$category&subcategory=$subcategory");
}
else
{
echo '<div class="alert alert-danger">Не введен Адрес!</div>';
}
}


echo '<form action="?cmd=edit&category='.$category.'&subcategory='.$subcategory.'&key='.$key.'" method="POST">
<div class="form-group col-sm-8">
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-qrcode"></span> </span>
<input type="text" placeholder="'.$key_edit['code'].'" class="form-control" name="key" value="'.$key_edit['code'].'">
</div><br>
<button type="submit" name="edit" class="btn btn-danger btn-lg btn-block" data-loading-text="Изменить">Изменяю</button></form></div>';

	
break;

case 'delete':	
$key_del = DB::$the->query("SELECT code FROM `sel_keys` WHERE `id` = {$key} and `id_subcat` = {$subcategory}");
$key_del = $key_del->fetch(PDO::FETCH_ASSOC);
?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>  <li><a href="subcategory.php?category=<?=$category;?>"><?=$cat['name'];?></a></li>
  <li><a href="key.php?category=<?=$category;?>&subcategory=<?=$subcategory;?>"><?=$subcat['name'];?></a></li>
  <li class="active">Удаление Адреса: <b><?=$key_del['code'];?></b></li>
</ol>
<div class="alert alert-danger">Адрес будет удален навсегда!</div>

<div class="btn-group">
  <button type="button" class="btn btn-danger dropdown-toggle" data-loading-text="Думаем" data-toggle="dropdown">Вы уверены? <span class="caret"></span></button>
  <ul class="dropdown-menu" role="menu">
    <li><a href="?cmd=delete&category=<?=$category;?>&subcategory=<?=$subcategory;?>&key=<?=$key;?>&ok">Да, удалить</a></li>
    <li class="divider"></li>
    <li><a href="?category=<?=$category;?>&subcategory=<?=$subcategory;?>">Нет, отменить</a></li>
  </ul>
</div><br /><br />
<?


if(isset($_GET['ok'])) {
DB::$the->query("DELETE FROM `sel_keys` WHERE `id` = {$key} ");

header("Location: ?category=$category&subcategory=$subcategory");
}

break;

case 'remove_sale':	

?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>  <li><a href="subcategory.php?category=<?=$category;?>"><?=$cat['name'];?></a></li>
  <li><a href="key.php?category=<?=$category;?>&subcategory=<?=$subcategory;?>"><?=$subcat['name'];?></a></li>
  <li class="active">Удаление всех не проданных Адресов</li>
</ol>
<div class="alert alert-danger">Будут удалены все не проданные адреса!</div>

<div class="btn-group">
  <button type="button" class="btn btn-danger dropdown-toggle" data-loading-text="Думаем" data-toggle="dropdown">Вы уверены? <span class="caret"></span></button>
  <ul class="dropdown-menu" role="menu">
    <li><a href="?cmd=remove_sale&category=<?=$category;?>&subcategory=<?=$subcategory;?>&ok">Да, удалить все не проданные адреса</a></li>
    <li class="divider"></li>
    <li><a href="key.php?category=<?=$category;?>&subcategory=<?=$subcategory;?>">Нет, отменить</a></li>
  </ul>
</div><br /><br />

<?

if(isset($_GET['ok'])) {
DB::$the->query("DELETE FROM `sel_keys` WHERE `id_cat` = {$category} and `id_subcat` = {$subcategory} and `sale` = '0' ");

header("Location: key.php?category=category&subcategory=$subcategory");
}

break;
	
default:

?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>  <li><a href="subcategory.php?category=<?=$category;?>"><?=$cat['name'];?></a></li>
  <li class="active"><?=$subcat['name'];?></li>
</ol>


<div class="list-group">
<a class="list-group-item" href="?cmd=create&category=<?=$category;?>&subcategory=<?=$subcategory;?>">
<span class="glyphicon glyphicon-plus-sign"></span> Добавить много адресов
</a>
</div>
<?
?>
<div class="list-group">
<a class="list-group-item" href="key.php?cmd=remove_sale&category=<?=$category;?>&subcategory=<?=$subcategory;?>">
<span class="glyphicon glyphicon-remove"></span> Удалить все не проданные Адреса
</a>
</div>
<?

$total = DB::$the->query("SELECT * FROM `sel_keys` where `id_cat` = {$category} and `id_subcat` = {$subcategory} ");
$total = $total->fetchAll();
$max = 5;
$pages = $My_Class->k_page(count($total),$max);
$page = $My_Class->page($pages);
$start=($max*$page)-$max;

if(count($total) == 0){
echo '<div class="alert alert-danger">В данной подкатегории нет адресов!</div>';
}	

echo '<div class="list-group">';
$query = DB::$the->query("SELECT * FROM `sel_keys` where `id_cat` = {$category} and `id_subcat` = {$subcategory} order by rand() LIMIT $start, $max");
while($key = $query->fetch()) {
if($key['sale'] == 1) {
$sales = '<font color="red">[ПРОДАН]</font>';
}
else $sales = null;

	$subcats = DB::$the->query("SELECT * FROM `sel_cat` WHERE `id` = '".$key['id_subcats']."' ");
$subcats = $subcats->fetch(PDO::FETCH_ASSOC);

$cats = DB::$the->query("SELECT * FROM `sel_subcat` WHERE `id` = '".$key['id_cats']."' ");
$cats = $cats->fetch(PDO::FETCH_ASSOC);

echo '<span class="list-group-item"> <b>[Район:'.$subcats['name'].' Фасовка: '.$cats['name'].'] '.$key['code'].' </b> '.$sales;
echo '<a href="?cmd=edit&category='.$category.'&subcategory='.$subcategory.'&key='.$key['id'].'"> <span class="badge pull-right"><span class="glyphicon glyphicon-pencil"></span> </a>';
echo '<a href="?cmd=delete&category='.$category.'&subcategory='.$subcategory.'&key='.$key['id'].'"> <span class="badge pull-right"><span class="glyphicon glyphicon-remove"></span> </a>';
echo '</span>';
}
echo '</div>';

if ($pages>1) $My_Class->str('?category='.$category.'&subcategory='.$subcategory.'&',$pages,$page); 

}
?>
<style>
#upload{
	margin: 10px 30px; 
	padding: 10px;
	font-weight: bold; 
	font-size: 14px;
	font-family: Arial, Helvetica, sans-serif;
	text-align: center;
	background: #f2f2f2;
	color: #3366cc;
	border: 2px solid #ccc;
	width: 150px;
	cursor: pointer !important;
	-moz-border-radius: 5px; -webkit-border-radius:5px;
}
.darkbg{
	background: #ddd !important;
}
#status{
	font-family: Arial; 
	padding: 5px;
}
ul#files{ list-style: none; padding: 0; margin: 0; }
ul#files li{ padding: 10px; margin-bottom: 2px; width: 150px; float: left; margin-right: 10px;}
ul#files li img{ max-width: 160px; max-height: 150px; }
.success{}
.error{ background: #f0c6c3; border: 1px solid #cc6622; }
</style>

<?
$My_Class->foot();
?>