<?php
ob_start();
require '../style/head.php';
require '../classes/My_Class.php';
require '../classes/PDO.php';

if (!isset($_COOKIE['secretkey']) or $_COOKIE['secretkey'] != $secretkey) {
header("Location: /admin");		
exit;
}


if($_GET['page'] == "cat"){
    $query = DB::$the->query("SELECT * FROM `sel_category` order BY `id`");
       $My_Class->title("Управление ветриной");
	   if($_GET['page'] == "cat" and isset($_GET['addcat']) and isset($_POST['addcat'])){
		  
			 if($_POST['name'] != ""){
				 
			   $params = array('name' => $_POST['name'], 'conf' => $_POST['conf'], 'text' => $_POST['text'], 'img' => $_POST['img'], 'time' => time());  
               $q= DB::$the->prepare("INSERT INTO `sel_category` (name, conf, text, img, time) VALUES (:name, :conf, :text, :img, :time)");  
               $q->execute($params);
			   
			   header("Location: category.php?page=cat");
			 }
			  
	   }
	   if(isset($_GET['delet']) and isset($_GET['cat'])) {
		        DB::$the->query("DELETE FROM `sel_category` WHERE `id` = '{$_GET['cat']}'");
                     header("Location: category.php?page=cat");
					 
	   }
	    if(isset($_GET['remove_sale'])) {
			     DB::$the->query("DELETE FROM `sel_keys` WHERE `sale` = '1' ");
                     header("Location: category.php?page=cat");
					 
	   }
	    
         echo '
		 <div class="row">
                    <div class="col-sm-12">
                        <div class="button-list pull-right">
                            <a  class="btn btn-info waves-effect waves-light" href="#" data-toggle="modal" data-target="#addcat"><i class="fa fa-plus m-r-5"></i> <span>Добавить город</span></a>
							<a  class="btn btn-danger waves-effect waves-light" href="?page=cat&remove_sale"><i class="glyphicon glyphicon-trash m-r-5"></i><span>Удалить все проданые адреса</span></a>
		
		
		              <div id="addcat" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title">Добовляем город</h4>
                                        </div>
                                        <div class="modal-body">
										<form action="category.php?page=cat&addcat" method="Post">
										<div class="input-group">
                                                <span class="input-group-addon"><i class="typcn typcn-home"></i></span>
                                                <input type="text" name="name" maxlength="25" id="moreoptions" parsley-trigger="change" required="" placeholder="Название города"  class="form-control parsley-success">
                                       </div>
									   
									  <hr>
									  <center>Дополнительные настройки</center> 
									  <hr>
									  <div class="form-group">
                                              <div class="input-group">
												Отоброжать стандартный breadcrumb?<br />
                                                   <select class="form-control"  name="conf">
												   <option value="1">Вкл</option>
												   <option value="0">Выкл</option>
												   </select>
                                                </div>
                                            </div>
										
									  <div class="form-group">
                                            <div class="input-group">
										    <span class="input-group-addon"><i class="glyphicon glyphicon-bookmark"></i></span>
                                                <textarea class="form-control" placeholder="Этот текст будет выводится в боте после выбора города" name="text" rows="5"></textarea>
                                            </div>
                                        </div>
										
									   <div class="input-group">
                                                <span class="input-group-addon"><i class="glyphicon  glyphicon-picture"></i></span>
				
                                                <input type="text" name="img"  placeholder="Сылка на изображение"  class="form-control">
                                       </div>
									 </div>
                                         <div class="modal-footer">
                                            <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Отменить</button>
                                            <a href="href="javascript:;" onclick="$.Notification.notify(\'success\',\'bottom right\',\'Успешно!\', \'Создание района... Подождите пожалуйста страница будет перезагружена в течении 5 сек.\')"><button type="submit" name="addcat"  class="btn btn-info waves-effect waves-light">Сохранить</button></a>
                                        </div>
										</form>
                                    </div>
                                </div>
                            </div>
						</div>
				
					
                        <h4 class="page-title">Список Городов: </h4>
                      
                    </div>
                </div><br />
				<div class="row">
				<div class="col-lg-7">
		 <div class="list-group">';
          while($cat = $query->fetch()) {
			$cats = DB::$the->query("SELECT * FROM `sel_cat` where `cat` = '{$cat['id']}' ");
            $cats = $cats->fetchAll();
			$cats_count = count($cats);
             echo '<span id="cat'.$cat['id'].'" class="list-group-item">
			 <a href="?page=cats&cat='.$cat['id'].'">
			<span class="label label-warning"># '.$cat['id'].'</span>
               <b>'.$cat['name'].' [Районов:'.$cats_count.']</b>
			   </a>
			    <div class="button-list pull-right">
                <span class="label label-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="Редактирование"><i class="glyphicon glyphicon-pencil"></i></span>
			    <a  href="#" onclick="sweetAlert(\'Успешно\', \'Город: '.$cat['name'].' был успешно удален\', \'success\'); setTimeout(location.replace(\'category.php?page=cat&cat='.$cat['id'].'&delet\'),5000);"><span class="label label-danger"><i class="glyphicon glyphicon-remove" data-toggle="tooltip" data-placement="top" title="" data-original-title="Удалить"></i></span></a>
				<a href="?page=cats&cat='.$cat['id'].'" style="font-size:20px;"><i class="glyphicon glyphicon-chevron-right" data-toggle="tooltip" data-placement="top" title="" data-original-title="Перейти к управлению районами"></i></a>
                </div>
			</span>';
			 
          }
		  echo '</div></div>
		  <!-- Last Order -->
                   <div class="col-lg-5">
                       <div class="card-box">
                            <h4 class="m-t-0 m-b-20 header-title"><i class="glyphicon glyphicon-shopping-cart"></i> <b>Последние покупки</b></h4>

							<table class="table">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Город <br/><small>Район</small></th>
                                                    <th>Товар <br/><small>Фасовка</small></th>
                                                    <th>Покупатель</th>
                                                    <th>Время</th>
                                                </tr>
                                            </thead>';
										
            $query = DB::$the->query("SELECT * FROM `sel_keys` WHERE `sale` = '1'");
                while($keys = $query->fetch()) {
					$name = DB::$the->query("SELECT * FROM `sel_users` WHERE `chat` = '".$keys['block_user']."'");
                    $name = $name->fetch(PDO::FETCH_ASSOC);
					$cat = DB::$the->query("SELECT * FROM `sel_category` WHERE `id` = '".$keys['id_cat']."'");
                    $cat = $cat->fetch(PDO::FETCH_ASSOC);
					$cats = DB::$the->query("SELECT * FROM `sel_subcat` WHERE `id` = '".$keys['id_cats']."'");
                    $cats = $cats->fetch(PDO::FETCH_ASSOC);
					$subcat = DB::$the->query("SELECT * FROM `sel_subcategory` WHERE `id` = '".$keys['id_subcat']."'");
                    $subcat = $subcat->fetch(PDO::FETCH_ASSOC);
					$subcats = DB::$the->query("SELECT * FROM `sel_cat` WHERE `id` = '".$keys['id_subcats']."'");
                    $subcats = $subcats->fetch(PDO::FETCH_ASSOC);
							
					     echo'<tr>
                                <td>'.$i++.'</td>
                                <td>'.$cat['name'].' <br/><small>'.$subcats['name'].'</small></td>
                                <td>'.$subcat['name'].' <br/><small>'.$cats['name'].'</small></td>
                                <td>'.$name['first_name'].'</td>
                                 <td><span class="label label-info"><i class="glyphicon glyphicon-time"></i> '.$otziv['block_time'].'</span></td>
                                </tr>';
					}
                            
							   echo '</tbody>
								</table>
                            </div>
                      </div>
                </div>';
}
if($_GET['page'] == "cats" and isset($_GET['cat'])){
	
	
	$cat = DB::$the->query("SELECT * FROM `sel_category` where `id` = '{$_GET['cat']}' ");
    $cat = $cat->fetch(PDO::FETCH_ASSOC);
	
    $query = DB::$the->query("SELECT * FROM `sel_cat` where `cat` = '{$cat['id']}' order BY `id`");
       $My_Class->title("{$cat['name']} >> Выбираем район");
	   
	   	   if(isset($_GET['add']) and isset($_POST['addcats']) and  isset($_GET['cat'])){
		  
			 if($_POST['name'] != ""){
				 
			   $params = array('name' => $_POST['name'], 'cat' => $cat['id'], 'conf' => $_POST['conf'], 'text' => $_POST['text'], 'img' => $_POST['img'], 'time' => time());  
               $q= DB::$the->prepare("INSERT INTO `sel_cat` (name, cat, conf, text, img, time) VALUES (:name, :cat, :conf, :text, :img, :time)");  
               $q->execute($params);
				 
			 }
			  
	            header("Location: category.php?page=cats&cat={$_GET['cat']}");
				
		}elseif(isset($_GET['delet']) and isset($_GET['cats'])) {
		        DB::$the->query("DELETE FROM `sel_cat` WHERE `cat` = '{$_GET['cat']}' ");
	            header("Location: category.php?page=cats&cat={$_GET['cat']}");
					 
	   }
	   
	    if($cat['img'] != null){
         $img = $cat['img'];
		}else{
			$img = '/style/images/products/big/1.jpg';
		}
                  echo'<div class="col-sm-12">
				  <div class="card-box m-b-10">
                            <div class="table-box opport-box">
                                <div class="table-detail">
                                    <img src="'.$img.'" alt="img" class="img-circle thumb-lg m-r-15">
                                </div>

                                <div class="table-detail">
                                    <div class="member-info">
                                        <h4 class="m-t-0"><b>Город: '.$cat['name'].'</b></h4>
                                    </div>
                                </div>

                                <div class="table-detail table-actions-bar">
                                        <p class="text-dark m-b-5"><b>Описание: </b><br />';
										if($cat['text'] != null){
										echo'<span class="text-muted">'.$cat['text'].'</span></p>';
										}
                                echo'</div>
                            </div>
                        </div>
				  
				  
				  </div>
				  ';
					
						

							
					
                     echo'<div class="button-list pull-right">
					        <a  class="btn btn-danger waves-effect waves-light" href="category.php?page=cat"><i class="md md-reply m-r-5"></i> <span>Назад к городам</span></a>
                            <a  class="btn btn-info waves-effect waves-light" href="#" data-toggle="modal" data-target="#addcats"><i class="fa fa-plus m-r-5"></i> <span>Добавить Район</span></a>
		
		
		              <div id="addcats" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title">Добовляем район</h4>
                                        </div>
                                        <div class="modal-body">
										<form action="category.php?page=cats&cat='.$cat['id'].'&add" method="Post">
										<div class="input-group">
                                                <span class="input-group-addon"><i class="glyphicon glyphicon-road"></i></span>
                                                <input type="text" name="name" maxlength="25" id="moreoptions" parsley-trigger="change" required="" placeholder="Название района"  class="form-control parsley-success">
                                       </div>
									   
									  <hr>
									  <center>Дополнительные настройки</center>
									  <hr>
									  <div class="form-group">
                                              <div class="input-group">
												Отоброжать стандартный breadcrumb?<br />
                                                   <select class="form-control"  name="conf">
												   <option value="1">Вкл</option>
												   <option value="0">Выкл</option>
												   </select>
                                                </div>
                                            </div>
										
									  <div class="form-group">
                                            <div class="input-group">
										    <span class="input-group-addon"><i class="glyphicon glyphicon-bookmark"></i></span>
                                                <textarea class="form-control" placeholder="Этот текст будет выводится в боте после выбора района" name="text" rows="5"></textarea>
                                            </div>
                                        </div>
										
									   <div class="input-group">
                                                <span class="input-group-addon"><i class="glyphicon  glyphicon-picture"></i></span>
				
                                                <input type="text" name="img"  placeholder="Ссылка на изображение"  class="form-control">                                    </div>
									 </div>
                                         <div class="modal-footer">
                                            <button type="button" class="btn btn-default waves-effect waves-light" data-dismiss="modal">Отменить</button>
                                            <button type="submit" name="addcats" class="btn btn-info waves-effect waves-light">Добавить</button>
                                        </div>
										</form>
                                    </div>
                                </div>
                            </div>
						</div>
				
					
                        <h4 class="page-title">Список Районов: </h4>
                      
                    </div>
                </div><br />
				<div class="row">
				<div class="col-lg-7">
		 <div class="list-group">';
	           while($cats = $query->fetch()) {
				 echo '<span id="cat'.$cat['id'].'" class="list-group-item">
			 <a href="?page=subcat&cat='.$_GET['cat'].'&cats='.$cats['id'].'">
			<span class="label label-warning"># '.$cats['id'].'</span>
               <b>'.$cats['name'].'</b>
			   </a>
			    <div class="button-list pull-right">
                <span class="label label-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="Редактирование"><i class="glyphicon glyphicon-pencil"></i></span>
			    <a  href="#" onclick="sweetAlert(\'Успешно\', \'Район: '.$cats['name'].' был успешно удален\', \'success\'); setTimeout(location.replace(\'category.php?page=cats&cats='.$cats['id'].'&delet\'),5000);">
<span class="label label-danger"><i class="glyphicon glyphicon-remove" data-toggle="tooltip" data-placement="top" title="" data-original-title="Удалить"></i></span></a>
				<a href="?page=subcat&cat='.$cat['id'].'&cats='.$cats['id'].'" style="font-size:20px;"><i class="glyphicon glyphicon-chevron-right" data-toggle="tooltip" data-placement="top" title="" data-original-title="Перейти к управлению товаром"></i></a>
                </div>
			</span>';  
				   
			   }
		   echo '</div></div>
		  <!-- Last Order -->
                   <div class="col-lg-5">
                       <div class="card-box">
                            <h4 class="m-t-0 m-b-20 header-title"><i class="glyphicon glyphicon-shopping-cart"></i> <b>Последние покупки</b></h4>

							<table class="table">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Город <br/><small>Район</small></th>
                                                    <th>Товар <br/><small>Фасовка</small></th>
                                                    <th>Покупатель</th>
                                                    <th>Время</th>
                                                </tr>
                                            </thead>';
										
            $query = DB::$the->query("SELECT * FROM `sel_keys` WHERE `sale` = '1'");
                while($keys = $query->fetch()) {
					$name = DB::$the->query("SELECT * FROM `sel_users` WHERE `chat` = '".$keys['block_user']."'");
                    $name = $name->fetch(PDO::FETCH_ASSOC);
					$cat = DB::$the->query("SELECT * FROM `sel_category` WHERE `id` = '".$keys['id_cat']."'");
                    $cat = $cat->fetch(PDO::FETCH_ASSOC);
					$cats = DB::$the->query("SELECT * FROM `sel_subcat` WHERE `id` = '".$keys['id_cats']."'");
                    $cats = $cats->fetch(PDO::FETCH_ASSOC);
					$subcat = DB::$the->query("SELECT * FROM `sel_subcategory` WHERE `id` = '".$keys['id_subcat']."'");
                    $subcat = $subcat->fetch(PDO::FETCH_ASSOC);
					$subcats = DB::$the->query("SELECT * FROM `sel_cat` WHERE `id` = '".$keys['id_subcats']."'");
                    $subcats = $subcats->fetch(PDO::FETCH_ASSOC);
							
					     echo'<tr>
                                <td>'.$i++.'</td>
                                <td>'.$cat['name'].' <br/><small>'.$subcats['name'].'</small></td>
                                <td>'.$subcat['name'].' <br/><small>'.$cats['name'].'</small></td>
                                <td>'.$name['first_name'].'</td>
                                 <td><span class="label label-info"><i class="glyphicon glyphicon-time"></i> '.$otziv['block_time'].'</span></td>
                                </tr>';
					}
                            
							   echo '</tbody>
								</table>
                            </div>
                      </div>
                </div>';
		  
		  
}
if($_GET['page'] == "subcat" and isset($_GET['cat'])  and isset($_GET['cats'])){
	
	$cat = DB::$the->query("SELECT * FROM `sel_category` WHERE `id` = '".intval($_GET['cat'])."' ");
	$cat = $cat->fetch(PDO::FETCH_ASSOC);

	$cats = DB::$the->query("SELECT * FROM `sel_cat` WHERE `id` = '".intval($_GET['cats'])."' ");
	$cats = $cats->fetch(PDO::FETCH_ASSOC);
	
	 $My_Class->title("{$cat['name']} > {$cats['name']} >  Выбираем товар");

	
	   if($_GET['page'] == "subcat" and isset($_GET['add']) and isset($_POST['addsubcat']) and isset($_GET['cat'])  and isset($_GET['cats'])){
		  
			 if($_POST['name'] != ""){
				 
			   $params = array('name' => $_POST['name'], 'id_cat' => $cat['id'], 'conf' => $_POST['conf'], 'text' => $_POST['text'], 'img' => $_POST['img'], 'time' => time());  
               $q= DB::$the->prepare("INSERT INTO `sel_subcategory` (name, id_cat, conf, text, img, time) VALUES (:name, :id_cat, :conf, :text, :img, :time)");  
               $q->execute($params);
				 
			 }
			  
	   
	       header("Location: category.php?page=subcat&cat={$_GET['cat']}&cats={$_GET['cats']}");
		}
			  
	    if(isset($_GET['del']) and isset($_GET['subcat'])) {
		        DB::$the->query("DELETE FROM `sel_subcategory` WHERE `id` = '{$_GET['subcat']}'");
	                header("Location: category.php?page=subcat&cat={$_GET['cat']}&cats={$_GET['cats']}");
					 
	   }
	 if($cats['img'] != null){
         $img = $cats['img'];
		}else{
			$img = '/style/images/products/big/1.jpg';
		}
                  echo'<div class="col-sm-12">
				  <div class="card-box m-b-10">
                            <div class="table-box opport-box">
                                <div class="table-detail">
                                    <img src="'.$img.'" alt="img" class="img-circle thumb-lg m-r-15">
                                </div>

                                <div class="table-detail">
                                    <div class="member-info">
                                        <h4 class="m-t-0"><b>Район: '.$cats['name'].'</b></h4>
										<p class="text-dark m-b-5"><b>Город: </b> <span class="text-muted"> '.$cat['name'].'<span></p>
                                    </div>
                                </div>

                                <div class="table-detail table-actions-bar">
                                        <p class="text-dark m-b-5"><b>Описание: </b><br />';
										if($cats['text'] != null){
										echo'<span class="text-muted">'.$cats['text'].'</span></p>';
										}
                                echo'</div>
                            </div>
                        </div>
				  
				  
				  </div>
				  ';
					
						

							
					
                     echo'<div class="button-list pull-right">
					        <a  class="btn btn-danger waves-effect waves-light" href="category.php?page=cats&cat='.$cat['id'].'"><i class="md md-reply m-r-5"></i> <span>Назад к районам</span></a>
                            <a  class="btn btn-info waves-effect waves-light" href="#" data-toggle="modal" data-target="#addcat"><i class="fa fa-plus m-r-5"></i> <span>Добавить товар</span></a>
		              <div id="addcat" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title">Добавляем товар</h4>
                                        </div>
                                        <div class="modal-body">
										<form action="category.php?page=subcat&cat='.$cat['id'].'&cats='.$cats['id'].'&add" method="Post">
										<div class="input-group">
                                                <span class="input-group-addon"><i class="glyphicon glyphicon-qrcode"></i></span>
                                                <input type="text" name="name" maxlength="25" id="moreoptions" parsley-trigger="change" required="" placeholder="Название Товара"  class="form-control parsley-success">
                                       </div>
									   
									  <hr>
									  <center>Дополнительные настройки</center>
									  <hr>
									  <div class="form-group">
                                              <div class="input-group">
												Отображать стандартный breadcrumb?<br />
                                                   <select class="form-control"  name="conf">
												   <option value="1">Вкл</option>
												   <option value="0">Выкл</option>
												   </select>
                                                </div>
                                            </div>
										
									  <div class="form-group">
                                            <div class="input-group">
										    <span class="input-group-addon"><i class="glyphicon glyphicon-bookmark"></i></span>
                                                <textarea class="form-control" placeholder="Этот текст будет выводится в боте после выбора города" name="text" rows="5"></textarea>
                                            </div>
                                        </div>
										
									   <div class="input-group">
                                                <span class="input-group-addon"><i class="glyphicon  glyphicon-picture"></i></span>
				
                                                <input type="text" name="img"  placeholder="Ссылка на изображение"  class="form-control">
                                       </div>
									 </div>
                                         <div class="modal-footer">
                                            <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Отменить</button>
                                            <button type="submit" name="addsubcat" class="btn btn-info waves-effect waves-light">Сохранить</button>
                                        </div>
										</form>
                                    </div>
                                </div>
                            </div>
						</div>
				
					
                        <h4 class="page-title">Список товаров: </h4>
                      
                    </div>
                </div><br />
				<div class="row">
				<div class="col-lg-7">
		 <div class="list-group">';
       $query = DB::$the->query("SELECT * FROM `sel_subcategory` where `id_cat` = '".intval($_GET['cat'])."' order by `id` ");
          while($subcat = $query->fetch()) {
   echo '<span id="cat'.$cat['id'].'" class="list-group-item">
			 <a href="?page=key&cat='.$cat['id'].'&cats='.$cat['cats'].'&subcat='.$subcat['id'].'">
			<span class="label label-warning"># '.$subcat['id'].'</span>
               <b>'.$subcat['name'].'</b>
			   </a>
			    <div class="button-list pull-right">
                <span class="label label-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="Редактирование"><i class="glyphicon glyphicon-pencil"></i></span>
			    			    <a  href="#" onclick="sweetAlert(\'Успешно\', \'Товар: '.$subcat['name'].' был успешно удален\', \'success\'); setTimeout(location.replace(\'category.php?page=subcat&subcat='.$subcat['id'].'&del\'),5000);">
<span class="label label-danger"><i class="glyphicon glyphicon-remove" data-toggle="tooltip" data-placement="top" title="" data-original-title="Удалить"></i></span></a>
				<a href="?page=key&cat='.$cat['id'].'&cats='.$cats['id'].'&subcat='.$subcat['id'].'" style="font-size:20px;"><i class="glyphicon glyphicon-chevron-right" data-toggle="tooltip" data-placement="top" title="" data-original-title="Перейти к управлению адресами/фасовками"></i></a>
                </div>
			</span>';
			 
	
           }
   		  echo '</div></div>
		  <!-- Last Order -->
                   <div class="col-lg-5">
                       <div class="card-box">
                            <h4 class="m-t-0 m-b-20 header-title"><i class="glyphicon glyphicon-shopping-cart"></i> <b>Последние покупки</b></h4>

							<table class="table">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Город <br/><small>Район</small></th>
                                                    <th>Товар <br/><small>Фасовка</small></th>
                                                    <th>Покупатель</th>
                                                    <th>Время</th>
                                                </tr>
                                            </thead>';
										
            $query = DB::$the->query("SELECT * FROM `sel_keys` WHERE `sale` = '1'");
                while($keys = $query->fetch()) {
					$name = DB::$the->query("SELECT * FROM `sel_users` WHERE `chat` = '".$keys['block_user']."'");
                    $name = $name->fetch(PDO::FETCH_ASSOC);
					$cat = DB::$the->query("SELECT * FROM `sel_category` WHERE `id` = '".$keys['id_cat']."'");
                    $cat = $cat->fetch(PDO::FETCH_ASSOC);
					$cats = DB::$the->query("SELECT * FROM `sel_subcat` WHERE `id` = '".$keys['id_cats']."'");
                    $cats = $cats->fetch(PDO::FETCH_ASSOC);
					$subcat = DB::$the->query("SELECT * FROM `sel_subcategory` WHERE `id` = '".$keys['id_subcat']."'");
                    $subcat = $subcat->fetch(PDO::FETCH_ASSOC);
					$subcats = DB::$the->query("SELECT * FROM `sel_cat` WHERE `id` = '".$keys['id_subcats']."'");
                    $subcats = $subcats->fetch(PDO::FETCH_ASSOC);
							
					     echo'<tr>
                                <td>'.$i++.'</td>
                                <td>'.$cat['name'].' <br/><small>'.$subcats['name'].'</small></td>
                                <td>'.$subcat['name'].' <br/><small>'.$cats['name'].'</small></td>
                                <td>'.$name['first_name'].'</td>
                                 <td><span class="label label-info"><i class="glyphicon glyphicon-time"></i> '.$otziv['block_time'].'</span></td>
                                </tr>';
					}
                            
							   echo '</tbody>
								</table>
                            </div>
                      </div>
                </div>
				</div>';
    } elseif($_GET['page'] == "key" and isset($_GET['cat']) and isset($_GET['cats']) and isset($_GET['subcat'])){
	
	$cat = DB::$the->query("SELECT * FROM `sel_category` WHERE `id` = '".intval($_GET['cat'])."' ");
	$cat = $cat->fetch(PDO::FETCH_ASSOC);

	$cats = DB::$the->query("SELECT * FROM `sel_cat` WHERE `id` = '".intval($_GET['cats'])."' ");
	$cats = $cats->fetch(PDO::FETCH_ASSOC);
	
	$subcat = DB::$the->query("SELECT * FROM `sel_subcategory` WHERE `id` = '".intval($_GET['subcat'])."' ");
	$subcat = $subcat->fetch(PDO::FETCH_ASSOC);
	
	
    
	
	 $My_Class->title("{$cat['name']} > {$cats['name']} > {$subcat['name']} > Выбираем товар");

	
	
	 if($subcat['img'] != null){
         $img = $subcat['img'];
		}else{
			$img = '/style/images/products/big/1.jpg';
		}
                  echo'<div class="col-sm-12">
				  <div class="card-box m-b-10">
                            <div class="table-box opport-box">
                                <div class="table-detail">
                                    <img src="'.$img.'" alt="img" class="img-circle thumb-lg m-r-15">
                                </div>

                                <div class="table-detail">
                                    <div class="member-info">
									   <h4 class="m-t-0"><b>Товар: '.$subcat['name'].'</b></h4>
										<p class="text-dark m-b-5"><b>Район: </b> <span class="text-muted"> '.$cats['name'].'<span></p>
										<p class="text-dark m-b-5"><b>Город: </b> <span class="text-muted"> '.$cat['name'].'<span></p>
                                    </div>
                                </div>

                                <div class="table-detail table-actions-bar">
                                        <p class="text-dark m-b-5"><b>Описание: </b><br />';
										if($subcat['text'] != null){
										echo'<span class="text-muted">'.$subcats['text'].'</span></p>';
										}
                                echo'</div>
                            </div>
                        </div>
				  
				  
				  </div>
				  ';
					
				
          echo'<div class="button-list pull-right">
					        <a  class="btn btn-danger waves-effect waves-light" href="category.php?page=cats&cat='.$cat['id'].'"><i class="md md-reply m-r-5"></i> <span>Назад к районам</span></a>
                   
					</div>
                        <h4 class="page-title">Список Адресов: </h4>
                      
                    </div>
                </div><br />
				<div class="row">
				<div class="col-lg-15">
		 ';
       $query = DB::$the->query("SELECT * FROM `sel_keys` order by `id` ");
					 while($keys = $query->fetch()) {
				 $cats = DB::$the->query("SELECT * FROM `sel_subcat` WHERE `id_subcat` = '".$keys['id_subcat']."' ");
                    $cats = $cats->fetch(PDO::FETCH_ASSOC);
                       echo '<div class="col-sm-6 col-lg-3 col-md-4 mobiles">
                            <div class="product-list-box thumb">
                                <div class="product-action">
                                    <a href="#" class="btn btn-success btn-sm"><i class="md md-mode-edit"></i></a>
                                    <a href="#" class="btn btn-danger btn-sm"><i class="md md-close"></i></a>
                                </div>
          
                                <div class="price-tag">
                                  '.$cats['amount'].'₽
                                </div>
                                <div class="detail">
                                    <h4 class="m-t-0"><a href="" class="text-dark">'.$keys['code'].'</a></h4>
                                    <h5 class="m-0"> <span class="text-muted">Фасовка: '.$cats['name'].'</span></h5>
                                </div>
                            </div>
                        </div>';
					}
	               echo'</div>
	           </div>
			   ';
	
}
	
	
	   


/*
switch ($cmd){
case 'create':

$My_Class->title("Категории");
?>
<ol class="breadcrumb">
  <li><a href="/admin">Админ-панель</a></li>
  <li><a href="category.php">Категории</a></li>
  <li class="active">Создание категории</li>
</ol>
<?
if(isset($_POST['create'])) {

if($_POST['cat'] != "") {
$cat=$_POST['cat'];

$cat_m = DB::$the->query("SELECT mesto FROM `sel_category` order by `mesto` DESC limit 1 ");
$cat_m = $cat_m->fetch(PDO::FETCH_ASSOC);
$new_mesto = $cat_m['mesto']+1;

$params = array( 'name' => ''.$cat.'', 'time' => ''.time().'', 'mesto' => $new_mesto);  
 
$q= DB::$the->prepare("INSERT INTO `sel_category` (name, time, mesto) VALUES (:name, :time, :mesto)");  
$q->execute($params);

header("Location: category.php");
}
else
{
echo '<div class="alert alert-danger">Пустое название</div>';
}
}

echo '<form action="category.php?cmd=create" method="POST">
<div class="form-group col-sm-8">
<div class="input-group input-group-lg">
    <span class="input-group-addon"><span class="glyphicon glyphicon-pencil"></span> </span>
<input type="text" placeholder="Название категории" class="form-control" name="cat" value="">
</div>
<br />
<button type="submit" name="create" class="btn btn-danger btn-lg btn-block" data-loading-text="Создаю">Создать</button>
</div></form>';

break;
 	
case 'edit':	
?>
<ol class="breadcrumb">
  <li><a href="/admin">Админ-панель</a></li>
  <li><a href="category.php">Категории</a></li>
  <li class="active">Редактирование категории</li>
</ol>
<?

$row = DB::$the->query("SELECT * FROM `sel_category` WHERE `id` = {$category} ");
$cat = $row->fetch(PDO::FETCH_ASSOC);

// Редактирование категории
if(isset($_POST['edit'])) {

if($_POST['name'] != "") {
$name=$_POST['name'];
$mesto=intval($_POST['mesto']);

DB::$the->prepare("UPDATE sel_category SET name=? WHERE id=? ")->execute(array("$name", $category)); 
DB::$the->prepare("UPDATE sel_category SET mesto=? WHERE id=? ")->execute(array("$mesto", $category)); 

header("Location: category.php");
}
else
{
echo '<div class="alert alert-danger">Пустое название</div>';
}
}


echo '<form action="?cmd=edit&category='.$category.'" method="POST">
<div class="form-group col-sm-8">
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-pencil"></span> </span>
<input type="text" placeholder="'.$cat['name'].'" class="form-control" name="name" value="'.$cat['name'].'">
</div><br />
<div class="input-group input-group-lg">
<span class="input-group-addon"><span class="glyphicon glyphicon-flag"></span> </span>
<input type="text" placeholder="'.$cat['mesto'].'" class="form-control" name="mesto" value="'.$cat['mesto'].'">
</div><br />
<button type="submit" name="edit" class="btn btn-danger btn-lg btn-block" data-loading-text="Изменяю">Изменить</button>
</div></form>';

	
break;

case 'delete':	
$row = DB::$the->query("SELECT * FROM `sel_category` WHERE `id` = '".$category."'");
$cat = $row->fetch(PDO::FETCH_ASSOC);
?>
<ol class="breadcrumb">
  <li><a href="/admin">Админ-панель</a></li>
  <li><a href="category.php">Категории</a></li>
  <li class="active">Удаление категории: <b><?=$cat['name'];?></b></li>
</ol>
<div class="alert alert-danger">Будут удалены все подкатегории данной категории и ключи из всех подкатегорий данной категории!</div>

<div class="btn-group">
  <button type="button" class="btn btn-danger dropdown-toggle" data-loading-text="Думаем" data-toggle="dropdown">Вы уверены? <span class="caret"></span></button>
  <ul class="dropdown-menu" role="menu">
    <li><a href="?cmd=delete&category=<?=$category;?>&ok">Да, удалить</a></li>
    <li class="divider"></li>
    <li><a href="category.php">Нет, отменить</a></li>
  </ul>
</div><br /><br />

<?

if(isset($_GET['ok'])) {
DB::$the->query("DELETE FROM `sel_category` WHERE `id` = '".$category."' ");
DB::$the->query("DELETE FROM `sel_subcategory` WHERE `id_cat` = '".$category."' ");
DB::$the->query("DELETE FROM `sel_keys` WHERE `id_cat` = '".$category."' ");

header("Location: category.php");
}

break;

case 'remove_sale':	

?>
<ol class="breadcrumb">
  <li><a href="/admin">Админ-панель</a></li>
  <li><a href="category.php">Категории</a></li>
  <li class="active">Удаление всех проданных ключей</b></li>
</ol>
<div class="alert alert-danger">Будут удалены все проданные ключи из всех категорий!</div>

<div class="btn-group">
  <button type="button" class="btn btn-danger dropdown-toggle" data-loading-text="Думаем" data-toggle="dropdown">Вы уверены? <span class="caret"></span></button>
  <ul class="dropdown-menu" role="menu">
    <li><a href="?cmd=remove_sale&ok">Да, удалить все проданные ключи</a></li>
    <li class="divider"></li>
    <li><a href="category.php">Нет, отменить</a></li>
  </ul>
</div><br /><br />

<?

if(isset($_GET['ok'])) {
DB::$the->query("DELETE FROM `sel_keys` WHERE `sale` = '1' ");

header("Location: category.php");
}

break;
	
default:

?>
<div class="row">
                    <div class="col-sm-12">
                        <div class="button-list pull-right">
                            <a  class="btn btn-info waves-effect waves-light" href="?cmd=create"><i class="fa fa-plus m-r-5"></i> <span>Добавить город</span></a>
							<a  class="btn btn-danger waves-effect waves-light" href="?cmd=remove_sale"><i class="glyphicon glyphicon-trash m-r-5"></i><span>Удалить все проданые адреса</span></a>

                           
                        </div>

                        <h4 class="page-title">Управление городами</h4>
                      
                    </div>
                </div><br />
				<div class="row">
				<div class="col-lg-7">
<?



$total = DB::$the->query("SELECT * FROM `sel_category` ");
$total = $total->fetchAll();
$max = 15;
$pages = $My_Class->k_page(count($total),$max);
$page = $My_Class->page($pages);
$start=($max*$page)-$max;

if(count($total) == 0){
echo '<div class="alert alert-danger">Нет категорий!</div>';
}	

echo '<div class="list-group">';
$query = DB::$the->query("SELECT * FROM `sel_category` order by `mesto` LIMIT $start, $max");
while($cat = $query->fetch()) {
-
$total = DB::$the->query("SELECT id_cat FROM `sel_subcategory` WHERE `id_cat` = '".$cat['id']."' ");
$total = $total->fetchAll();
	
echo '<span class="list-group-item"><font color="green">#'.$cat['id'].'</font><a href="subcategory.php?category='.$cat['id'].'"><b>'.$cat['name'].'</b></a> ('.count($total).')  <ul><li><i class="glyphiconglyphicon-tags"></i></li>';
$querys = DB::$the->query("SELECT * FROM `sel_cat` where `cat` = '{$cat['id']}'");
while($subcats = $querys->fetch()) {
	echo '<li>'.$subcats['name'].'</li>';
}
echo'</ul><div class="button-list pull-right">';
echo '<a class="btn btn-sm btn-purple  waves-effect waves-light" href="?cmd=edit&category='.$cat['id'].'"><i class="glyphicon glyphicon-pencil"></i></a>';
echo '<a class="btn btn-sm btn-danger  waves-effect waves-light" href="?cmd=delete&category='.$cat['id'].'&hash='.md5($_cat['time']).'"><i class="glyphicon glyphicon-trash"></i></a>';
echo '</div></span>';
}
echo '</div>';

if ($pages>1) $My_Class->str('?',$pages,$page); 

?></div>

                    <!-- Todos app -->
                   <div class="col-lg-5">
                       <div class="card-box">
                            <h4 class="m-t-0 m-b-20 header-title"><i class="glyphicon glyphicon-shopping-cart"></i> <b>Последнии покупки</b></h4>

							<table class="table">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Город <br/><small>Район</small></th>
                                                    <th>Товар <br/><small>Фасовка</small></th>
                                                    <th>Покупатель</th>
                                                    <th>Время</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                               <?php
							  
								
                               $query = DB::$the->query("SELECT * FROM `sel_keys` WHERE `sale` = '1'");
                               while($keys = $query->fetch()) {
						          $name = DB::$the->query("SELECT * FROM `sel_users` WHERE `chat` = '".$keys['block_user']."'");
                                  $name = $name->fetch(PDO::FETCH_ASSOC);
							      $cat = DB::$the->query("SELECT * FROM `sel_category` WHERE `id` = '".$keys['id_cat']."'");
                                  $cat = $cat->fetch(PDO::FETCH_ASSOC);
								  $cats = DB::$the->query("SELECT * FROM `sel_subcat` WHERE `id` = '".$keys['id_cats']."'");
                                  $cats = $cats->fetch(PDO::FETCH_ASSOC);
								  $subcat = DB::$the->query("SELECT * FROM `sel_subcategory` WHERE `id` = '".$keys['id_subcat']."'");
                                  $subcat = $subcat->fetch(PDO::FETCH_ASSOC);
								  $subcats = DB::$the->query("SELECT * FROM `sel_cat` WHERE `id` = '".$keys['id_subcats']."'");
                                  $subcats = $subcats->fetch(PDO::FETCH_ASSOC);
							
							    echo'
                                                <tr>
                                                    <td>'.$i++.'</td>
                                                    <td>'.$cat['name'].' <br/><small>'.$subcats['name'].'</small></td>
                                                    <td>'.$subcat['name'].' <br/><small>'.$cats['name'].'</small></td>
                                                    <td>'.$name['first_name'].'</td>
                                                    <td><span class="label label-info"><i class="glyphicon glyphicon-time"></i> '.$otziv['block_time'].'</span></td>
                                                </tr>';
							   }
                               ?>
							   </tbody>
									   </table>
                        </div>

                      </div>
                </div>
<?
}
*/

$My_Class->foot();
?>