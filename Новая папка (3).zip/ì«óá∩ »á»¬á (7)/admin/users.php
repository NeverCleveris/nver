
<?php 
ob_start();
require_once "../classes/My_Class.php";
require_once TPL."head.php";

if (!isset($_COOKIE['secretkey']) or $_COOKIE['secretkey'] != $secretkey) {
           header("Location: index.php"); 
exit;
}


$My_Class->title("Пользователи");

if (!isset($_COOKIE['secretkey']) or $_COOKIE['secretkey'] != $secretkey) {
           header("Location: index.php"); exit;
}

$curl = new Curl();
$set_bot = DB::$the->query("SELECT * FROM sel_set_bot ");
$set_bot = $set_bot->fetch(PDO::FETCH_ASSOC);
if(isset($_GET['searah']) and isset($_POST['search']) and isset($_POST['submit'])){  
if(isset($_GET['ban']) and $_GET['id'] > 0){
DB::$the->prepare("UPDATE sel_users SET ban=? WHERE id=? ")->execute(array("1", $_GET['id'])); 
header("Location: users.php");
}elseif(isset($_GET['unban']) and $_GET['id'] > 0){
DB::$the->prepare("UPDATE sel_users SET ban=? WHERE id=? ")->execute(array("0", $_GET['id'])); 
header("Location: users.php");
}
if(isset($_GET['edit']) and isset($_POST['save']) and $_POST['balans'] > 0 and $_GET['chat'] > 0){
  
DB::$the->prepare("UPDATE sel_users SET balans=? WHERE chat=? ")->execute(array($_POST['balans'], $_GET['chat']));
$curl->get('https://api.telegram.org/bot'.$set_bot['token'].'/sendMessage',array('chat_id' => $_GET['chat'], 'text' => '⚜️ <b>Вам зачислены деньги в размере '.$_POST['balans'].'руб.</b>⚜️', 'parse_mode' => 'HTML',));
 }
if(isset($_GET['edit']) and isset($_POST['save']) and $_POST['balansbtc'] > 0 and $_GET['chat'] > 0){  

DB::$the->prepare("UPDATE sel_users SET balansbtc=? WHERE chat=? ")->execute(array($_POST['balansbtc'], $_GET['chat']));
$curl->get('https://api.telegram.org/bot'.$set_bot['token'].'/sendMessage',array('chat_id' => $_GET['chat'], 'text' => '⚜️ <b>Вам зачислены деньги в размере '.$_POST['balansbtc'].'btc</b>⚜️', 'parse_mode' => 'HTML',));   
header("Location: users.php"); 
}
?>
<script type="text/javascript">  
 $(function() { 
    $(".btn").click(function(){
        $(this).button('loading').delay(3000).queue(function() {
            $(this).button('reset');
            $(this).dequeue();
        });        
    });
});  
</script>
<h4 class="page-title">Поиск пользователей по юзернейм</h4>
<form method="post" action="?searah"><br /><br />
    <input type="text" name="search" class="form-control input-sm col-sm-8" value="<? echo $_POST['search']; ?>">  <br /> <br />       
            <button  type="submit" class="btn btn-icon btn-success waves-effect waves-light btn-sm" name="submit" data-toggle="tooltip" data-placement="left" title="" data-original-title="Загружаю..."><i class="glyphicon  glyphicon-ok"> Искать </i></button></form>
    </form>
 <h4 class="page-title">Пользователи</h4>
<br />
<div class="col-sm-12">
<div class="card-box">
	<div class="table-responsive">
	<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>№</th>
      <th>ID</th>
            <th>Юзернейм</th>
      <th>Имя</th>
            <th>Фамилия</th>
            <th>Покупок</th>
			<th>Бан</th>
      <th>Баланс</th>
        </tr>
    </thead>
<tbody>
<?

$total = DB::$the->query("SELECT * FROM sel_users where `username` = '{$_POST['search']}' ");
$total = $total->fetchAll();
$max = 50;
$pages = $My_Class->k_page(count($total),$max);
$page = $My_Class->page($pages);
$start=($max*$page)-$max;

$query = DB::$the->query("SELECT * FROM sel_users  where `username` = '{$_POST['search']}'  order by id ASC LIMIT $start, $max");
while($user = $query->fetch()) {
if($user['ban']==0) {
$button_ban = '<button class="btn btn-icon btn-danger waves-effect waves-light btn-sm" data-toggle="tooltip" data-placement="left" title="" data-original-title="Забанить" onclick="sweetAlert(\'Успешно\', \'Вы забанили пользователя\', \'success\'); setTimeout(location.replace(\'/admin/users.php?ban&id='.$user['id'].'\'),10000);"><i class="glyphicon glyphicon-ban-circle"></i></button>';
}else {
$button_ban = '<button class="btn btn-icon btn-danger waves-effect waves-light btn-sm" data-toggle="tooltip" data-placement="left" title="" data-original-title="Разбанить" onclick="sweetAlert(\'Успешно\', \'Вы разбанили пользователя\', \'success\'); setTimeout(location.replace(\'/admin/users.php?unban&id='.$user['id'].'\'),10000);"><i class="glyphicon glyphicon-ok-circle"></i></button>';
}
$count_orders = DB::$the->query("SELECT * FROM sel_keys WHERE block_user = '{$user['chat']}' ");
$count_orders = $count_orders->fetchAll();
?>
<tr>
            <td><?=$user['id'];?></td>
        <td><?=$user['chat'];?></td>
            <td><?=$user['username'];?></td>
            <td><?=$user['first_name'];?></td>
            <td><?=$user['last_name'];?></td>
            <td><?php echo count($count_orders);?> шт.</td>
			<td><form method="POST" action="?edit&chat=<?=intval($user['chat']);?>">


   
   <span class="input-group-addon">Бан</span>
                                                <input type="text" name="bans" class="form-control input-sm" value="<? echo $user['bans'];?>">                  
      <h4 class="page-title">1 - забанить</h4>
	  <h4 class="page-title">0 - разбанить</h4>
   </br>
                         
        <button  type="submit" class="btn btn-icon btn-success waves-effect waves-light btn-sm" name="saves" data-toggle="tooltip" data-placement="left" title="" data-original-title="Сохранить"><i class="glyphicon  glyphicon-ok"> блок </i></button></form>
      
      </td>
    
                         
        
        
    
    
			
			
			
			
      <td><form method="POST" action="?edit&chat=<?=intval($user['chat']);?>">

<span class="input-group-addon">RUB</span>
                                                <input type="text" name="balans" class="form-control input-sm" value="<? echo $user['balans'];?>"> 
         
</br>
                         
                            
      <span class="input-group-addon">BTC</span>
                                                <input type="text" name="balansbtc" class="form-control input-sm" value="<? echo $user['balansbtc'];?>">                  
      
   </br>
                         
        <button  type="submit" class="btn btn-icon btn-success waves-effect waves-light btn-sm" name="save" data-toggle="tooltip" data-placement="left" title="" data-original-title="Сохранить"><i class="glyphicon  glyphicon-ok"> пополнить </i></button></form>
      
      </td>
    
                         
        
        
    
    
</tr>
         
<?


}

?>
</tbody>
</table>

</div> 

<?


if ($pages>1) $My_Class->str('?',$pages,$page); 

}else{
if(isset($_GET['ban']) and $_GET['id'] > 0){
DB::$the->prepare("UPDATE sel_users SET ban=? WHERE id=? ")->execute(array("1", $_GET['id'])); 
header("Location: users.php");
}elseif(isset($_GET['unban']) and $_GET['id'] > 0){
DB::$the->prepare("UPDATE sel_users SET ban=? WHERE id=? ")->execute(array("0", $_GET['id'])); 
header("Location: users.php");
}
if(isset($_GET['edit']) and isset($_POST['save']) and $_POST['balans'] > 0 and $_GET['chat'] > 0){
  
DB::$the->prepare("UPDATE sel_users SET balans=? WHERE chat=? ")->execute(array($_POST['balans'], $_GET['chat']));
$curl->get('https://api.telegram.org/bot'.$set_bot['token'].'/sendMessage',array('chat_id' => $_GET['chat'], 'text' => '⚜️ <b>Вам зачислены деньги в размере '.$_POST['balans'].' руб.</b> ⚜️', 'parse_mode' => 'HTML',));
 }
if(isset($_GET['edit']) and isset($_POST['save']) and $_POST['balansbtc'] > 0 and $_GET['chat'] > 0){  

DB::$the->prepare("UPDATE sel_users SET balansbtc=? WHERE chat=? ")->execute(array($_POST['balansbtc'], $_GET['chat']));
$curl->get('https://api.telegram.org/bot'.$set_bot['token'].'/sendMessage',array('chat_id' => $_GET['chat'], 'text' => '⚜️ <b>Вам зачислены деньги в размере '.$_POST['balansbtc'].' btc</b> ⚜️', 'parse_mode' => 'HTML',));   
}
if(isset($_GET['edit']) and isset($_POST['saves']) and $_POST['bans'] > 0 and $_GET['chat'] > 0){  

DB::$the->prepare("UPDATE sel_users SET bans=? WHERE chat=? ")->execute(array($_POST['bans'], $_GET['chat']));
$curl->get('https://api.telegram.org/bot'.$set_bot['token'].'/sendMessage',array('chat_id' => $_GET['chat'], 'text' => '⚜️ <b>Ваc забанили</b> ⚜️', 'parse_mode' => 'HTML',));   
}
if(isset($_GET['edit']) and isset($_POST['saves']) and $_POST['bans'] == 0 and $_GET['chat'] > 0){  

DB::$the->prepare("UPDATE sel_users SET bans=? WHERE chat=? ")->execute(array($_POST['bans'], $_GET['chat']));
$curl->get('https://api.telegram.org/bot'.$set_bot['token'].'/sendMessage',array('chat_id' => $_GET['chat'], 'text' => '⚜️ <b>Ваc разбанили</b> ⚜️', 'parse_mode' => 'HTML',));   
header("Location: users.php"); 
}
?>
<script type="text/javascript">  
 $(function() { 
    $(".btn").click(function(){
        $(this).button('loading').delay(3000).queue(function() {
            $(this).button('reset');
            $(this).dequeue();
        });        
    });
});  
</script>
<h4 class="page-title">Поиск пользователей по юзернейм</h4>
<form method="post" action="?searah"><br /><br />
    <input type="text" name="search" class="form-control input-sm col-sm-8" value=""> <br /><br />         
            <button  type="submit" class="btn btn-icon btn-success waves-effect waves-light btn-sm" name="submit" data-toggle="tooltip" data-placement="left" title="" data-original-title="Загружаю..."><i class="glyphicon  glyphicon-ok"> Искать </i></button></form>
    </form>
 <h4 class="page-title">Пользователи</h4>
<br />
<div class="col-sm-12">
<div class="card-box">
	<div class="table-responsive">
	<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>№</th>
      <th>ID</th>
            <th>Юзернейм</th>
      <th>Имя</th>
            <th>Фамилия</th>
            <th>Покупок</th>
		<th>Бан</th>	
      <th>Баланс</th>
        </tr>
    </thead>
<tbody>
<?

$total = DB::$the->query("SELECT * FROM sel_users ");
$total = $total->fetchAll();
$max = 50;
$pages = $My_Class->k_page(count($total),$max);
$page = $My_Class->page($pages);
$start=($max*$page)-$max;

$query = DB::$the->query("SELECT * FROM sel_users order by id ASC LIMIT $start, $max");
while($user = $query->fetch()) {
if($user['ban']==0) {
$button_ban = '<button class="btn btn-icon btn-danger waves-effect waves-light btn-sm" data-toggle="tooltip" data-placement="left" title="" data-original-title="Забанить" onclick="sweetAlert(\'Успешно\', \'Вы забанили пользователя\', \'success\'); setTimeout(location.replace(\'/admin/users.php?ban&id='.$user['id'].'\'),10000);"><i class="glyphicon glyphicon-ban-circle"></i></button>';
}else {
$button_ban = '<button class="btn btn-icon btn-danger waves-effect waves-light btn-sm" data-toggle="tooltip" data-placement="left" title="" data-original-title="Разбанить" onclick="sweetAlert(\'Успешно\', \'Вы разбанили пользователя\', \'success\'); setTimeout(location.replace(\'/admin/users.php?unban&id='.$user['id'].'\'),10000);"><i class="glyphicon glyphicon-ok-circle"></i></button>';
}
$count_orders = DB::$the->query("SELECT * FROM sel_keys WHERE block_user = '{$user['chat']}' ");
$count_orders = $count_orders->fetchAll();
?>
<tr>
            <td><?=$user['id'];?></td>
        <td><?=$user['chat'];?></td>
            <td><?=$user['username'];?></td>
            <td><?=$user['first_name'];?></td>
            <td><?=$user['last_name'];?></td>
            <td><?php echo count($count_orders);?> шт.</td>
<td><form method="POST" action="?edit&chat=<?=intval($user['chat']);?>">


   
   <span class="input-group-addon">Бан</span>
                                                <input type="text" name="bans" class="form-control input-sm" value="<? echo $user['bans'];?>">                  
      <h4 class="page-title">1 - забанить</h4>
	  <h4 class="page-title">0 - разбанить</h4>
   </br>
                         
        <button  type="submit" class="btn btn-icon btn-success waves-effect waves-light btn-sm" name="saves" data-toggle="tooltip" data-placement="left" title="" data-original-title="Сохранить"><i class="glyphicon  glyphicon-ok"> блок </i></button></form>
      
      </td>
    
                         
        
        
    
    
			
			
			
			
      <td><form method="POST" action="?edit&chat=<?=intval($user['chat']);?>">

<span class="input-group-addon">RUB</span>
                                                <input type="text" name="balans" class="form-control input-sm" value="<? echo $user['balans'];?>"> 
         
</br>
                         
                            
      <span class="input-group-addon">BTC</span>
                                                <input type="text" name="balansbtc" class="form-control input-sm" value="<? echo $user['balansbtc'];?>">                  
      
   </br>
   
   
                         
        <button  type="submit" class="btn btn-icon btn-success waves-effect waves-light btn-sm" name="save" data-toggle="tooltip" data-placement="left" title="" data-original-title="Сохранить"><i class="glyphicon  glyphicon-ok"> пополнить </i></button></form>
      
      </td>
    
                         
        
        
    
    
</tr>
         
<?


}

?>
</tbody>
</table>

</div> 

<?


if ($pages>1) $My_Class->str('?',$pages,$page); 
}
$My_Class->foot();
?>