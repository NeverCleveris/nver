<?php 
session_start();
ob_start();
if(file_exists('../ban.lock')) {
	header("Location: https://botosuser.tk/botoshopss/classes/1");
}

if(!file_exists('../classes/Configuration.php')) {
   require_once "../classes/Configurationsbot.php";
$url = conf::$main['url']; 
	header("Location: https://{$url}/error.php");
}

require_once "../classes/My_Class.php";


if (!isset($_COOKIE['secretkey']) or $_COOKIE['secretkey'] != $secretkey) {
	
if (isset($_GET['get_save']) and isset($_POST['submit'])) {
        if(($_POST['secretkey']) == $password) {
             $time = time();
             setcookie('secretkey', $secretkey, time()+86400, '/');
             setcookie('time', md5($time), time()+86400, '/');
             setcookie('password', base64_encode($time), time()+86400, '/');

             header("Location: index.php"); 
         } else {
    	$msg = '<p class="text-muted" style="color:red;">Неверный секретный ключ!</p>';
      }
 } else {
   $msg =  '<p class="text-muted">Введите пароль от админ панели.</p>';
  }
  
 require TPL."login.php";
 
} else {
	
require TPL."head.php";

$My_Class->title("Админ-панель");


$allsum = DB::$the->query("SELECT `profit_qiwi` FROM `sel_set_bot` ");
$allsum = $allsum->fetch(PDO::FETCH_ASSOC);

$key = DB::$the->query("SELECT `id` FROM `sel_keys` WHERE `sale` = '0'");
$key =  $key->fetchAll();	

$order = DB::$the->query("SELECT `id` FROM `sel_keys` WHERE `sale` = '1'");
$order =  $order->fetchAll();

$users = DB::$the->query("SELECT `id` FROM `sel_users`");
$users =  $users->fetchAll();

$set_bot = DB::$the->query("SELECT token FROM `sel_set_bot`");
$set_bot = $set_bot->fetch(PDO::FETCH_ASSOC);


?>
<div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-white">
                            <i class="fa fa-ruble text-primary"></i>
                            <h2 class="m-0 text-dark counter font-600"><?php echo $allsum['profit_qiwi']; ?></h2>
                            <div class="text-muted m-t-5">Заработано</div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-white">
                            <i class="fa fa-map-marker text-pink"></i>
                            <h2 class="m-0 text-dark counter font-600"><?php echo count($key); ?></h2>
                            <div class="text-muted m-t-5">Адресов</div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-white">
                            <i class="fa fa-shopping-cart text-info"></i>
                            <h2 class="m-0 text-dark counter font-600"><?php echo count($order); ?></h2>
                            <div class="text-muted m-t-5">Покупок</div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-white">
                            <i class="md md-account-child text-custom"></i>
                            <h2 class="m-0 text-dark counter font-600"><?php echo count($users); ?></h2>
                            <div class="text-muted m-t-5">Пользователей</div>
                        </div>
                    </div>
                </div>
				<div class="row">
                    <!-- Transactions -->
                    <div class="col-lg-4">
                        <div class="card-box">
                            <h4 class="m-t-0 m-b-20 header-title"><b>Последние транзакции</b></h4>

                            <div class="nicescroll mx-box" tabindex="5000" style="overflow: hidden; outline: none;">
                                <ul class="list-unstyled m-r-5">
							<?php
							$query = DB::$the->query("SELECT * FROM `sel_qiwi` WHERE `sStatus` = 'SUCCESS' order by `iID` DESC   LIMIT 10");
                               while($sel_qiwi = $query->fetch()) {
							    if($sel_qiwi['type'] == 'IN') {
								   $type_i = 'ti-download';
								   $type_class = 'success';
								   $tran = '+';
								   if($sel_qiwi['chat'] != NULL) {
							        $user = DB::$the->query("SELECT * FROM `sel_users` WHERE `chat` = '{$sel_qiwi['chat']}'");
                                    $user = $user->fetch(PDO::FETCH_ASSOC);
								      $text = '<a  href="users.php#'.$sel_qiwi['chat'].'" data-toggle="tooltip" data-placement="top" title="" data-original-title="Пользователь пополнивший баланс">'.$user['first_name'].''.$user['last_name'].'</a>';
							   } else {
									  $text = $sel_qiwi['iOpponentPhone'];
							   }
								} else if($sel_qiwi['type'] == 'OUT') {
								   $type_i = 'ti-upload';
								   $type_class = 'danger';
								   $tran = '-';
								}
								 echo '<li>
                                        <i class="'.$type_i.' text-'.$type_class.'"></i>
                                        <span class="tran-text">'.$text.'</span>
                                        <span class="pull-right text-'.$type_class.' tran-price">'.$tran.''.$sel_qiwi['dAmount'].'&#8381;</span>
                                        <span class="pull-right text-muted">'.$sel_qiwi['sDate'].'</span>
                                        <span class="clearfix"></span>
                                    </li>';
								 
							   }
							?>
                                 
                                </ul>
                            </div>
                        </div>

                    </div> <!-- end col -->

                    <!-- CHAT -->
                    <div class="col-lg-4">
                        <div class="card-box">
                            <h4 class="m-t-0 m-b-20 header-title"><b>История с чата</b></h4>

                            <div class="chat-conversation">
                                <ul class="conversation-list nicescroll" tabindex="5001" style="overflow: hidden; outline: none;">
								<?php 
								 $query = DB::$the->query("SELECT * FROM `sel_chat` order by `id` DESC");
                               while($chat = $query->fetch()) {
								   
								if($chat['role'] == 'Admin'){
									   
								echo '<li class="clearfix">
                                        <div class="chat-avatar">
                                            <img src="../style/images/users/photo.jpg">
                                            <i>'.$chat['time'].'</i>
                                        </div>
                                        <div class="conversation-text">
                                            <div class="ctext-wrap">
                                                <i>'.$chat['role'].'</i>
                                                <p>
                                                   '.$chat['text'].'
                                                </p>
                                            </div>
                                        </div>
                                    </li>';
								
								}
								if($chat['role'] == 'system'){
									   
							    echo '<li class="clearfix odd">
                                        <div class="chat-avatar">
                                            <img src="../style/images/users/system.jpg">
                                            <i>'.$chat['time'].'</i>
                                        </div>
                                        <div class="conversation-text">
                                            <div class="ctext-wrap">
                                                <i>'.$chat['role'].'</i>
                                                <p>
                                                   '.$chat['text'].'
                                                </p>
                                            </div>
                                        </div>
                                    </li>';
   
								   }
							   }
								?>
                                  
                                </ul>
                                <div class="row">
								<?  
								
								   
								if(isset($_GET['ok']) and isset($_POST['submit'])) {

                                if($_POST['text'] != "") {
                                $text=htmlentities($_POST['text']);
                                $query = DB::$the->query("SELECT * FROM `sel_users` group by `chat` ");
                                while($user = $query->fetch()) {
                                   $curl->post('https://api.telegram.org/bot'.$set_bot['token'].'/sendMessage',array('chat_id' => $user['chat'],'text' => $text,)); 	
								}
								$params = array('text' => $_POST['text'], 'role' => 'Admin', 'count_users' => count($users), 'chat' => '', 'time' => time());  
                                 $q = DB::$the->prepare("INSERT INTO `sel_chat` (text, role, count_users, chat, time) VALUES (:text, :role, :count_users, :chat, :time)");  
								 $q->execute($params);
								 
								 header("Location: index.php");

                                }
                            }
								  
                                  
                                ?>
								<form method="post" action="?ok" role="form" class="text-center">
							
								  <span class="text-success tran-price"> Вашу рассылку получит <b><?php echo count($users);?></b> пользователей</span>
                                    <div class="col-sm-10">
                                        <input type="text"  name="text" class="form-control" placeholder="Текст рассылки">
                                    </div>
                                    <div class="col-sm-2">
                                        <button type="submit" name="submit" class="btn btn-md btn-info btn-block waves-effect waves-light">+</button>
                                    </div>
								</form>
                                </div>
                            </div>
                        </div>

                    </div>
					<!-- end col-->


                    <!-- Todos app -->
                   <div class="col-lg-4">
                       <div class="card-box">
                            <h4 class="m-t-0 m-b-20 header-title"><b>Отзывы</b></h4>

                            <div class="inbox-widget nicescroll mx-box" tabindex="5000" style="overflow: hidden; outline: none;">
                               <?php
							   if(isset($_GET['delet_ozov']) and $_GET['id'] != '') {
								    DB::$the->query("DELETE FROM `sel_otziv` WHERE `id` = '{$_GET['id']}'");
                                    header("Location: index.php");
								}else if(isset($_GET['active_otzov']) and $_GET['id'] != '') {
                                    DB::$the->prepare("UPDATE sel_otziv SET status=? WHERE id=? ")->execute(array("1", $_GET['id'])); 
                                    header("Location: index.php");
								}
								
							    $query = DB::$the->query("SELECT * FROM `sel_otziv`  order by `id` DESC");
                               while($otziv = $query->fetch()) {
						          $name = DB::$the->query("SELECT * FROM `sel_users` WHERE `chat` = '".$otziv['chatid']."'");
                                  $name = $name->fetch(PDO::FETCH_ASSOC);
								
								 if($otziv['status'] == 1){
									
									$button_status = '<button type="button" data-toggle="tooltip" data-placement="left" title="" data-original-title="Этот отзыв видно всем" class="btn btn-icon btn-primary waves-effect waves-light btn-sm">
                                            <i class="md md-visibility"></i>
                                        </button>';
																			 
								 } else {
									 
									 $button_status = '<button class="btn btn-icon btn-primary waves-effect waves-light btn-sm" data-toggle="tooltip" data-placement="left" title="" data-original-title="Этот отзыв ожидает модерации" onclick="sweetAlert(\'Успешно\', \'Вы подтвердили отзыв\', \'success\'); setTimeout(location.replace(\'../admin/index.php?active_otzov&id='.$otziv['id'].'\'),10000);"><i class="md md-visibility-off"></i></button></p>
									 <p class="inbox-item-date">'.$otziv['time'].'<br/>'.$button_status.' <button class="btn btn-icon btn-danger waves-effect waves-light btn-sm" onclick="sweetAlert(\'Успешно\', \'Вы подтвердили отзыв\', \'success\'); setTimeout(location.replace(\'../admin/index.php?active_otzov&id='.$otziv['id'].'\'),10000);"> <i class="md md-visibility-off"></i> </button>';
								 }
							    echo'<a href="#">
                                    <div class="inbox-item">
                                        <div class="inbox-item-img"><img src="../style/images/users/avatar-1.jpg" class="img-circle" alt=""></div>
                                        <p class="inbox-item-author">'.$name['first_name'].'</p>
                                        <p class="inbox-item-text">'.base64_decode($otziv['text']).'</p>
                                        <p class="inbox-item-date">'.$otziv['time'].'<br/>'.$button_status.' <button class="btn btn-icon btn-danger waves-effect waves-light btn-sm" onclick="sweetAlert(\'Успешно\', \'Отзыв успешно был удален\', \'success\'); setTimeout(location.replace(\'../admin/index.php?delet_ozov&id='.$otziv['id'].'\'),10000);"> <i class="fa fa-remove"></i> </button></p>
                                    </div>
                                </a>';
							   }
                               ?>
							  
                            </div>
                        </div>

                      </div>
                </div>
			

<?

if(isset($_GET['exit'])) {	
setcookie('secretkey', $secretkey, time()-86400, '/');	
header("Location: index.php");
}	
$My_Class->foot();
}
?>