<?php 
ob_start();

require_once "../classes/My_Class.php";
require_once "../classes/engine.php";


if (!isset($_COOKIE['secretkey']) or $_COOKIE['secretkey'] != $secretkey) {
header("Location: index.php");		
exit;
}


require TPL."head.php";

$My_Class->title("Адреса");


if(isset($_GET['cmd'])){$cmd = htmlspecialchars($_GET['cmd']);}else{$cmd = '0';}

?> 
<script type="text/javascript">  
 $(function() { 
    $(".btn").click(function(){
        $(this).button('loading').delay(3000).queue(function() {
            $(this).button('reset');
            $(this).dequeue();
        });        
    });
});  
</script>
<?

switch ($cmd){
case 'sale_null':


?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>  <li class="active">Проданные/не проданные Адреса</li>
</ol>


<div class="list-group">
  <a href="keys.php" class="list-group-item">
    Проданные Адреса
  </a>
  <a class="list-group-item active">Не проданные Адреса</a>
</div>

	<div class="table-responsive">
	<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th  style="text-align:center;">№</th>
            <th  style="text-align:center;">Время добавления товара</th>
            <th style="text-align:center;">Адрес</th>
            <th  style="text-align:center;">Город</th>
			<th  style="text-align:center;">Район</th>
            <th  style="text-align:center;">Товар</th>
            <th  style="text-align:center;">Фасовка</th>
        </tr>
    </thead>
<tbody>
<?

$total = DB::$the->query("SELECT * FROM `sel_keys` where `sale` = '0' ");
$total = $total->fetchAll();
$max = 10;
$pages = $My_Class->k_page(count($total),$max);
$page = $My_Class->page($pages);
$start=($max*$page)-$max;

$query = DB::$the->query("SELECT * FROM `sel_keys` where `sale` = '0' order by `id` DESC LIMIT $start, $max");
while($key = $query->fetch()) {
$cat = DB::$the->query("SELECT name FROM `sel_category` WHERE `id` = {$key['id_cat']} ");
$cat = $cat->fetch(PDO::FETCH_ASSOC);

$subcats = DB::$the->query("SELECT * FROM `sel_cat` WHERE `id` = '".$key['id_subcats']."' ");
$subcats = $subcats->fetch(PDO::FETCH_ASSOC);


$subcat = DB::$the->query("SELECT name FROM `sel_subcategory` WHERE `id` = {$key['id_subcat']} ");
$subcat = $subcat->fetch(PDO::FETCH_ASSOC);

$subcatss = DB::$the->query("SELECT name FROM `sel_subcat` WHERE `id` = {$key['id_cats']} ");
$subcatss = $subcatss->fetch(PDO::FETCH_ASSOC);

$id_user = DB::$the->query("SELECT chat FROM `sel_orders` WHERE `id_key` = {$key['id']} ");
$id_user = $id_user->fetch(PDO::FETCH_ASSOC);			
?>
<tr>
            <td  align="center"><?=$key['id'];?></td>
	        <td  align="center"><?=$date = $eng->showtime($key['time'], 1);?></td>		
            <td  align="center"><?=$key['code'];?></td>	
            <td  align="center"><?=$cat['name'];?></td>
			<td  align="center"><?=$subcats['name'];?></td>
            <td  align="center"><?=$subcat['name'];?></td>
            <td  align="center"><?=$subcatss['name'];?></td>
</tr>
<?	


}

?>
</tbody>
</table>
</div> 

<?
if ($pages>1) $My_Class->str('?cmd=sale_null&',$pages,$page); 

break;
	
default:

?>
<ol class="breadcrumb">
<li><a href="index.php">Админ-панель</a></li>  <li class="active">Проданные/не проданные Адреса</li>
</ol>

<div class="list-group">
  <a  class="list-group-item active">
    Проданные Адреса
  </a>
  <a href="?cmd=sale_null" class="list-group-item">Не проданные Адреса</a>
</div>

	<div class="table-responsive">
	<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th  style="text-align:center;">№</th>
			<th  style="text-align:center;">Время добавления товара</th>
            <th  style="text-align:center;">Адрес</th>
<th>Город <br/><small>Район</small></th>
         <th>Товар<br/><small>Фасовка</small></th>
            
            <th  style="text-align:center;">ID</th>
			<th  style="text-align:center;">Никнейм</th>
			<th  style="text-align:center;">Имя</th>
			<th  style="text-align:center;">Фамилия</th>
			<th  style="text-align:center;">Время покупки</th>
        </tr>
    </thead>
<tbody>
<?

$total = DB::$the->query("SELECT * FROM `sel_keys` where `sale` = '1' ");
$total = $total->fetchAll();
$max = 10;
$pages = $My_Class->k_page(count($total),$max);
$page = $My_Class->page($pages);
$start=($max*$page)-$max;

$query = DB::$the->query("SELECT * FROM `sel_keys` where `sale` = '1' order by `id` DESC LIMIT $start, $max");
while($key = $query->fetch()) {
$cat = DB::$the->query("SELECT name FROM `sel_category` WHERE `id` = {$key['id_cat']} ");
$cat = $cat->fetch(PDO::FETCH_ASSOC);

$subcats = DB::$the->query("SELECT * FROM `sel_cat` WHERE `id` = '".$key['id_subcats']."' ");
$subcats = $subcats->fetch(PDO::FETCH_ASSOC);

$subcat = DB::$the->query("SELECT name FROM `sel_subcategory` WHERE `id` = {$key['id_subcat']} ");
$subcat = $subcat->fetch(PDO::FETCH_ASSOC);

$subcatss = DB::$the->query("SELECT name FROM `sel_subcat` WHERE `id` = {$key['id_cats']} ");
$subcatss = $subcatss->fetch(PDO::FETCH_ASSOC);

$userss = DB::$the->query("SELECT * FROM `sel_users` WHERE `chat` = {$key['usersi']} ");
$userss = $userss->fetch(PDO::FETCH_ASSOC);

$orders = DB::$the->query("SELECT * FROM `sel_keys` where `sale` = '1' and `block_user` = '{$chat}' ");
$orders = $orders->fetchAll();

$keys = DB::$the->query("SELECT id_key,id_subcat,code,time FROM `sel_orders` where `chat` = '{$chat}' ");
$keys = $keys->fetch(PDO::FETCH_ASSOC);

$id_user = DB::$the->query("SELECT time FROM `sel_orders` WHERE `id_key` = {$key['id']} ");
$id_user = $id_user->fetch(PDO::FETCH_ASSOC);

$datess = $eng->showtime($key['time'], 1);		
?>
<tr>
            <td  align="center"><?=$key['id'];?></td>
			<td  align="center"><?=$date = $eng->showtime($key['time'], 1);?></td>
            <td  align="center"><?=$key['code'];?></td>	

<td><?=$cat['name'];?> <br/><small><?=$subcats['name'];?></small></td>
<td><?=$subcat['name'];?> <br/><small><?=$subcatss['name'];?></small></td>                                                    

        
			
			<td  align="center"><?=$key['usersi'];?></td>
			<td  align="center"><?=$userss['username'];?></td>
			<td  align="center"><?=$userss['first_name'];?></td>
			<td  align="center"><?=$userss['last_name'];?></td>
			<td  align="center"><?=$date = $eng->showtime($key['time_buy'], 1);?></td>
</tr>
<?	


}

?>
</tbody>
</table>
</div> 

<?
if ($pages>1) $My_Class->str('?',$pages,$page); 

}

$My_Class->foot();
?>