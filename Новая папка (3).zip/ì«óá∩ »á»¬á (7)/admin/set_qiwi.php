<?php
ob_start();

require_once "../classes/My_Class.php";
require_once TPL."head.php";


if (!isset($_COOKIE['secretkey']) or $_COOKIE['secretkey'] != $secretkey) {
header("Location: index.php"); exit;
}

?>

<script type="text/javascript">  
 $(function() { 
    $(".btn").click(function(){
        $(this).button('loading').delay(3000).queue(function() {
            $(this).button('reset');
            $(this).dequeue();
        });        
    });
});  
</script>


<?
# Получаем информацию из БД о настройках бота
$set_bot = DB::$the->query("SELECT * FROM `sel_set_bot` ");
$set_bot = $set_bot->fetch(PDO::FETCH_ASSOC);

if(isset($_GET['transferMoney']) and $_GET['id'] > 0) {

     $set_qiwi = DB::$the->query("SELECT * FROM `sel_set_qiwi` WHERE `id` = '{$_GET['id']}' ");
    $set_qiwi = $set_qiwi->fetch(PDO::FETCH_ASSOC);
	
	$number = $set_qiwi["number"];
$password = $set_qiwi["password"];

	$My_Class->title("Переводов средсв с QIWI {$number}");
	
	$qiwi = new QiwiApi($set_qiwi["number"], $set_qiwi["password"], true);
	$methods = new QiwiApi();
	
$balance = $qiwi->getLoadBalance();
if(isset($_GET['ok']) and isset($_POST['transfer'])) {
$amount = $_POST['sum'];
$date = time();
$id = 1000 * time();
$tr = $qiwi->$_POST['methods']([
"id" =>  "{$id}",
"sum" => [
				"amount"=> $amount,
				"currency" => "643"
	],
 "paymentMethod" => [
			"type" => "Account",
			"accountId" => "643"
	],
	"comment" => "{$_POST['comment']}",
	"fields" => [
	 			"account" => "{$_POST['number']}"
	]
 ]);
   print_r($tr);
}
?>

<ol class="breadcrumb">
  <li><a href="../admin">Главная</a></li>
  <li><a href="../admin/set_qiwi.php">Управление <font color="orange">Qiwi N° 1</font> </a></li>
  <li class="active">Перевод средств </li>
</ol>
<br />
<form method="POST" action="?transferMoney&id=<?=$_GET['id'];?>&ok">
	
    <div class="col-sm-12">
<div class="card-box">
	<div class="form-group">
      <label for="exampleSelect1">Выбор направления перевода средств с <font color="orange">QIWI</font> +<?php echo $number; ?></label>
      <select class="form-control" id="exampleSelect1" for="inputSuccess1" name="methods">
      	<option value="">....</option>
        <option value="sendMoneyToQiwi">Visa Qiwi Wallet</option>
        <option value="sendMoneyToYandex">Яндекс.Деньги</option>
        <option value="sendMoneyToWebMany">Bitcoin WebMoney</option>
        <option value="sendMoneyToTele2">Теле 2 </option>
        <option value="sendMoneyToMir">Карта МИР</option>
        <option value="sendMoneyToVisa">Карта VISA</option>
        <option value="sendMoneyToMaster">Карта Mastercard и Maestro</option>
      </select>
    </div>
    <label for="exampleSelect1"><button type="button" class="btn btn-secondary" data-toggle="tooltip" data-placement="top" title="" data-original-title="При переводе на QIWI номер указывать в формате +7хххххххххх*При переводе на баланс телефона номер указывать без +7*При переводе на карты номер карты указывать без пробелов
" aria-describedby="tooltip662686"><font color="red">*</font>Информация о направлении перевода</button></label>
   
</br>
<div class="input-group">	
    <span class="input-group-addon">Номер счёта</span>
    <input type="text" class="form-control" name="number" value="">
	</div><br />
	
	<label for="exampleSelect1"><button type="button" class="btn btn-secondary" data-toggle="tooltip" data-placement="top" title="" data-original-title="При совершении перевода, в зависимости от метода направления, взымается комиссия Qiwi. Во избежание ошибочного перевода, учитывайте размер комиссии и вписывайте сумму с её вычетом. 
" aria-describedby="tooltip662686"><font color="red">*</font>Информация о сумме перевода</button></label>
</br>
	
<div class="input-group">	
	<span class="input-group-addon">Сумма</span>
    <input type="text" class="form-control" name="sum" placeholder="Ваш баланс: <?php echo round($balance['accounts'][0]['balance']['amount'] - 0);?> руб.">
	<span class="input-group-addon"><font color="green"><span class="glyphicon glyphicon-rub"></font></span>
</div><br/>

<div class="input-group">	
	<span class="input-group-addon">Комментарий</span>
    <input type="text" class="form-control" name="comment" placeholder="Необходимый текст">
</div><br />
<hr>
	
<button type="submit" name="transfer" data-loading-text="Переважу" class="btn btn-default btn-lg btn-block">Перевести</button></form>
</div>
</div>
<?


   $My_Class->foot();



   

}elseif(isset($_GET['history']) and $_GET['id'] > 0) {

	$set_qiwi = DB::$the->query("SELECT * FROM `sel_set_qiwi` WHERE `id` = '{$_GET['id']}' ");
    $set_qiwi = $set_qiwi->fetch(PDO::FETCH_ASSOC);
	


$number = $set_qiwi["number"];
$password = $set_qiwi["password"];	

		$My_Class->title("История транзакций QIWI +{$number}");


$qiwi = new QiwiApi($set_qiwi["number"], $set_qiwi["password"], true);

		
		echo'<ol class="breadcrumb">
  <li><a href="../admin">Главная</a></li>
  <li><a href="../admin/set_qiwi.php">Управление <font color="orange">Qiwi N° 1</font> </a></li>
  <li class="active">История  <font color="orange">QIWI</font> <i><font color="green"><b>+'.$number.'</b></font></i></li>
</ol>';
		
   
	
	
	
	echo'
                                    	
                                    <div class="table-responsive">
	<table class="table table-bordered table-striped">
    <thead>
        <tr>
                                    <th><font color="blue">#</font></th>
                                        <th><font color="blue">Номер</font></th>
                                        <th><font color="blue">Дата</font></th>
                                       <th><font color="blue">Комментарий</font></th>
										 <th><font color="blue">Сумма</font></th>
										 	 <th><font color="blue">Действие</font></th>
										  <th><font color="blue">Провайдер</font></th>
                                        <th class="text-center"><font color="blue">Статус</font></th>
                                    </tr>
                                </thead>

                                            <tbody>';
 $tr = $qiwi->getLoadHistory([
 'rows' => '50',
 'operation' => 'ALL',
 'sources[0]' => 'QW_RUB'
 ]);
	
       foreach ($tr["data"] as $sel_qiwi) {
	    $date = substr($sel_qiwi['date'], 0, 19);
		$date = str_replace("T"," ",$date);
		if($sel_qiwi['statusText'] == "Success"){
			$class = 'success';
		}elseif($sel_qiwi['statusText'] == "Error"){
			$class = 'danger';
		}elseif($sel_qiwi['statusText'] == "Operation in progress"){
			$class = 'warning';
		}
           echo '    <tr>
                                                    <td><span class="label label-table label-'.$class.'">'.$sel_qiwi['trmTxnId'].'</span></td>
													<td><span class="label label-table label-'.$class.'"><font color="blue">'.$sel_qiwi['account'].'</font></span></td>
                                                    <td><span class="label label-table label-'.$class.'">'.$date.'</span></td>
                                                    <td><span class="label label-table label-'.$class.'">'.$sel_qiwi['comment'].'</span></td>
                                                    <td><span class="label label-table label-'.$class.'"><font color="blue">'.$sel_qiwi['total']['amount'].' </font>₽</span></td>
                                                    <td><span class="label label-table label-'.$class.'">'.$sel_qiwi['type'].'</span></td>
													 <td><span class="label label-table label-'.$class.'">'.$sel_qiwi['provider']['shortName'].'</span></td>
											
													<td><span class="label label-table label-'.$class.'">'.$sel_qiwi['statusText'].'</span></td>

                                               </tr>
												';

	   }	   
        echo '
                                </tbody>
                            </table>
							  </div>
                        </div>
                    </div>
           

';

		$My_Class->foot();

}else{
	$My_Class->title("Управление Qiwi N° 1");
	
$row = DB::$the->query("SELECT * FROM `sel_set_qiwi` ");
$set = $row->fetch(PDO::FETCH_ASSOC);

$row = DB::$the->query("SELECT * FROM `sel_set_bot` ");
$sets = $row->fetch(PDO::FETCH_ASSOC);

if(isset($_GET['ok']) and isset($_POST['submit'])) {
	

if($_POST['token1'] != "") {

	
$password1= $_POST['token1'];
$number1 = $_POST['number1'];
$amount= $_POST['amount'];
$number = $_POST['number'];

DB::$the->prepare("UPDATE sel_set_qiwi SET number=? WHERE id=?")->execute(array("$number1", "1")); 

DB::$the->prepare("UPDATE sel_set_qiwi SET password=? WHERE id=?")->execute(array("$password1", "1")); 

DB::$the->prepare("UPDATE sel_set_qiwi SET active=? ")->execute(array("0")); 

DB::$the->prepare("UPDATE sel_set_qiwi SET active=? WHERE id=?")->execute(array("1", "1")); 


DB::$the->prepare("UPDATE sel_set_bot SET amount=? ")->execute(array("$amount")); 

DB::$the->prepare("UPDATE sel_set_bot SET number=? ")->execute(array("$number")); 


header("Location: set_qiwi.php");
}else {
	 echo $eng->msg("2", "Первый номер и пароль обязательный к заполнению!", "2");
}
}


?>
<div class="row">
                    <div class="col-sm-12">
                        <div class="button-list pull-right">
                            <a  class="btn btn-info waves-effect waves-light" href="set_qiwik.php"><i class="fa fa-plus m-r-5"></i> <span>Добавить Кошелек</span></a>

                           
                        </div>

                        <h4 class="page-title">Управление <font color="orange">Qiwi N° 1</font> </h4>
                      
                    </div>
                </div><br />
<center>

<?php


  $query = DB::$the->query("SELECT * FROM `sel_set_qiwi` order by `id`");
    while($row = $query->fetch()) {
		
      $number = $row["number"];
      $password = $row["password"];	
	  
$qiwi = new QiwiApi($number, $password, true);
		
		 $account = $qiwi->getAccount();
		 
    if($account['contractInfo']['blocked'] == false and $account['contractInfo']['contractId'] != ''){
	
	
	
	
	
	
      echo'<div class="row">
	  <div class="col-lg-7">
  <div class="panel panel-default">
	<div class="panel-heading"><input type="radio" name="active" value="'.$row["id"].'"'; if($row["active"] == '1') echo 'checked'; echo'> <font color="green"><b></b>'; if($row["active"] == '1') echo ' <b>'.$row["number"].' </b>'; echo'</font> [ Обновлялся: <b>5 мин назад</b> ]
                                 
								
						</div>
						<form method="POST" action="?ok">
 <div class="panel-body">	
 <div class="input-group input-group-lg">	
	<span class="input-group-addon">Номер </span>
		
    <input type="text" class="form-control" placeholder="7999999999" name="number'.$row["id"].'" value="'.$row["number"].'">
	</div><br/>
	
	<div class="input-group input-group-lg">
    <span class="input-group-addon">Token</span>

    <input type="text"  class="form-control" placeholder="Qiwi Token" name="token'.$row["id"].'" value="'.$row["password"].'">
	</div>
<br/>

<label for="exampleSelect1"><button type="button" class="btn btn-secondary" data-toggle="tooltip" data-placement="top" title="" data-original-title="Введите Ваш кошелёк Яндекс.Деньги, для автоматического перевода с киви на Яндекс
" aria-describedby="tooltip662686"><font color="red">*</font>Информация</button></label>
</br>
	

	<div class="input-group input-group-lg">
    <span class="input-group-addon"><b><font color="orange">Яндекс.Деньги</font>  Автоперевод</b></span>

    <input type="text"  class="form-control" placeholder="Номер кошелька" name="number" value="'.$sets['number'].'">
	</div><br/>
	
	<label for="exampleSelect1"><button type="button" class="btn btn-secondary" data-toggle="tooltip" data-placement="top" title="" data-original-title="Сумму автоперевода вводить, если отключён полный вывод суммы баланса
" aria-describedby="tooltip662686"><font color="red">*</font>Информация о сумме перевода</button></label>
</br>
	
	<div class="input-group input-group-lg">
    <span class="input-group-addon">Сумма автоперевода</span>

    <input type="text"  class="form-control" placeholder="10000" name="amount" value="'.$sets['amount'].'">
												</div><br/>
												
	
	
                                                <span class="input-group-btn">
											 </span>
                                            </div>
								
	
<div class="input-group input-group-lg"><br />	
<ul>
<a type="submit" href="?history&id='.$row["id"].'" data-loading-text="Загружаем" class="btn btn-min btn-info waves-effect waves-light w-md">История переводов</a>
<a type="submit" href="?transferMoney&id='.$row["id"].'" data-loading-text="Загружаем" class="btn btn-min btn-warning waves-effect waves-light">Перевод средств </a>
</ul>
    </div>';

	
	$oborot = DB::$the->query("SELECT sum(dAmount) FROM `sel_qiwi` where `iAccount` = ".$number." ");
    $oborot = $oborot->fetchAll();
	
	if($oborot[0]["sum(dAmount)"] == '') $sum = 0; else $sum = $oborot[0]["sum(dAmount)"];

	echo '<div class="input-group input-group-lg">
		<span style="size:4"> 
<span class="input-group-addon">Заработано: '.$eng->declOfNum('<b>'.$sum.'</b>', array('Рубль','Рубля','Рублей')) .'</span>
		<span class="input-group-addon"> <font color="green">'. $account['userInfo']['operator'].'</font> </span>
	<span class="input-group-addon">Баланс: '.$eng->declOfNum('<b>'.$row['balanse'].'</b>', array('Рубль','Рубля','Рублей')).'</span>
</div></div></div>
</div>


';


  }else if($row["number"] == "" or $row["active"] == 2){
      echo'<div class="row">
	  <div class="col-lg-7">
  <div class="panel panel-default">
<div class="panel-heading"><input type="radio" name="active" value="'.$row["id"].'"'; if($row["active"] == '1') echo 'checked'; echo'> № '.$row["id"].' : <font color="red"><b>[OFF]</b> Ошибка подключения</font> [ Обновлялся: <b>3 мин назад</b> ]

 <div class="panel-body">';
 echo $eng->msg("2", "Code: {$row["error"]} Messages: Неверный токен или истек срок действия токена.", "2");
echo'<div class="input-group input-group-lg">	
	<span class="input-group-addon">Номер </span>
    <input type="text" class="form-control" name="number'.$row["id"].'" value="'.$row["number"].'" readonly>
	</div><br/>';


echo'
<div class="input-group input-group-lg">
                                               	<span class="input-group-addon">Token</span>

                                                <input type="text"  class="form-control" placeholder="<font color="orange">Qiwi</font>  Token" name="token'.$row["id"].'" value="'.$row["password"].'">
                                                <span class="input-group-btn">
											 </span>
                                            </div>
											 
    </div>
</div>
</form>
	   
';

  }
} 

echo'<form><div class="panel panel-default">
<button type="submit" name="submit" data-loading-text="Сохраняю" class="btn btn-default btn-lg btn-block">Сохранить</button></form>
</div></div></div></div>
</div>

';


$My_Class->foot();
}
?>
