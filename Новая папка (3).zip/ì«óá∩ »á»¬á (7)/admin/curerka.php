<?php 
ob_start();
require_once "../classes/Configuration.php";
require_once "../classes/My_Class.php";
require_once TPL."head.php";

if (!isset($_COOKIE['secretkey']) or $_COOKIE['secretkey'] != $secretkey) {
           header("Location: index.php"); 
exit;
}


$My_Class->title("Список курьеров");

if (!isset($_COOKIE['secretkey']) or $_COOKIE['secretkey'] != $secretkey) {
           header("Location: index.php"); exit;
}


$curl = new Curl();
$set_bot = DB::$the->query("SELECT * FROM `sel_set_bot` ");
$set_bot = $set_bot->fetch(PDO::FETCH_ASSOC);


if($_GET['cmd'] == 'ok'){
$users = DB::$the->query("SELECT * FROM `sel_curers` WHERE `login` = '{$_POST['login']}' ");
$users = $users->fetch(PDO::FETCH_ASSOC);
	if($users['login'] == NULL){
$params = array('login' => ''.$_POST['login'].'', 'password' => ''.$_POST['password'].'', 'category' => ''.$_POST['cat'].'', 'date_reg' =>''.time().'', 'number' =>''.$_POST['number'].'');  
$q= DB::$the->prepare("INSERT INTO `sel_curers` (login, password, category, date_reg, number) VALUES (:login, :password, :category, :date_reg, :number)");  
$q->execute($params);
	}
header("Location: curerka.php");
}

if($_GET['cmd'] == 'dell'){
if($_GET['ok'] == '1'){
	
	DB::$the->query("DELETE FROM `sel_curers` WHERE `id` = '".$_GET['id']."' ");
	header("Location: curerka.php");

}?>
<div class="alert alert-danger">Курьер будет удален навсегда!</div>

<div class="btn-group">
  <button type="button" class="btn btn-danger dropdown-toggle" data-loading-text="Думаем" data-toggle="dropdown">Вы уверены? <span class="caret"></span></button>
  <ul class="dropdown-menu" role="menu">
    <li><a href="?cmd=dell&ok=1&id=<?=$_GET['id']?>">Да, удалить</a></li>
    <li class="divider"></li>
    <li><a href="curerka.php">Нет, отменить</a></li>
  </ul>
</div><br /><br />
<?
}
if($_GET['cmd'] == 'setting'){
	
	if(isset($_GET['ok'])){
		
		DB::$the->prepare("UPDATE sel_set_bot SET zp_cur=? ")->execute(array($_POST['amount'])); 
		DB::$the->prepare("UPDATE sel_set_bot SET zp_cur_date=? ")->execute(array($_POST['date'])); 
		DB::$the->prepare("UPDATE sel_set_bot SET zp_cur_time=? ")->execute(array($_POST['time'])); 

			header("Location: curerka.php");

	}
	?>



 <h4 class="page-title">Настройки </h4>
<?php echo $msg;


	?>
	
 <div class="pull-left"><a  href="<?php echo SITEDIR ?>/admin/curerka.php" class="btn btn-icon btn-success waves-effect waves-light btn-sm" style="margin-bottom: 10px;">Назад</a><small> к списку курьеров</small></div>
                     
               <br />
				
<div class="col-sm-12">
<div class="card-box">
<form method="POST" action="?cmd=setting&ok" enctype="multipart/form-data">

<div class="input-group input-group-lg">	
	<span class="input-group-addon">За 1 товар</span>
<input type="text" class="form-control" placeholder="Введите сумму которую курер будет получать за 1 адрес" name="amount" value="<?php echo $set_bot['zp_cur'];?>">

    </div><br />
<div class="input-group input-group-lg">	
	<span class="input-group-addon">Даты получения зп</span>
	<div class="bootstrap-select show-tick" style="height: 48px;">
<select class="selectpicker" multiple="" name="date"  value="<?php echo $set_bot['zp_cur_date'];?>" data-style="btn-white" tabindex="-98">
                                       
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                            <option value="5">5</option>
                                            <option value="6">6</option>
                                            <option value="7">7</option>
                                            <option value="8">8</option>
                                            <option value="9">9</option>
                                            <option value="10">10</option>
                                            <option value="12">12</option>
                                            <option value="13">13</option>
                                            <option value="14">14</option>
                                            <option value="15">15</option>
                                            <option value="17">17</option>
                                            <option value="18">18</option>
                                            <option value="19">19</option>
                                            <option value="20">20</option>
                                            <option value="21">21</option>
                                            <option value="22">22</option>
                                            <option value="23">23</option>
                                            <option value="24">24</option>
                                            <option value="25">25</option>
                                            <option value="26">26</option>
                                            <option value="27">27</option>
                                            <option value="28">28</option>
                                            <option value="29">29</option>
                                            <option value="30">30</option>
											<option value="31">31</option>


                                        </select></div>
  </div><br />	
<label>Время</label><div class="input-group clockpicker m-b-20" data-placement="top" data-align="top" data-autoclose="true">
                                <input type="text" class="form-control" name="time" placeholder="Время выполнения переводов" value="<?php echo $set_bot['zp_cur_time'];?>">
                                <span class="input-group-addon"> <span class="md md-access-time"></span> </span>
                            </div>
	<div class="input-group input-group-lg">	
<br />
<hr>
<button type="submit" name="submit" data-loading-text="Сохраняю" class="btn btn-danger btn-lg btn-block">Сохранить</button>
</form>
</div>
</div>
</div>
<?
$My_Class->foot();
}else
if($_GET['cmd'] == 'add'){?>



 <h4 class="page-title">Добавить курьера</h4>
<?php echo $msg;


	$sql = DB::$the->query("SELECT * FROM `sel_category`");
	
	$cat = '<select class="form-control" name="cat">';
	while($row = $sql->fetch()){
		$cat .= '<option value="'.$row['id'].'">'.$row['name'].'</option>';
	}
		$cat .= '</select>';

	?>
	
 <div class="pull-left"><a  href="<?php echo SITEDIR ?>/admin/curerka.php" class="btn btn-icon btn-success waves-effect waves-light btn-sm" style="margin-bottom: 10px;">Назад</a><small> к списку курьеров</small></div>
                     
               <br />
				
<form method="POST" action="?cmd=ok">
<div class="col-sm-12">
<div class="card-box">
<div class="input-group input-group-lg">
    <span class="input-group-addon">Login</span>
    <input type="text" class="form-control" name="login">
	</div><br />
<div class="input-group input-group-lg">	
	<span class="input-group-addon">Password</span>
    <input type="text" class="form-control" name="password">
    </div><br />
<div class="input-group input-group-lg">	
	<span class="input-group-addon">Number</span>
    <input type="text" class="form-control" name="number">
    </div><br />		
<div class="input-group input-group-lg">	
	<span class="input-group-addon">В городе</span>
	<?=$cat;?>
    </div><br />
	
	
<hr>
<button type="submit" name="submit" data-loading-text="Сохраняю" class="btn btn-danger btn-lg btn-block">Добавить</button>
</form>
</div>
</div>

<?

$My_Class->foot();
?>	
	
<?php
}else{
	  function birthday($sec_birthday)
  {
    // Сегодняшняя дата
    $sec_now = time();
    // Подсчитываем количество месяцев, лет
    for($time = $sec_birthday, $month = 0; 
        $time < $sec_now; 
        $time = $time + date('t', $time) * 86400, $month++){
        $rtime = $time;
        }
    $month = $month - 1;
    // Количество лет
    $year = intval($month / 12);
    // Количество месяцев
    $month = $month % 12;
    // Количество дней
    $day = intval(($sec_now - $rtime) / 86400);

    $result .= declination($day, "день", "дня", "дней")." ";
    return $result;
  }

  // Склонение числа $num
  function declination($num, $one, $ed, $mn, $notnumber = false)
  {  
  
    if($num === "") print "";
    if(($num == "0") or (($num >= "5") and ($num <= "20")) or preg_match("|[056789]$|",$num))
      if(!$notnumber)
        return "$num $mn";
      else
        return $mn;
    if(preg_match("|[1]$|",$num))
      if(!$notnumber)
        return "$num $one";
      else
        return $one;
    if(preg_match("|[234]$|",$num))
      if(!$notnumber)
        return "$num $ed";
      else
        return $ed;
  }
?>
<script type="text/javascript">  
 $(function() { 
    $(".btn").click(function(){
        $(this).button('loading').delay(3000).queue(function() {
            $(this).button('reset');
            $(this).dequeue();
        });        
    });
});  
</script>

<div class="col-sm-12">
<div class="card-box">
<div id="msg">
<div class="alert alert-info">
              <button type="button" class="close" data-dismiss="alert">x</button><br>
              
              <strong>Внимание!</strong> Адрес Курьер-панели <?php echo SITEDIR ?>/curpanel/index.php
</div>
</div>

<h4 class="page-title">Список курьеров</h4>
<br />
<div class="col-sm-12"></div><br /><br />
<div class="card-box">
<div class="pull-left"><a  href="/idshop/admin/users.php" class="btn btn-icon btn-success waves-effect waves-light btn-sm" style="margin-bottom: 10px;">Назад</a><small> к пользователям</small></div>
<div class="pull-right"><a  href="?cmd=add" class="btn btn-icon btn-success waves-effect waves-light btn-sm" style="margin-bottom: 10px;"> Добавить курьера</a>     <a  href="?cmd=setting" class="btn btn-icon btn-success waves-effect waves-light btn-sm" style="margin-bottom: 10px;"> Настройки</a></div>
	<div class="table-responsive">
	<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>№</th>
			<th>Логин</th>
            <th>Пароль</th>
			<th>Город</th>
            <th>Работает</th>
            <th>Добавил</th>
			<th>На сумму</th>
			<th>Заработал</th>
			<th>Получил зп</th>
			<th>Выплатить зп</th>
			<th>Удалить</th>
        </tr>
    </thead>
<tbody>
<?

$total = DB::$the->query("SELECT * FROM `sel_curers` ");
$total = $total->fetchAll();
$max = 50;
$pages = $My_Class->k_page(count($total),$max);
$page = $My_Class->page($pages);
$start=($max*$page)-$max;

$sql = DB::$the->query("SELECT * FROM `sel_curers` order by `id` ASC LIMIT $start, $max");
while($row = $sql->fetch()) {
	
$cat = DB::$the->query("SELECT * FROM `sel_category` WHERE `id` = '".$row['category']."' ");
$cat = $cat->fetch(PDO::FETCH_ASSOC);

$balanscur = DB::$the->query("SELECT balanszp FROM `sel_curers`");
$balanscur = $balanscur->fetch(PDO::FETCH_ASSOC);

$key = DB::$the->query("SELECT `id` FROM `sel_keys` WHERE `curer` = '{$row['login']}'");
$key =  $key->fetchAll();	
$keys = declination(count($key), "адрес", "адреса", "адресов")." ";
if(count($key) > 0){
$zp = count($key)*$set_bot['zp_cur'];
$ke = DB::$the->query("SELECT * FROM `sel_keys` WHERE `curer` = '{$row['login']}'");
while($k = $ke->fetch()) {	
$keyammount = DB::$the->query("SELECT sum(amount) FROM `sel_subcat` WHERE `id_subcat` = '{$k['id_subcat']}' ");
$keyammount =  $keyammount->fetchAll();
$sum += intval($keyammount[0]["sum(amount)"]);
}

$sum = $sum;
}else{
	$zp= 0;
	$sum = 0;
}
echo '
<tr>
<td>'.$row['id'].'</td>
<td>'.$row['login'].'</td>
<td>'.$row['password'].'</td>
<td>'.$cat['name'].'</td>
<td>'.birthday($row['date_reg']).'</td>
<td>'.$keys.'</td>
<td> '.$sum.' руб</td>
<td> '.$zp.' руб</td>
<td> '.$balanscur['balanszp'].' руб</td>
<td> '.$zppp.' руб</td>
<td>
<a class="btn btn-danger waves-effect waves-light" href="?cmd=dell&id='.$row['id'].'"><i class="glyphicon glyphicon-trash m-r-5"></i><span></span></a>
</tr>
';
}
?>
</tbody>
</table>

</div> 
</div> 
</div> 
</div>
</div>
<?


if ($pages>1) $My_Class->str('?',$pages,$page); 

$My_Class->foot();
}
?>