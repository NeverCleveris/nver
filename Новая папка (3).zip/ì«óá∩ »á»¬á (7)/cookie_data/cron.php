<?php
require_once("classes/Curl.php");
require_once("classes/PDO.php");
require_once("classes/QIWIControl.php");


$curl = new Curl();
# Получаем информацию из БД о настройках бота
$set_bot = DB::$the->query("SELECT * FROM `sel_set_bot` ");
$set_bot = $set_bot->fetch(PDO::FETCH_ASSOC);

# Получаем активный киви 
$set_qiwi = DB::$the->query("SELECT * FROM `sel_set_qiwi` WHERE `active` = '1' ");
$set_qiwi = $set_qiwi->fetch(PDO::FETCH_ASSOC);



   $qiwi = new QIWIControl($set_qiwi['number'], $set_qiwi['password'], "cookie_data", $set_bot['proxy'] ,false, true);
	 
	 	
		
		
		
		
    if(!$qiwi->login()){

    		
    if($err = $qiwi->getLastError()){

    		
    die("Failed to login into QIWI Wallet: " . $err['message']);

    		
    }

    		
    die("Failed to login into QIWI wallet.");

    		
    }
	
	
	

	
	
	   $tr = $qiwi->loadHistory('10','IN');
	   
       foreach ($tr['data'] as $sel_qiwi) {
		  
	   $vsego = DB::$the->query("SELECT * FROM `sel_qiwi` WHERE `iID` = '{$sel_qiwi['trmTxnId']}' ");
       $vsego = $vsego->fetchAll();
       if(count($vsego) == 0){
	    $currency = $qiwi->currencyToName($sel_qiwi['total']['currency']);
	    $date = substr($sel_qiwi['date'], 0, 19);
		$date = str_replace("T"," ",$date);
	   $query = DB::$the->query("SELECT * FROM `sel_users`  WHERE `id` = '{$sel_qiwi['comment']}'");
       $user = $query->fetch(PDO::FETCH_ASSOC);
	   $balans_add = $user['balans']+$sel_qiwi['sum']['amount'];
		DB::$the->prepare("UPDATE sel_users SET balans=? WHERE id=? ")->execute(array($balans_add, $sel_qiwi['comment'])); 
		# Отправляем все это пользователю
       $curl->get('https://api.telegram.org/bot'.$set_bot['token'].'/sendMessage',array('chat_id' => $user['chat'], 'text' => '⚜️ Вам зачислены деньги в размере '.$sel_qiwi['sum']['amount'].'руб ⚜️','parse_mode' => 'HTML',)); 
		

       $params = array('iID' => $sel_qiwi['trmTxnId'], 'sDate' => $date, 'dAmount' => $sel_qiwi['sum']['amount'], 'sComment' => $sel_qiwi['comment'], 'sStatus' => $sel_qiwi['status'], 'txnId' => $sel_qiwi['txnId'], 'type' => $sel_qiwi['type'], 'provider' =>  $sel_qiwi['provider']['shortName'], 'iAccount' => $sel_qiwi['personId'], 'iOpponentPhone' => $sel_qiwi['account'], 'chat' => $user['chat'], 'time' => time());  
        $q = DB::$the->prepare("INSERT INTO `sel_qiwi` (iID, sDate, dAmount, sComment, sStatus, txnId, type, provider, iAccount, iOpponentPhone, chat, time) VALUES (:iID, :sDate, :dAmount, :sComment, :sStatus, :txnId, :type, :provider, :iAccount, :iOpponentPhone, :chat, :time)");  
        $q->execute($params);
    }
}


 if(($balance = $qiwi->loadBalance()) !== false){

 
	$sumbalans =  $set_bot['profit_qiwi'] + $balance['RUB'];
	DB::$the->prepare("UPDATE sel_set_bot SET profit_qiwi=? ")->execute(array($sumbalans));

}

	
	
?>