<?php
echo'
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- App Favicon icon -->
        <link rel="shortcut icon" href="favicon.ico">
       

        <!--Morris Chart CSS -->
		<link rel="stylesheet" href="../style/plugins/morris/morris.css">
        <!-- Sweet Alert css -->
        <link href="../style/plugins/bootstrap-sweetalert/sweet-alert.css" rel="stylesheet" type="text/css">
 <!-- Plugin Css-->
        <link rel="stylesheet" href="../style/plugins/magnific-popup/css/magnific-popup.css" />
        <link rel="stylesheet" href="../style/plugins/jquery-datatables-editable/datatables.css" />

        <link href="../style/css'.$_COOKIE["theme"].'/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="../style/css'.$_COOKIE["theme"].'/core.css" rel="stylesheet" type="text/css" />
        <link href="../style/css'.$_COOKIE["theme"].'/components.css" rel="stylesheet" type="text/css" />
        <link href="../style/css'.$_COOKIE["theme"].'/icons.css" rel="stylesheet" type="text/css" />
        <link href="../style/css'.$_COOKIE["theme"].'/pages.css" rel="stylesheet" type="text/css" />
        <link href="../style/css'.$_COOKIE["theme"].'/menu.css" rel="stylesheet" type="text/css" />
        <link href="../style/css'.$_COOKIE["theme"].'/responsive.css" rel="stylesheet" type="text/css" />

        <!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesnt work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
		 <script src="../style/js/jquery.min.js"></script>
        <script type="text/javascript" src="../style/js/ajaxupload.3.5.js"></script>
        <script src="../style/js/modernizr.min.js"></script>

    </head>
 <body>
	<!-- Navigation Bar-->
       <header id="topnav">
            <div class="topbar-main">
                <div class="container">

                    <!-- Logo container-->
                    <div class="logo">
                        <a href="index.php" class="logo"><span>Курер <i class="icon-paypal"></i>anel</span></a>
                    </div>
                    <!-- End Logo container-->


<div class="menu-extras">
                        <ul class="nav navbar-nav navbar-right pull-right">
                       
 <li class="navbar-c-items"><h4 style="color:white;"></h4></li>
							
                            <li class="dropdown navbar-c-items">
							
                                <a href="" class="dropdown-toggle waves-effect waves-light profile" data-toggle="dropdown" aria-expanded="true"><img src="../style/images/users/photo.jpg" alt="admin" class="img-circle"> </a>
                                <ul class="dropdown-menu">
                                    <li><a href="settings.php"><i class="ti-settings text-custom m-r-10"></i> Настройки</a></li>
                                    <li class="divider"></li>
                                    <li><a href="index.php?exit"><i class="ti-power-off text-danger m-r-10"></i> Выйти</a></li>
                                </ul>
                            </li>
                        </ul>
						</div>
						
					    <div class="menu-item">
                            <!-- Mobile menu toggle-->
                            <a class="navbar-toggle">
                                <div class="lines">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </a>
							</div>
                   <div id="navigation" class="active" style="display: none;">
                           <ul class="nav navbar-nav navbar-left navigation-menu">
                            <li class="has-submenu">
                                <a href="index.php"><i class="typcn typcn-home"></i>Главная</a> 
                            </li>
                            <li class="has-submenu">
                                <a href="shops.php"><i class="typcn typcn-shopping-cart"></i>Управление товаром</a>
                            </li>
                            
                        </ul>
                            <!-- End mobile menu toggle-->
                        </div>
                    </div>

                </div>
                </div>

       
        </header>';
		?>