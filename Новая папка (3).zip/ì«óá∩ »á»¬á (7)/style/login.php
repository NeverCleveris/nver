<?php

echo '<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="author" content="">

		<link rel="shortcut icon" href="favicon.ico">

		<title>Авторизация в админ панели</title>

		<link href="'.CSS.'bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="'.CSS.'core.css" rel="stylesheet" type="text/css" />
        <link href="'.CSS.'components.css" rel="stylesheet" type="text/css" />
        <link href="'.CSS.'icons.css" rel="stylesheet" type="text/css" />
        <link href="'.CSS.'pages.css" rel="stylesheet" type="text/css" />
        <link href="'.CSS.'responsive.css" rel="stylesheet" type="text/css" />

        <!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesnt work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->

        <script src="'.JS.'modernizr.min.js"></script>

	</head>
	<body>

		<div class="account-pages"></div>
		<div class="clearfix"></div>
		<div class="wrapper-page">
			<div class=" card-box">
				
				<div class="panel-body">
					<form method="POST" action="index.php?get_save" role="form" class="text-center">
						<div class="user-thumb">
							<img src="..//style/images/users/admin.jpg" class="img-responsive img-circle img-thumbnail" alt="thumbnail">
						</div>
						<div class="form-group">
							<h3>АДМИНИСТРАТОР</h3>
						<?php echo $msg; ?>
							<div class="input-group m-t-30">
								<input type="password" class="form-control" placeholder="Password"  name="secretkey" required="">
								<span class="input-group-btn">
									<button type="submit" name="submit" class="btn btn-pink w-sm waves-effect waves-light">
									Войти
 									</button> 
								</span>
							</div>
						</div>
						
					</form>
       

				</div>
			</div>
			
			<div class="row">
				<div class="col-sm-12 text-center">
					<p>
				
                            <div class="col-xs-6">
                            	
                                Copyright <a href="https://t.me/dgoniY67"><b>®© 🏪SHOPBOT Telegram 2019  Все права защищены</b></a>

                            </div>
                            <div class="col-xs-6">
                                <ul class="pull-right list-inline m-b-0">
                                    <li>
                                    	
                                        <a href="https://t.me/dgoniY67">» 🏪ShopBot Telegram</a>
                                    </li>
                                    <li>
                                        <a href="https://t.me/dgoniY67">» Заказы</a>
                                    </li>
									 <li>
                                        <a href="https://t.me/dgoniY67">» Поддержка</a>
                                    </li>
                                    <li>
                                        <a href="https://t.me/ShopBotTelegram">» Канал в Telegram</a>
                                   <br><br><br><br><br><br>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
</div>
					</p>
				</div>
			</div>

		</div>

		<script>
			var resizefunc = [];
		</script>

		<!-- jQuery  -->
        <script src="'.JS.'jquery.min.js"></script>
        <script src="'.JS.'bootstrap.min.js"></script>
        <script src="'.JS.'detect.js"></script>
        <script src="'.JS.'fastclick.js"></script>
        <script src="'.JS.'jquery.slimscroll.js"></script>
        <script src="'.JS.'jquery.blockUI.js"></script>
        <script src="'.JS.'waves.js"></script>
        <script src="'.JS.'wow.min.js"></script>
        <script src="'.JS.'jquery.nicescroll.js"></script>
        <script src="'.JS.'jquery.scrollTo.min.js"></script>


        <script src="'.JS.'jquery.core.js"></script>
        <script src="'.JS.'jquery.app.js"></script>

	</body>
</html>';

?>