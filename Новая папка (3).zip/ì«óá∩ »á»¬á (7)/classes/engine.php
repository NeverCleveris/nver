<?php 

class Engine
{
	
	public function load($class) 
	{
		$this->$class = $class::getInstance();
		
		return $this->$class;
	}
	
	# BYDIMKA v2 
	
	/*
	Описание: Логирование действий
	Параметры: $contents (текст)   - номер пользователя 
			   $file (текст) - название файла без расширения
	*/		
	function log($contents, $file) 
	{
		file_put_contents($_SERVER['DOCUMENT_ROOT'].'/logs/'.$file.'.txt', $contents, FILE_APPEND);	
	}
	
	# BYDIMKA v2 
	/*
	Описание: Генерация ключа
	Параметры: $length (число)   - длина ключа
	*/			
	function GenerateKey($length) 
	{
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPRQSTUVWXYZ0123456789";
		$code = "";
		$clen = strlen($chars) - 1;  
		while (strlen($code) < $length)
			$code .= $chars[mt_rand(0,$clen)];  
		return $code;
	}
	
	# BYDIMKA v2 
	/*
	Описание: Окончания слов с цифрами
	Параметры: $number (число)   - число
			   $titles (массив)  - слова с окончаниями
	*/	
	function declOfNum($number, $titles) 
	{
		$cases = array (2, 0, 1, 1, 1, 2);
		return $number." ".$titles[ ($number%100>4 && $number%100<20)? 2 : $cases[min($number%10, 5)] ];
	}
	
	# BYDIMKA v2 
	/*
	Описание: Навигация страниц
	Параметры: $num (число)    	-        Количество записей
		$step (число)   		-        Шаг
		$cur_page (число)   	-        Текущая страница
		$put (текст)			-		 Ссылка до страницы
	*/
	function pagination($num, $step, $cur_page, $put) 
	{
		$num_pages=ceil($num/$step);
		if ($num_pages > 1) 
		{
			$result = '<div class="pagination pagination-centered"><ul>';
			if(($cur_page+1) == 1)
				$result .= '<li class="disabled"><a>Назад</a></li>';
			else	
				$result .= '<li><a href="'.$put.''.$cur_page.'">Назад</a></li>';
			if($num_pages > 10) 
			{
				if(($cur_page+1) >= ($num_pages-3)) 
				{
					$result .= '<li><a href="'.$put.'1">1</a></li>';
					$result .=  '<li class="disabled"><a>...</a></li>';		
					for($i=($num_pages-4);$i<=$num_pages;$i++) 
					{
						if ($i-1 == $cur_page)
							$result .= '<li class="active"><a>'.$i.'</a></li>';
						else
							$result .= '<li><a href="'.$put.''.$i.'">'.$i.'</a></li>';
					}				
				} else if(($cur_page+1) > 4) {
					$result .= '<li><a href="'.$put.'1">1</a></li>';
					$result .=  '<li class="disabled"><a>...</a></li>';
					for($i=($cur_page-1);$i<=($cur_page+3);$i++) 
					{
						if ($i-1 == $cur_page)
							$result .= '<li class="active"><a>'.$i.'</a></li>';
						else
							$result .= '<li><a href="'.$put.''.$i.'">'.$i.'</a></li>';
					}
					$result .=  '<li class="disabled"><a>...</a></li>';
					$result .= '<li><a href="'.$put.''.$num_pages.'">'.$num_pages.'</a></li>';
				} else {
					for($i=1;$i<=5;$i++) 
					{
						if ($i-1 == $cur_page)
							$result .= '<li class="active"><a>'.$i.'</a></li>';
						else
							$result .= '<li><a href="'.$put.''.$i.'">'.$i.'</a></li>';
					}
					$result .=  '<li class="disabled"><a>...</a></li>';
					$result .= '<li><a href="'.$put.''.$num_pages.'">'.$num_pages.'</a></li>';
				}
			} else {
				for($i=1;$i<=$num_pages;$i++) 
				{
					if ($i-1 == $cur_page)
						$result .= '<li class="active"><a>'.$i.'</a></li>';
					else
						$result .= '<li><a href="'.$put.''.$i.'">'.$i.'</a></li>';
				}
			}
			if($num_pages == ($cur_page+1)) 
				$result .= '<li class="disabled"><a>Вперед</a></li>';
			else 
				$result .= '<li><a href="'.$put.''.($cur_page+2).'">Вперед</a></li>';
			$result .= "</ul></div>\n";
		} else 
			$result = '';
		return $result;
	}
	
	# BYDIMKA v2 
	/*
	Описание: Вывод времени
	Параметры: $timestamp (число)   - время в формате timestamp
			   $type (число)  - переключатель ~ 1 - со временем 0 - без
	*/		
	function showtime($timestamp, $type) 
	{
		$date = date("d.m.Y", $timestamp);
		$yesterday = date("d.m.Y", mktime(0, 0, 0, date("m"), date("d")-1, date("Y"))); 
		if ($date == date("d.m.Y")) 
		{
			if($type == '1')
				$date = date("Сегодня в H:i", $timestamp);
			else
				$date = date("H:i", $timestamp);
		} else if ($yesterday == $date)
			$date = date("Вчера в H:i", $timestamp);
		else {
			if($type == '1')
				$date = date("d.m.Y в H:i", $timestamp);
			else
				$date = date("d.m.Y", $timestamp);
		}
		return $date;
	}

	# BYDIMKA v2 
	/*
	Описание: Вывод русского месяца
	Параметры: $timestamp (число)   - время в формате timestamp
	*/		
	function russian_date($timestamp) {
		$date=explode(".", date("H.i.d.n.Y", $timestamp));
		$month = array(1 => 'января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря');
		return $date[2].' '.$month[$date[3]].' '.$date[4].' года';
	}

	# BYDIMKA v2 
	/*
	Описание: Замена тегов в чате
	Параметры: $text (текст)   - текст сообщения
	*/	
	function replacechat($text) {
		$str_search = array(
		"#\\(пикча\)(https?://.*?\.(?:jpg|jpeg|gif|png|bmp))\(пикча\)#is",
		"#\(ютуб\)http://[a-z]{0,3}.youtube.com/watch\?v=([0-9a-zA-Z_-]{1,11})\(ютуб\)#is"
		);
		$str_replace = array(
		'<a class="fancybox" rel="group" href="\\1"><img class="fancyimg" src="\\1" alt="Изображение" /></a>',
		"<iframe width='400' height='300' src='http://www.youtube.com/embed/\\1' frameborder='0' allowfullscreen></iframe>",
		);
		return preg_replace($str_search, $str_replace, $text);
	}

	

	# BYDIMKA v2 
	/*
	Описание: Замена смайлов в чате
	Параметры: $text (текст)   - текст сообщения
			   $search (массив) - то что ищем
			   $replace (массив) - на что заменяем
	*/	
	function replace_smiles($text, $search, $replace) 
	{
		return str_replace($search, $replace, $text);
	}
	
	# BYDIMKA v2 
	/*
	Описание: Вывод смайлов
	Параметры: $array (массив)   - массив смайлов
			   $func (текст) - функция вставки смайла
	*/		
	function viewsmiles($array,$func) 
	{
		$result = '';
		if(count($array) > 0)
			for($i=0;$i<count($array);$i++)
				$result .= '<a style="cursor: pointer;" class="smmargin" onclick="'.$func.'(\''.$array[$i]['name'].'\')"><img src="'.$array[$i]['search'].'"/></a>';
		return $result;
	}

	# BYDIMKA v2 
	/*
	Описание: Форматирование текста
	Параметры: $text (текст)   - текст сообщения
	*/		
	function input($text) 
	{
		$text = trim($text);
		$text = htmlspecialchars($text, ENT_QUOTES);
		$text = str_replace("\r\n", "<br />", $text);
		return $text;
	}

	# BYDIMKA v2 
	/*
	Описание: Форматирование текста (VARCHAR)
	Параметры: $text (текст)   - текст сообщения
			   $strlen (число)  - переключатель ~ 1 - обрезать 0 - не обрезать
			   $length (число)  - длина, до которой обрежится текст
	*/		
	function inputvar($text, $strlen = false, $length = 30) 
	{
		$text = trim($text);
		$text = htmlspecialchars($text, ENT_QUOTES);
		$text = str_replace("\r\n", "", $text);
		if(strlen($text) > $length)
            $text = mb_substr($text, 0, $length, 'UTF-8');
		return $text;
	}
	
	# BYDIMKA v2 
	/*
	Описание: Редактирование форматирование текста
	Параметры: $text (текст)   - текст сообщения
	*/		
	function editinput($text) 
	{
		$text = str_replace("<br />", "\r\n", $text);
		return $text;
	}

	function msg($header, $msg, $status) 
	{
		$array_status = array(1 => 'success', 2 => 'danger', 3 => 'info', 4 => 'warning');
		$array_header = array(1 => 'Поздравляем!', 2 => 'Ошибка!', 3 => 'Информация', 4 => 'Предупреждение');
		if(isset($array_status[$status]))
			$status = $array_status[$status];
		else
			$status = 4;
		if(isset($array_header[$header]))
			$header = $array_header[$header];
		return "<div class='alert alert-{$status}'><strong>{$header}</strong><br />{$msg}</div>";
	}
	
	
	function safe($var)
	{
		return htmlspecialchars($var, ENT_QUOTES, 'UTF-8');
	}
	
	#Прочие функции
	function redirect($link) {
		return '<script type="text/javascript"> location="'.$link.'" </script>';
	}
	function stripinput($text) {
		if (QUOTES_GPC) $text = stripslashes($text);
		$search = array("&", "\"", "'", "\\", '\"', "\'", "<", ">", "&nbsp;");
		$replace = array("&amp;", "&quot;", "&#39;", "&#92;", "&quot;", "&#39;", "&lt;", "&gt;", " ");
		$text = str_replace($search, $replace, $text);
		$text = str_replace("\r\n", "<br />", $text);
		$text = trim($text);
		return $text;
	}	
	
	function smiles($func, $status, $escaped){	
		$smiles = array(
		":D"=>'<img src="/main/img/smiles/biggrin.png"/>',
		":)"=>'<img src="/main/img/smiles/smile.png"/>',
		";)"=>'<img src="/main/img/smiles/wink.png"/>',
		"o0"=>'<img src="/main/img/smiles/blink.png"/>',
		":P"=>'<img src="/main/img/smiles/tongue.png"/>',
		"lol"=>'<img src="/main/img/smiles/laugh.png"/>',
		"angry"=>'<img src="/main/img/smiles/angry.png"/>',
		"^_^"=>'<img src="/main/img/smiles/happy.png"/>',
		":o"=>'<img src="/main/img/smiles/ohmy.png"/>'
		);
		if($status == '0') {
			$result = '';
			foreach ($smiles as $i => $smilesvalue) {
				$result .= '<a style="cursor: pointer;" onclick=\'InsertSmile("'.$i.'")\'>'.$smilesvalue.'</a> ';
			}
			return $result;
		} else if($status == '1') {
			$text = strtr($func, $smiles);
			return $text;
		}
	}
	
	function replaceBBCode($text_post) {
		$str_search = array(
		"#\[b\](.+?)\[\/b\]#is",
		"#\[i\](.+?)\[\/i\]#is",
		"#\[u\](.+?)\[\/u\]#is",
		"#\[url=((?:http|https):\/\/[^\s]+)\](.+?)\[\/url\]#is",
		"#\[url\]((?:http|https):\/\/[^\s]+)\[\/url\]#is",
		"#\[youtube\]http://[a-z]{0,3}.youtube.com/watch\?v=([0-9a-zA-Z_-]{1,11})\[\/youtube\]#is",
		"#\[img\](https?://.*?\.(?:jpg|jpeg|gif|png|bmp))\[\/img\]#is",
		"#\[size=([1-9]|1[0-9]|20)\](.+?)\[\/size\]#is",
		"#\[color=(\#[0-9A-F]{6}|[a-z]+)\](.*?)\[\/color\]#is",
		"#\[quote\](.+?)\[\/quote\]#is",
		"#\[code\](.+?)\[\/code\]#is",
		"#\[c\](.+?)\[\/c\]#is",
		"#\[l\](.+?)\[\/l\]#is",
		"#\[r\](.+?)\[\/r\]#is"
		);
		$str_replace = array(
		"<b>\\1</b>",
		"<i>\\1</i>",
		"<span style='text-decoration:underline'>\\1</span>",
		"<a rel='nofollow' target='_blank' href='\\1'>\\2</a>",
		"<a rel='nofollow' target='_blank' href='\\1'>\\1</a>",
		"<iframe width='400' height='300' src='http://www.youtube.com/embed/\\1' frameborder='0' allowfullscreen></iframe>",
		'<a class="fancybox" rel="group" href="\\1"><img class="fancyimg" src="\\1" alt="Изображение" /></a>',
		"<span style='font-size:\\1px'>\\2</span>",
		"<span style='color:\\1'>\\2</span>",
		"<blockquote><small>Цитата</small><p>\\1</p></blockquote>",
		"<pre class='pre-scrollable'>\\1</pre>",
		"<p style='text-align:center;'>\\1</p>",
		"<p style='text-align:left;'>\\1</p>",
		"<p style='text-align:right;'>\\1</p>",
		);
		return preg_replace($str_search, $str_replace, $text_post);
	}

	function replaceChatMsg($text_post) {
		$str_search = array(
		"#\:(https?://.*?\.(?:jpg|jpeg|gif|png|bmp))\:#is"
		);
		$str_replace = array(
		'<img style="max-width:400px; max-width:400px;" src="\\1" />'
		);
		return preg_replace($str_search, $str_replace, $text_post);
	}
	
	function bb_panel(){
		$panel = '<ul id="bbpanel"><li><div class="btn-group">
		<a class="btn" alt="b">Жирный</a>
		<a class="btn" alt="i"><i>Курсив</i></a>
		<a class="btn" alt="u"><u>Подчеркнутый</u></a></div></li>
		<li><div class="btn-group"><a class="btn" alt=\'size[=]\'><i class="icon-resize-vertical"></i></a>
		<a class="btn" alt=\'color[=]\'><i class="icon-asterisk"></i></a></div></li>
		<li><a class="btn" alt=\'url[=]\'><i class="icon-share"></i></a></li>
		<li><a class="btn" alt="img"><i class="icon-picture"></i></a></li>
		<li><a class="btn" alt="youtube">YouTube</a></li>
		<li><a href="#help" role="button" class="btn" data-toggle="modal"><i class="icon-info-sign"></i></a></li></ul>
		<div class="modal hide fade" id="help" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"><div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button><h3 id="myModalLabel">Помощь по BB кодам</h3></div>
		<div class="modal-body">
		<table class="table table-bordered">
		<thead>
		<tr>
		<th>Пример</th>
		<th>Вывод</th>
		</tr>
		</thead>
		<tbody>
		<tr><td><code>[b]Жирный шрифт[/b]</code></td><td><b>Жирный шрифт</b></td></tr>
		<tr><td><code>[i]Курсивный шрифт[/i]</code></td><td><i>Курсивный шрифт</i></td></tr>
		<tr><td><code>[u]Подчеркнутый шрифт[/u]</code></td><td><u>Подчеркнутый шрифт</u></td></tr>
		<tr><td><code>[size=20]Текст большой высоты[/size]</code></td><td><span style="font-size:20px">Текст большой высоты</span></td></tr>
		<tr><td><code>[color=red]Текст красного цвета[/color]</code></td><td><span style="color:red">Текст красного цвета</span></td></tr>
		<tr><td><code>[url=http://hot-cs.ru/]Ссылка на наш сайт[/url]</code></td><td><a target="_blank" rel="nofollow" href="http://hot-cs.ru/">Ссылка на наш сайт</a></td></tr>
		<tr><td><code>[img]http://yandex.st/morda-logo/i/logo.png[/img]</code></td><td><img style="max-width:400px;" src="http://yandex.st/morda-logo/i/logo.png" alt = "Изображение" /></td></tr>
		<tr><td><code>[youtube]http://www.youtube.com/watch?v=4hpEnLtqUDg[/youtube]</code></td><td><iframe width="400" height="300" src="http://www.youtube.com/embed/4hpEnLtqUDg" frameborder="0" allowfullscreen></iframe></td></tr>
		</tbody>
		</table>
		</div></div>';
		return $panel;
	}
}

$eng = new Engine();