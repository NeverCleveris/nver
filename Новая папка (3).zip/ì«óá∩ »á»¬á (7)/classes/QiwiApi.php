<?php 

require_once(__DIR__ . DIRECTORY_SEPARATOR . "UserAgent2.php");

class QiwiApi {
    private $_phone;
    private $_token;
    private $_url;
    private $ua;
	private $cookie_file;
    private $debug;
    private $lastStatus;
	
    function __construct($phone, $token, $debug_mode=false) {
        $this->_phone = $phone;
        $this->_token = $token;
        $this->_url   = 'https://edge.qiwi.com/';
	   $this->debug = $debug_mode;
		$cookie_dir = "cookie_data";
		if(preg_match("/([0-9]+)/", $phone, $m)) {
            if(!file_exists($cookie_dir)){
                if(!mkdir($cookie_dir, 0775, true)){
                    die("Failed to create directory $cookie_dir");
                }
            }
            $this->cookie_file = "{$cookie_dir}/cookie{$m[1]}.txt";
        }
		$this->ua = new UserAgent2($this->cookie_file, false);
		
	}
	
	
	
    private function sendRequest($method, array $content = [], $post = false) {
       $ch = curl_init();
        if ($post) {
            curl_setopt($ch, CURLOPT_URL, $this->_url . $method);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($content));
        } else {
            curl_setopt($ch, CURLOPT_URL, $this->_url . $method . '/?' . http_build_query($content));
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/json',
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->_token
        ]); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		
				
        $result = curl_exec($ch);
	
       
        curl_close($ch);
		
		
        return json_decode($result, 1);
    }


	public function getStatus(){
        return $this->lastStatus;
    }
	
    public function getAccount(Array $params = []) {
        return $this->sendRequest('person-profile/v1/profile/current', $params);
    }
	
		
    public function getLoadHistory(Array $params = []) {
        return $this->sendRequest('payment-history/v1/persons/' . $this->_phone . '/payments', $params);
    }
	
	public function getLoadBalance() {
        return $this->sendRequest('funding-sources/v1/accounts/current');
    }
	
	 function loadHistory($count = 10, $type = 'ALL'){
		  
        $url .= 'https://edge.qiwi.com/payment-history/v1/persons/' . $this->_phone . '/payments?rows='.$count.'&operation='.$type;
        $response = $this->ua->request(USERAGENT_METHOD_GET, $url, false, false, [
            'Accept: application/json',
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->_token
        ]); 
		
         $this->lastStatus = $this->ua->getStatus();
         

        return json_decode($response, 1);
        
    } 


	public function loadBalance(){
		  
        $url = 'https://edge.qiwi.com/funding-sources/v1/accounts/current';
        $response = $this->ua->request(USERAGENT_METHOD_GET, $url, false, false, [
             'Accept: application/json',
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->_token,
        ]);
		
         $this->lastStatus = $this->ua->getStatus();
		 
        $response = json_decode($response, 1);

        return json_decode($result, 1);
        
    }
	

    public function getTax($providerId) {
        return $this->sendRequest('sinap/providers/'. $providerId .'/form');
    }  

    public function sendMoneyToQiwi(Array $params = []) {
        return $this->sendRequest('sinap/api/v2/terms/99/payments', $params, 1);
    }
    
    public function sendMoneyToWebMany(Array $params = []) {
        return $this->sendRequest('sinap/api/v2/terms/31271/payments', $params, 1);
    }
    
    public function sendMoneyToYandex(Array $params = []) {
        return $this->sendRequest('sinap/api/v2/terms/26476/payments', $params, 1);
    }

    public function sendMoneyToProvider($providerId, Array $params = []) {
        return $this->sendRequest('sinap/terms/'. $providerId .'/payments', $params, 1);
    }    
        public function sendMoneyToVisa(Array $params = []) {
        return $this->sendRequest('sinap/api/v2/terms/1963/payments', $params, 1);
    }
    
    public function sendMoneyToMaster(Array $params = []) {
        return $this->sendRequest('sinap/api/v2/terms/21013/payments', $params, 1);
    }
    
    public function sendMoneyToMir(Array $params = []) {
        return $this->sendRequest('sinap/api/v2/terms/31652/payments', $params, 1);
    }
    
    public function sendMoneyToTele2(Array $params = []) {
        return $this->sendRequest('sinap/api/v2/terms/42/payments', $params, 1);
    }
    
    public function sendMoneyToRTK(Array $params = []) {
        return $this->sendRequest('sinap/api/v2/terms/32170/payments', $params, 1);
    }
}