<?php
$file="Configuration.php";
unlink($file);
?>