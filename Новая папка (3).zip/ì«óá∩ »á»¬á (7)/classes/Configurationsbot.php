<?php

class conf {
	static $main = array( // Главные настройки
		'adm_password' => 'password',
		'idshop' => 'idshop',
		'url' => 'url',
		);

	static $db = array(
		'db_serv' => 'db_serv',
		'db_user' => 'db_user',
		'db_pass' => 'db_pass',
		'db_name' => 'db_name',

		);
				
	static $api = array(
		'login' => 'beget_login',
		'password' => 'beget_password',
		'ip' => 'ip',
		);
}
?>