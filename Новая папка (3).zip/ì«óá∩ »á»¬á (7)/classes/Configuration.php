<?php

class conf {
	static $main = array( // Главные настройки
		'adm_password' => 'ПАРОЛЬ ОТ АДМИНКИ',
		'idshop' => 'РАЗДЕЛ ГДЕ НАХОДИТСЯ ФАЙЛЫ',
		'url' => 'ИМЯ',
		);

	static $db = array(
		'db_serv' => 'localhost',
		'db_user' => 'ИМЯ БАЗЫ',
		'db_pass' => 'ПАРОЛЬ БАЗЫ',
		'db_name' => 'ИМЯ БАЗЫ',

		);
				
	static $api = array(
		'login' => 'ЛОГИН',
		'password' => 'ПАРОЛЬ',
		'ip' => 'ip',
		);
}
?>