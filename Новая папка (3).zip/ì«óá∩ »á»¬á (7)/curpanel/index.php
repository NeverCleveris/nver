<?php 
session_start();
ob_start();


require_once "../classes/My_Class.php";

function GenerateKey() 
{
	$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPRQSTUVWXYZ0123456789";
	$code = "";
	$clen = strlen($chars) - 1;  
	while (strlen($code) < 10)
		$code .= $chars[mt_rand(0,$clen)];  
	return md5($code);
}


if (!isset($_COOKIE["id"]) and !isset($_COOKIE["hash"])) {
	
if (isset($_GET['get_save']) and isset($_POST['submit'])) {
	
	$sql = DB::$the->query("SELECT * FROM `sel_curers` WHERE `login` = '{$_POST['login']}' and `password` = '{$_POST['password']}'");
	$row = $sql->fetch(PDO::FETCH_ASSOC);
	
        if($row['password'] != NULL) {
             $time = time();
             setcookie("id", $row['id'], time()+86400, '/');
             $hash = GenerateKey();
		     setcookie("hash", $hash, time()+2592000, "/");
             header("Location: index.php"); 
         } else {
    	$msg = '<p class="text-muted" style="color:red;">Неверный логин или пароль</p>';
      }
 } else {
   $msg =  '<p class="text-muted">Введите пароль от курьер панели.</p>';
  }
  
echo '<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="author" content="">

		<link rel="shortcut icon" href="favicon.ico">

		<title>Авторизация в админ панели</title>

		<link href="'.CSS.'bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="'.CSS.'core.css" rel="stylesheet" type="text/css" />
        <link href="'.CSS.'components.css" rel="stylesheet" type="text/css" />
        <link href="'.CSS.'icons.css" rel="stylesheet" type="text/css" />
        <link href="'.CSS.'pages.css" rel="stylesheet" type="text/css" />
        <link href="'.CSS.'responsive.css" rel="stylesheet" type="text/css" />

        <!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesnt work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->

        <script src="'.JS.'modernizr.min.js"></script>

	</head>
	<body>

		<div class="account-pages"></div>
		<div class="clearfix"></div>
		<div class="wrapper-page">
			<div class="card-box">
				
				<div class="panel-body">
					<form method="POST" action="index.php?get_save" role="form" class="text-center">
						<div class="user-thumb">
							<img src="../style/images/users/photo.jpg" class="img-responsive img-circle img-thumbnail" alt="thumbnail">
						</div>
						<div class="form-group">
							<h3>Курер</h3>
							<center>
						'.$msg.'
						<div class="input-group m-t-30">
								<input type="text" class="form-control" placeholder="Login"  name="login" required="">
								<span class="input-group-btn">
							
								</span>
							</div>
							<div class="input-group m-t-30">
								<input type="password" class="form-control" placeholder="password"  name="password" required="">
									
							</div>
														<div class="input-group m-t-30">

							<button type="submit" name="submit" class="btn btn-pink w-sm waves-effect waves-light">
									Войти
 									</button> 
									</div>
									</center>
						</div>
					
				
					</form>
       

				</div>
			</div>
			
			

		</div>

		<script>
			var resizefunc = [];
		</script>

		<!-- jQuery  -->
        <script src="'.JS.'jquery.min.js"></script>
        <script src="'.JS.'bootstrap.min.js"></script>
        <script src="'.JS.'detect.js"></script>
        <script src="'.JS.'fastclick.js"></script>
        <script src="'.JS.'jquery.slimscroll.js"></script>
        <script src="'.JS.'jquery.blockUI.js"></script>
        <script src="'.JS.'waves.js"></script>
        <script src="'.JS.'wow.min.js"></script>
        <script src="'.JS.'jquery.nicescroll.js"></script>
        <script src="'.JS.'jquery.scrollTo.min.js"></script>


        <script src="'.JS.'jquery.core.js"></script>
        <script src="'.JS.'jquery.app.js"></script>

	</body>
</html>';
 
} else {
	
require TPL."cur_head.php";

$My_Class->title("Курьер-панель");

// Количество лет, месяцев и дней, прошедших со дня рождения
  function birthday($sec_birthday)
  {
    // Сегодняшняя дата
    $sec_now = time();
    // Подсчитываем количество месяцев, лет
    for($time = $sec_birthday, $month = 0; 
        $time < $sec_now; 
        $time = $time + date('t', $time) * 86400, $month++){
        $rtime = $time;
        }
    $month = $month - 1;
    // Количество лет
    $year = intval($month / 12);
    // Количество месяцев
    $month = $month % 12;
    // Количество дней
    $day = intval(($sec_now - $rtime) / 86400);

    $result .= declination($day, "день", "дня", "дней")." ";
    return $result;
  }

  // Склонение числа $num
  function declination($num, $one, $ed, $mn, $notnumber = false)
  {  
    // $one="статья";  
    // $ed="статьи";  
    // $mn="статей";  
    if($num === "") print "";
    if(($num == "0") or (($num >= "5") and ($num <= "20")) or preg_match("|[056789]$|",$num))
      if(!$notnumber)
        return "$num $mn";
      else
        return $mn;
    if(preg_match("|[1]$|",$num))
      if(!$notnumber)
        return "$num $one";
      else
        return $one;
    if(preg_match("|[234]$|",$num))
      if(!$notnumber)
        return "$num $ed";
      else
        return $ed;
  }
  	$sql = DB::$the->query("SELECT * FROM `sel_curers` WHERE `id` = '{$_COOKIE['id']}'");
	$row = $sql->fetch(PDO::FETCH_ASSOC);
	
	$set_bot = DB::$the->query("SELECT * FROM `sel_set_bot` ");
$set_bot = $set_bot->fetch(PDO::FETCH_ASSOC);


$key = DB::$the->query("SELECT `id` FROM `sel_keys` WHERE `curer` = '{$row['login']}'");
$key =  $key->fetchAll();	

$keys = declination(count($key), "адрес", "адреса", "адресов")." ";
$zp = count($key)*$set_bot['zp_cur'];

$order = DB::$the->query("SELECT `id` FROM `sel_keys` WHERE `curer` = '{$row['login']}'");
$order =  $order->fetchAll();

$users = DB::$the->query("SELECT `id` FROM `sel_users`");
$users =  $users->fetchAll();

$set_bot = DB::$the->query("SELECT token,zp_cur FROM `sel_set_bot`");
$set_bot = $set_bot->fetch(PDO::FETCH_ASSOC);

$balanscur = DB::$the->query("SELECT balanszp FROM `sel_curers`");
$balanscur = $balanscur->fetch(PDO::FETCH_ASSOC);

$cat = DB::$the->query("SELECT * FROM `sel_category` WHERE `id` = '".$row['category']."' ");
$cat = $cat->fetch(PDO::FETCH_ASSOC);

$ke = DB::$the->query("SELECT * FROM `sel_keys` WHERE `curer` = '{$row['login']}'");
while($k = $ke->fetch()) {	
$keyammount = DB::$the->query("SELECT sum(amount) FROM `sel_subcat` WHERE `id_subcat` = '{$k['id_subcat']}' ");
$keyammount =  $keyammount->fetchAll();
$sum += intval($keyammount[0]["sum(amount)"]);
}

$sum = $sum;

?>
<div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-white">
                                 <i class="fa fa-shopping-cart text-info"></i>
                            <h2 class="m-0 text-dark counter font-600"><?php echo birthday($row['date_reg']); ?></h2>
                            <div class="text-muted m-t-5">Работаешь</div>
                        </div>
                        </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-white">
                            <i class="fa fa-map-marker text-pink"></i>
                            <h2 class="m-0 text-dark counter font-600"><?php echo $keys; ?></h2>
                            <div class="text-muted m-t-5">Добавил адресов </div>
                        </div>
                        </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-white">
							   <i class="fa fa-ruble text-primary"></i>
                            <h2 class="m-0 text-dark counter font-600"><?php echo $set_bot['zp_cur'] ; ?> руб</h2>
                            <div class="text-muted m-t-5">Оплата за 1 клад</div>
                        </div>
                        </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-white">
                             <i class="fa fa-ruble text-primary"></i>
                            <h2 class="m-0 text-dark counter font-600"><?php echo $zp ; ?> руб</h2>
                            <div class="text-muted m-t-5">Заработал</div>
                        </div>
                        </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="widget-panel widget-style-2 bg-white">
                             <i class="fa fa-ruble text-primary"></i>
                            <h2 class="m-0 text-dark counter font-600"><?php echo $balanscur['balanszp'] ; ?> руб</h2>
                            <div class="text-muted m-t-5">Получил зп</div>
                        </div>
                    </div>
                </div>
			

<?

if(isset($_GET['exit'])) {	
setcookie('id', "\\", time()-86400, '/');
setcookie('hash', "\\", time()-86400, '/');	
	
header("Location: index.php");
}	
$My_Class->foot();
}
?>