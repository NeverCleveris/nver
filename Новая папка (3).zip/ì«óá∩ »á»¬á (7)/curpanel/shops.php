<?php
ob_start();


require_once "../classes/My_Class.php";
require_once TPL."cur_head.php";



if (!isset($_COOKIE["id"]) and !isset($_COOKIE["hash"])) {
header("Location: index.php");		
exit;
}

  	$sql = DB::$the->query("SELECT * FROM `sel_curers` WHERE `id` = '{$_COOKIE['id']}'");
	$user = $sql->fetch(PDO::FETCH_ASSOC);
	
	if($_GET['page']== 'add'){
		
		$My_Class->title("Добавление адресов");


		?>
<script type="text/javascript">
	$(function(){
		var btnUpload=$('#upload');
		var status=$('#status');
		new AjaxUpload(btnUpload, {
			action: '../admin/ajax.php?mod=uploadsimg',
			name: 'uploadfile',
			onSubmit: function(file, ext){
				 if (! (ext && /^(bmp|jpg|png|jpeg|gif)$/.test(ext))){  
                    // extension is not allowed 
					status.text('Поддерживаемые форматы bmp, jpg, jpeg, png, gif');
					return false;
				}
				status.text('Загрузка...');
			},
			onComplete: function(file, response){
				//On completion clear the status
				status.text('');
				//Add uploaded file to list
				if(response==="success"){
					$('<li></li>').appendTo('#files').html('<img src="../style/images/keys/'+file+'" alt=""><br>'+file).addClass('success');
				} else{
					$('<li></li>').appendTo('#files').text('Файл не загружен!' + file).addClass('error');
				}
			}
		});
		
	});
</script>

	 <h4 class="page-title">Добавить адреса</h4>
             
               <br />
				
<div class="col-sm-12">
<div class="card-box">
<div id="msg">
<div class="alert alert-info">
              <button type="button" class="close" data-dismiss="alert">x</button><br>
              <strong>Внимание!</strong> Каждый адрес вводите с новой строки, Что бы добавить фотографию ниже загрузите и в нужном месте укажите<br/><b> [img]название нужной фотографи[/img]</b>
</div>
</div>
<form id="addkeys">
<input type="hidden" name="cat" value="<?=$user['category'];?>">
<input type="hidden" name="login" value="<?=$user['login'];?>">
<div class="input-group input-group-lg">	
  <textarea  name="key" class="form-control"  cols="130" rows="15" placeholder="Каждый адрес с новой строки" required="required"></textarea>
    </div><br />
<div class="input-group input-group-lg">	
	<span class="input-group-addon">Товар</span>
	<select class="form-control" id="addkey_tovar" name="tovar"  onchange="selectcats()">
			<option  disabled="disabled">Выбери товар</option>
</select>
		
    </div><br />	

<div class="input-group input-group-lg">	
	<span class="input-group-addon">В Районе</span>
	<select class="form-control" name="subcat" id="addkey_subcats">
		<option  disabled="disabled">Выбери район</option>
</select>
    </div><br />
<div class="input-group input-group-lg">	
	<span class="input-group-addon">Фасовка</span>
	<select class="form-control" name="cats" id="addkey_cats">
	<option  disabled="disabled">Выбери товар</option>
		</select>
    </div><br />	
<br /><div id="upload"><span>Выбрать файл<span></div><span id="status"></span>
	<div  style="margin: 0;margin-bottom: 10px;">	
<ul id="files"></ul>
</div><br /> 
<hr>
<button type="submit" onclick="addkeys()"  data-loading-text="Сохраняю" class="btn btn-danger btn-lg btn-block">Добавить</button>
</form>
</div>
</div>
<style>
#upload{
	margin: 10px 30px; 
	padding: 10px;
	font-weight: bold; 
	font-size: 14px;
	font-family: Arial, Helvetica, sans-serif;
	text-align: center;
	background: #f2f2f2;
	color: #3366cc;
	border: 2px solid #ccc;
	width: 150px;
	cursor: pointer !important;
	-moz-border-radius: 5px; -webkit-border-radius:5px;
}
.darkbg{
	background: #ddd !important;
}
#status{
	font-family: Arial; 
	padding: 5px;
}
ul#files{ list-style: none; padding: 0; margin: 0; }
ul#files li{ padding: 10px; margin-bottom: 2px; width: 150px; float: left; margin-right: 10px;}
ul#files li img{ max-width: 160px; max-height: 150px; }
.success{}
.error{ background: #f0c6c3; border: 1px solid #cc6622; }
</style>
<?
$My_Class->foot();
}else{
	$My_Class->title("Управление товаром");

?>


<h4 class="page-title">Управление товаром</h4>
<br />
<div class="col-sm-12">
<div class="card-box">
<center><a  href="?page=add" class="btn btn-icon btn-success waves-effect waves-light btn-sm" style="margin-bottom: 10px;"><span class="glyphicon glyphicon-plus-sign"></span> Добавить адреса</a></center>
<?php
$total = DB::$the->query("SELECT * FROM `sel_keys` where `curer` = '{$user['login']}'");
$total = $total->fetchAll();
$max = 5;
$pages = $My_Class->k_page(count($total),$max);
$page = $My_Class->page($pages);
$start=($max*$page)-$max;

if(count($total) == 0){
echo '<div class="alert alert-danger">В данной подкатегории нет адресов!</div>';
}	

echo '<ul class="sortable-list taskList list-unstyled ui-sortable" id="upcoming">';
$query = DB::$the->query("SELECT * FROM `sel_keys` where `curer` = '{$user['login']}' order by `id` DESC LIMIT $start, $max");
while($key = $query->fetch()) {


	$subcats = DB::$the->query("SELECT * FROM `sel_cat` WHERE `id` = '".$key['id_subcats']."' ");
$subcats = $subcats->fetch(PDO::FETCH_ASSOC);
$subcat = DB::$the->query("SELECT * FROM `sel_subcategory` WHERE `id` = '".$key['id_subcat']."' ");
$subcat = $subcat->fetch(PDO::FETCH_ASSOC);
$cats = DB::$the->query("SELECT * FROM `sel_subcat` WHERE `id` = '".$key['id_cats']."' ");
$cats = $cats->fetch(PDO::FETCH_ASSOC);

echo '
                                <li class="task-warning ui-sortable-handle" id="task1">
                                    <div class="checkbox checkbox-custom checkbox-single pull-right">
                                        <input type="checkbox" aria-label="Single checkbox Two">
                                        <label></label>
                                    </div>
                                 '.$key['code'].'
                                    <div class="m-t-20">
                                        <p class="pull-right m-b-0"><i class="ion-ios7-drag"></i> <b>Товар:</b> <span> '.$subcat['name'].'</span></p>
                                        <p class="m-b-0"><b>Фасовка:</b>'.$cats['name'].'  <b>Район:</b> '.$subcats['name'].' </p>
                                    </div>
                                </li>';
}
echo '</ul>';

if ($pages>1) $My_Class->str('?category='.$category.'&subcategory='.$subcategory.'&',$pages,$page); 
?>
</div> 
</div> 
</div> 
</div> 
<?php
$My_Class->foot();

}
echo'<script>
setTimeout("selectcats()", 1000);
setTimeout("selecttovar('.$user['category'].')", 1000);
setTimeout("selectsubcats('.$user['category'].')", 500);
</script>';
?>
<script>
function selecttovar(cat){
	
    $.ajax({  
        type: "GET",  
        url: "../curpanel/ajax.php",
		data: "mod=loadtovar&cat="+cat,
        dataType: "json",
        success: function(data){
	      if(data.status == 'success'){
		  var tovar = '<option  disabled="disabled" selected="selected">' + $("#addkey_tovar option:first").html() +'</option>';
				
				for(x in data.tovar)
					tovar += '<option value="' + data.tovar[x].id + '">' + data.tovar[x].name + '</option>'
				
				$("#addkey_tovar").html(tovar);
		 }
    } 
	
});
   }
   
function selectcats(){
	var tovar = $('#addkey_tovar').val();
	if(!tovar)
		return false;
    $.ajax({  
        type: "GET",  
        url: "../curpanel/ajax.php",
		data: "mod=loadcats&tovar="+tovar,
        dataType: "json",
        success: function(data){
	      if(data.status == 'success'){
		  var cats = '<option disabled="disabled" selected="selected">' + $("#addkey_cats option:first").html() +'</option>';
				
				for(x in data.cats)
					cats += '<option value="' + data.cats[x].id + '">' + data.cats[x].name + '</option>'
				
				$("#addkey_cats").html(cats);
		 }
    } 
	
});

 }
  
function selectsubcats(cat){
	

    $.ajax({  
        type: "GET",  
        url: "../curpanel/ajax.php",
		data: "mod=loadsubcats&cat="+cat,
        dataType: "json",
        success: function(data){
	      if(data.status == 'success'){
		  var subcats = '<option disabled="disabled" selected="selected">' + $("#addkey_subcats option:first").html() +'</option>';
				
				for(x in data.subcats)
					subcats += '<option value="' + data.subcats[x].id + '">' + data.subcats[x].name + '</option>'
				
				$("#addkey_subcats").html(subcats);
		 }
    } 
	
});
   }
   

   
   function addkeys(){
	$.ajax({
		type: "GET",
		url: "../curpanel/ajax.php?mod=addkeys",
		data: $("#addkeys").serialize(),
		dataType: "json",
		success: function(data){
			    if(data.status == 'success'){

				$("#msg").html('<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">x</button><br><strong>Внимание!</strong>'+data.status+'</div>');
				
		 }else if(data.status == 'error'){

				$("#msg").html('<div class="alert alert-error"><button type="button" class="close" data-dismiss="alert">x</button><br><strong>Внимание!</strong>'+data.status+'</div>');
		 
		 }
		}
	});
	return false;

}
</script>
  