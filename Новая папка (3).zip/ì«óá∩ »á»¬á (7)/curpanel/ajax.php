<?php

require_once "../classes/My_Class.php";

header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache"); 
header("Content-Type: text/javascript; charset=utf-8");


$load = (isset($_GET['mod']) ? $_GET['mod'] : "");

switch($load)
{
		case 'loadcats':
			 $cats = array();
$query = DB::$the->query("SELECT * FROM `sel_subcat` WHERE `id_subcat` = '{$_GET['tovar']}' ");
	 			while($row = $query->fetch()) {
  
  $cats[$row['id']] = array('id' =>$row['id'],'name'=>$row['name']);
           }
echo json_encode(array('status'=>'success', 'cats' => $cats,));
	    break;
	case 'loadtovar':
			 $tovar = array();
$query = DB::$the->query("SELECT * FROM `sel_subcategory` WHERE `id_cat` = '{$_GET['cat']}' ");
	 			while($row = $query->fetch()) {
  
  $tovar[$row['id']] = array('id' =>$row['id'], 'name'=> $row['name']);
           }
echo json_encode(array('status'=>'success', 'tovar' => $tovar,));
	    break;
		case 'loadsubcats':
			 $subcats = array();
$query = DB::$the->query("SELECT * FROM `sel_cat` WHERE `cat` = '{$_GET['cat']}' ");
	 			while($row = $query->fetch()) {
  
  $subcats[$row['id']] = array('id' =>$row['id'],'name'=>$row['name']);
           }
echo json_encode(array('status'=>'success', 'subcats' => $subcats,));
	    break;
	case 'addkeys':	
  if ($_GET['key'] != "") {
    $code = $_GET['key'];
	$arrAD = ['key' => 'code'];
	$arrAD[]='key';
	foreach(explode("\n",$code)as$key){
		$key = htmlspecialchars($key);
		$key = trim($key);
		if(($key = htmlspecialchars(trim( $key)))!= ''){
			$str_search = array("#\[img\](.*?\.(?:jpg|jpeg|gif|png|bmp))\[\/img\]#is",);
			$str_replace = array("".SITEDIR."/style/images/keys/\\1",);
			$key = preg_replace($str_search, $str_replace, $key);
			$params = array('code' => $key, 'id_cat' => $_GET['cat'], 'id_cats' => $_GET['cats'], 'id_subcats' => $_GET['subcat'], 'id_subcat' => $_GET['tovar'], 'time' => time(), 'sale' => '0', 'curer' => $_GET['login']);
			$q = DB::$the->prepare("INSERT INTO `sel_keys` (code, id_cat, id_cats, id_subcats, id_subcat, time, sale, curer) VALUES (:code, :id_cat, :id_cats, :id_subcats, :id_subcat, :time, :sale, :curer)");
			$q->execute($params);}$ph = DB::$the->query("SELECT id FROM `sel_keys` order by `id` DESC "); $ph = $ph->fetch(PDO::FETCH_ASSOC);}
	                     header("Location: shops.php");

    echo json_encode(array('status'=>'success', 'msg' => 'Успешно добавлены',));

  }else{
	      echo json_encode(array('status'=>'error', 'msg' => 'Не все данные указаны!',));

  }
  break;
}
?>