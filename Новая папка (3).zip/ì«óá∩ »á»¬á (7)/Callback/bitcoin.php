<?php
require '../classes/Configuration.php';
require '../classes/Curl.php';
require '../classes/PDO.php';
require '../classes/engine.php';

$eng = new Engine();
$curl = new Curl();
$db = new DB();
DB::$the->query("SET NAMES utf8");
$set_bot = DB::$the->query("SELECT * FROM `sel_set_bot` ");
$set_bot = $set_bot->fetch(PDO::FETCH_ASSOC);
$jsons = file_get_contents('https://blockchain.info/ru/ticker'); // Получаем запрос от пользователя
$btccur = json_decode($jsons, true);
$btccurs    = $btccur['RUB']['buy']; //курс биткоина к рублю

$url = "http://www.nationalbank.kz/rss/rates.xml"; // Адрес до RSS-ленты
	$rss = simplexml_load_file($url);

	$rub = $rss->channel->item[0]->description; // курс RUR к тенге
	$eur = $rss->channel->item[1]->description; // курс EUR к тенге
	$usd = $rss->channel->item[2]->description; // курс USD к тенге


$secret = "7j0ap91o99cxj8k9";
if ($_GET["secret"] !== $secret) die();
 
$invoice_id = $_GET["invoice_id"]; //вывод пользователя
$input_address = $_GET["input_address"];//вывод кошелька btc
$input_transaction_hash = $_GET["input_transaction_hash"];
$transaction_hash = $_GET["transaction_hash"];
$value_in_satoshi = $_GET["value"];//вывод сатоши
$value_in_satoshik = str_replace("E-5","",$value_in_satoshi);//вывод сатоши
$value_in_btc = $value_in_satoshik / 100000000;//вывод btc
$confirmations = $_GET["confirmations"];//вывод подтверждений
$value_in_rub = round($value_in_btc * $btccurs); //вывод рублей
$value_in_kzt = round($value_in_rub * $rub); //вывод тенге
// An unconfirmed transaction appeared on the network, you can add it to DB and show to customer that we see transaction and waiting confirmation. But order is still not paid!
if ($confirmations==1){
	$params = array("invoice_id" => $invoice_id, "input_address" => $input_address, "input_transaction_hash" => $input_transaction_hash, "transaction_hash" => $transaction_hash, "value" => $value_in_btc, "date_create" => time(), "valuerub" => $value_in_rub, "valuekzt" => $value_in_kzt);  
         $q = DB::$the->prepare("INSERT INTO payments (invoice_id, status, input_address, input_transaction_hash, transaction_hash, value, date_create, valuerub, valuekzt) VALUES (:invoice_id, 'Оплачен', :input_address, :input_transaction_hash, :transaction_hash, :value, :date_create, :valuerub, :valuekzt)");  
         $q->execute($params);	
         $chat = $_GET['users'];
         // ???????? ??? ?????????? ? ????????????
$user = DB::$the->query("SELECT * FROM `sel_users` WHERE `chat` = {$chat} ");
$user = $user->fetch(PDO::FETCH_ASSOC);
$balans_add = $user['balansbtc'] + $value_in_btc;
		 DB::$the->prepare("UPDATE sel_users SET balansbtc=? WHERE chat=? ")->execute(array($balans_add, $user['chat'])); 
$curl->get('https://api.telegram.org/bot'.$set_bot['token'].'/sendMessage',array('chat_id' => $user['chat'], 'text' => '⚜️ Вам зачислены деньги в размере '.$value_in_btc.' BTC ⚜️','parse_mode' => 'HTML',)); 		 		 
		 if ($q->rowCount()) {
        echo "*ok*";
    
		 
}
 
}
?>